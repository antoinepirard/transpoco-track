# Cameras FAQ

Back to home

1.  Knowledge Base 
3.  Cameras 
5.  FAQ 

-   Logging-in to your Transpoco account
    -   Login to your Transpoco account
    -   Transpoco Smartphone Apps
    -   2 Factor Authentication
    -   System requirements
    -   Overview of Transpoco
    -   Implementation
-   How to organise your account to achieve the best results
    
-   How to use each feature - step by step guides
    -   Users and permissions
    -   Walkaround Checks module
    -   Fuel/Electric Vehicles Module
    -   Maintain Module
    -   Dashboard
    -   Messaging module
    -   Scheduled Reports
-   How to Order More Trackers
    
-   Live Map
    
-   Cameras
    -   FAQ
-   Webinar Videos
    
-   Walkaround Checklists
    -   Walkaround Checklists
    -   Driver App
    -   Alerts
-   Reports
    -   Reports
    -   Viewing data in reports
-   Fuel
    
-   Dashboard
    
-   Maintain Module
    
-   Driving Style
    
-   Locations
    
-   Cost Management (TCO) Report
    
-   The Notification Features
    
-   Hardware and Installation
    
-   Removal & Repair of Hardware
    -   Requesting a Repair or a Deinstallation
-   Cameras & GDPR Guidelines
    
-   Scheduled Reports
    
-   Safety Program
    
-   Fleet Manager App
    
-   Users & Permissions
    
-   Alerts
    
-   Policies & Documents
    
-   Privacy Policy and Terms & Conditions
    -   RoPA
-   API
    
-   Transpoco User Manuals
    
-   Settings
    -   Garage
-   Whats New?
    
-   Account Mangement Services
    
-   Driver ID process
    
-   Security
    
-   Transpoco Locate
    
-   Subscriptions & Invoices
    
-   Tutorial videos
    
-   Cancelling your account
    
-   VOR
    
-   Installation
    
-   BIKLY
    

# Cameras FAQ

## Here you will find all information you may need related to cameras. If you need any other information, please contact our support team on support@transpoco.com

### **Index:**

What are the billing options for our cameras?

What benefits does a camera deliver for the customer?

Can a customer transfer their camera to another provider if they cancel or contract expires?

Do we sell rear facing cameras or multi-camera systems?

Where to install a camera in your vehicle?

**What is the standard cost of installing a camera?**

Do we offer a self install camera option?

What is the process for cancelling a camera?

Can the settings of a camera be customised?

Do we offer free trials for cameras?

How many hours of footage can the camera record?

How long does the camera take to start recording after the power is ON (vehicle engine is ON)?

**How can we ensure the camera continues to works post installation and how can we be alerted to problems.**

**Can I have an online demo of the camera?**

**What network are the camera SIMs on?**

**How will a camera solve the customers’ problems or improve their situation?**

**When an event is triggered, how long is the clip uploaded to the platform?**

**How long is the camera data stored in the platform? Can we customise this period?** 

**When the camera starts and stops recording**

**If someone removes the SD Card does our camera notify us that it has been removed?** 

**If the SD card is removed does the user need specialized software to view the video footage locally?**

### What are the billing options for our cameras?

#### Check with our sales team.

For existing customers we can start by looking at your current billing cycle and working to choose an option which suits you. For new or prospective customers please check with our sales team at 01 90 53 881 to discuss your options.

### What benefits does a camera deliver for the customer?

#### Reductions in administration. accidents, insurance and improved reputation

The benefits of installing a camera are:

\-Reduction in administration time

\-Reduction in accidents

\-Reduced insurance premiums

\-Improved company reputation

### Can a customer transfer their camera to another provider if they cancel or contract expires?

#### Transferring your camera to another provider.

As you have paid for the camera you will have the right to move to a new provider if you cancel or your contract expires. However, moving to a new provider will probably require reformatting, new SIM cards, etc.

The SIM card provided by Transpoco will be cancelled.

### Do we sell rear facing cameras or multi-camera systems?

We keep expanding our range of cameras,  please call our sales team at +353(0)1 90 53 881 to learn more and to schedule an online demonstration of our cameras. 

### Where to install a camera in your vehicle?

#### Install a dash camera behind the rear view mirror.

Best practice is to securely fix your camera behind the rear-view mirror of your vehicle, out of your line of sight to ensure it doesn’t obstruct your view and that way it will clearly capture both lanes of the road ahead.

### What is the standard cost of installing a camera?

#### Average standard cost to install a dash camera in ROI is €50.

Average standard cost to install a dash camera in ROI is €50. 

### Do we offer a self install camera option?

#### Self-installing dash cameras.

There is an installation guide included with the VT2000 to help you to self-install the dash camera.

### What is the process for cancelling a camera?

#### How to cancel a camera contract.

**Cancellation Process** 

**1\. Notification to cancel**

Please provide us with 30 days notice of cancellation. For our records we will require you to express your intention to cancel in writing. Please email support@transpoco.com with your intention to cancel.

We will respond to the email acknowledging the cancellation and that no further subscription payments for the dash camera(s) will be charged.

**2\. Status of hardware**

As you have purchased the dash camera(s) there will be no need to return of the dash camera(s).

However, we will cancel the SIM card in the dash camera(s) and the dash camera will no longer be accessible in your Transpoco account.

To continue to use the dash camera(s) with another provider your dash camera will require a new SIM card and reformatting by any new provider.

**3\. Refund**

We will stop future subscription payments the dash camera(s). We will not offer any partial refund from your previous payment.

**4\. Third party financing**

If you have financed the purchase of your camera through third party financing and intend to cancel please contact your finance provider.

You can contact Transpoco to stop your subscription charges- email us at support@transpoco.com

### Can the settings of a camera be customised?

**AI Cameras**

The driver facing AI camera and forward facing AI camera are configured to detect specific events. You can view all of the events **here.**

If you want to disable one or more events events please send an email to support@transpoco.com stating your changes. Any change to a camera will apply to all camera in your fleet.

The AI events include an audio warning to warn the driver. By default, these audio warnings are not enabled, we will only enable these audio warnings at the request of a customer. We can also disable the warnings if instructed by a customer.

**Non-AI Camera**

The settings for the non-AI cameras cannot be changed.

### Do we offer free trials for cameras?

Please contact the sales team in Transpoco at +353(0)1 90 53 881 to discuss pricing and to organise a demonstration.

### How many hours of footage can the camera record?

#### SD card can record for 80 hours before erasing footage.

The data is stored on a 128 GB SD card. This SD card will hold approximately 80 hours of video.

After 80 hours have been recorded the football will erase creating space for a further 80 hours of footage to be recorded. It means the footage is erased as needed on a FIFO basis so that at any given time, the previous 80 hours footage is on the camera.

### **How long does the camera take to start recording after the power is ON (vehicle engine is ON)?**

The camera takes 20 - 30 seconds to start recording after its power is ON (vehicle engine is ON).

### How can we ensure the camera continues to works post installation and how can we be alerted to problems.

Once sales have increased we will create a health check feature. At the moment there is no specification or requirements document for this feature.

### Can I have an online demo of the camera?

Yes, please contact the sales team in Transpoco at +353(0)1 90 53 881 to schedule an online demonstration of our camera solutions.

### What network are the camera SIMs on?

#### SIM networks

T-mobile with non steered sims. Networks used in main markets are:

UK: Hutchison 3G (Three): 2G, 3G, LTE ,Telefonica (O2): 2G, 3G, LTE Vodafone: 2G, 3G, LTE

Ireland: Meteor (Eir): 2G, 3G, LTE, Three Ireland: 2G, 3G,Vodafone: 2G, 3G, LTE

France: Bouygues Telecom: 2G, 3G, LTE,Free Mobile: 2G, 3G,Orange: 2G, 3G, LTE,SFR: 2G, 3G

### How will a camera solve the customers’ problems or improve their situation?

#### Dash camera will result in reduced insurance costs.

By providing evidence at times when there has been an incident. As the cameras are connected to trackers they can provide data in real time meaning customers can act straight away answering to insurers and reducing their premiums

### **When an event is triggered, how long is the clip uploaded to the platform?**

Our default if the event is a triggered event is 10secs. If you want to request footage through the system we allow it for 1min intervals with a max footage request of 5mins. e.g. If it is a clip of 10secs, it starts 5 secs before the incident and lasts for more 5 secs giving a total of 10 secs. 

### **How long is the camera data stored in the platform? Can we customise this period?** 

Our default period is 7yrs IF the footage is downloaded from the camera to align with the Statute of Limitations regarding claims.

Yes, we can adjust this for you for any dowloaded footage as we do for other key clients. Please send an email to support@transpoco.com

### When the camera starts and stops recording

Cameras only start recording **20 - 30 seconds** after it is with power ON (after the vehicle engine is ON).

Cameras stop recording depending on the settings. We usually set them with **300 secs** after the vehicle engine is OFF.

### If someone removes the SD Card does the camera notify us that it has been removed? 

There is an event called **"Abnormal storage alarm"** that will go through the Notifications page, but it can be related to "SD Card not existing" or "SD Card read and write exception". Only Transpoco can check it via WebCeiba. 

**Note:** If you see this **"Abnormal storage alarm"** in the Notifications section, please contact our support on **support@transpoco.com**

### **If the SD card is removed does the user need specialized software to view the video footage locally?**

The user needs the Ceiba Desktop version to read the SD Card. Please contact our support on **support@transpoco.com** if you need to access the SD Card locally.
