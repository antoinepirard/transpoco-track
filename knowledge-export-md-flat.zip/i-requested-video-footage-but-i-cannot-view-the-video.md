# I requested video footage but I cannot view the video

Back to home

1.  Knowledge Base 
3.  Cameras 
5.  FAQ 

-   Logging-in to your Transpoco account
    -   Login to your Transpoco account
    -   Transpoco Smartphone Apps
    -   2 Factor Authentication
    -   System requirements
    -   Overview of Transpoco
    -   Implementation
-   How to organise your account to achieve the best results
    
-   How to use each feature - step by step guides
    -   Users and permissions
    -   Walkaround Checks module
    -   Fuel/Electric Vehicles Module
    -   Maintain Module
    -   Dashboard
    -   Messaging module
    -   Scheduled Reports
-   How to Order More Trackers
    
-   Live Map
    
-   Cameras
    -   FAQ
-   Webinar Videos
    
-   Walkaround Checklists
    -   Walkaround Checklists
    -   Driver App
    -   Alerts
-   Reports
    -   Reports
    -   Viewing data in reports
-   Fuel
    
-   Dashboard
    
-   Maintain Module
    
-   Driving Style
    
-   Locations
    
-   Cost Management (TCO) Report
    
-   The Notification Features
    
-   Hardware and Installation
    
-   Removal & Repair of Hardware
    -   Requesting a Repair or a Deinstallation
-   Cameras & GDPR Guidelines
    
-   Scheduled Reports
    
-   Safety Program
    
-   Fleet Manager App
    
-   Users & Permissions
    
-   Alerts
    
-   Policies & Documents
    
-   Privacy Policy and Terms & Conditions
    -   RoPA
-   API
    
-   Transpoco User Manuals
    
-   Settings
    -   Garage
-   Whats New?
    
-   Account Mangement Services
    
-   Driver ID process
    
-   Security
    
-   Transpoco Locate
    
-   Subscriptions & Invoices
    
-   Tutorial videos
    
-   Cancelling your account
    
-   VOR
    
-   Installation
    
-   BIKLY
    

# I requested video footage but I cannot view the video

In order to download and view a clip of footage from a dash cam in a vehicle straightaway the vehicle needs to have the engine on at the time of the request. 

If the vehicle has the engine off at the time you request the clip of footage you will have to wait until the the engine of the vehicle turns on.

To help, we indicate the current status of the engine in the Camera module in the **Vehicle Status Status** column. In the example below, the vehicles with the: 

**\-green** **icon** status indicate the engine is on and if you request video the video will download within a few minutes.

**\-red icon** indicates the ignition is off. If you request video you will have to wait until the engine is turned on in order to download and view the video. After the video downloads you will receive an email to notify you that the video is available to view.

Camera-12-16-2024\_03\_15\_PM
