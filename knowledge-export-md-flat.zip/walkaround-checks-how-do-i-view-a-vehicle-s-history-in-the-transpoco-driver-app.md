# Walkaround Checks: How do I view a vehicle's history in the Transpoco Driver app?

Back to home

1.  Knowledge Base 
3.  Walkaround Checklists 
5.  Driver App 

-   Logging-in to your Transpoco account
    -   Login to your Transpoco account
    -   Transpoco Smartphone Apps
    -   2 Factor Authentication
    -   System requirements
    -   Overview of Transpoco
    -   Implementation
-   How to organise your account to achieve the best results
    
-   How to use each feature - step by step guides
    -   Users and permissions
    -   Walkaround Checks module
    -   Fuel/Electric Vehicles Module
    -   Maintain Module
    -   Dashboard
    -   Messaging module
    -   Scheduled Reports
-   How to Order More Trackers
    
-   Live Map
    
-   Cameras
    -   FAQ
-   Webinar Videos
    
-   Walkaround Checklists
    -   Walkaround Checklists
    -   Driver App
    -   Alerts
-   Reports
    -   Reports
    -   Viewing data in reports
-   Fuel
    
-   Dashboard
    
-   Maintain Module
    
-   Driving Style
    
-   Locations
    
-   Cost Management (TCO) Report
    
-   The Notification Features
    
-   Hardware and Installation
    
-   Removal & Repair of Hardware
    -   Requesting a Repair or a Deinstallation
-   Cameras & GDPR Guidelines
    
-   Scheduled Reports
    
-   Safety Program
    
-   Fleet Manager App
    
-   Users & Permissions
    
-   Alerts
    
-   Policies & Documents
    
-   Privacy Policy and Terms & Conditions
    -   RoPA
-   API
    
-   Transpoco User Manuals
    
-   Settings
    -   Garage
-   Whats New?
    
-   Account Mangement Services
    
-   Driver ID process
    
-   Security
    
-   Transpoco Locate
    
-   Subscriptions & Invoices
    
-   Tutorial videos
    
-   Cancelling your account
    
-   VOR
    
-   Installation
    
-   BIKLY
    

# Walkaround Checks: How do I view a vehicle's history in the Transpoco Driver app?

## The app allows you to view the checklist history of one or more vehicles or vehicle groups for a selected period.

From the Walkaround Home Page, tap on **View Vehicle History**.

If the categories are not showing (as in right image), tap on **Filters** (left image).

Screenshot\_20190725\_122516\_com.synx.driver     Screenshot\_20190801\_180006\_com.synx.driver

Tap on **All Groups** if you want to select a vehicle group.

Select the vehicle group from the list, scrolling down or typing in all or part of the group name in the text box if required (the list will filter automatically).

Screenshot\_20190725\_122529\_com.synx.driver      Screenshot\_20190801\_180248\_com.synx.driver

Tap on **All Vehicles** if you want to select a specific vehicle in your chosen vehicle group.

Select the vehicle from the list, scrolling down or typing in all or part of the group name in the text box if required (the list will filter automatically).

Screenshot\_20190727\_145518\_com.synx.driver      Screenshot\_20190801\_180255\_com.synx.driver

**Note:** You do not need to select a vehicle group first, but for a large fleet this makes it easier to find a specific vehicle.

To change the dates from today’s date (default), tap on the **first** **date** (first image).

Screenshot\_20190801\_180255\_com.synx.driver NEW2     Screenshot\_20190801\_022917\_com.synx.driver     Screenshot\_20190801\_180311\_com.synx.driver

Tap on the required **start** **date** in the calendar and tap on **OK**.

From the Filters page, tap on the **second** **date** (first image below).

Screenshot\_20190801\_180311\_com.synx.driver NEW2     Screenshot\_20190801\_022938\_com.synx.driver    Screenshot\_20190801\_180322\_com.synx.driver

Tap on **View Vehicle History** from the filters page.

Screenshot\_20190801\_180421\_com.synx.driver

Scroll down to check that all checklists have been submitted.

**Note:** The paper plane icon denotes a checklist that has not yet been submitted.

If there is a checklist that needs submitting, follow the instructions for View Driver History if you were the driver, or contact the relevant driver to request they submit the checklist.
