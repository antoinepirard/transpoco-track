# How to change the custom' status of a vehicle

Back to home

1.  Knowledge Base 
3.  Fleet Manager App 

-   Logging-in to your Transpoco account
    -   Login to your Transpoco account
    -   Transpoco Smartphone Apps
    -   2 Factor Authentication
    -   System requirements
    -   Overview of Transpoco
    -   Implementation
-   How to organise your account to achieve the best results
    
-   How to use each feature - step by step guides
    -   Users and permissions
    -   Walkaround Checks module
    -   Fuel/Electric Vehicles Module
    -   Maintain Module
    -   Dashboard
    -   Messaging module
    -   Scheduled Reports
-   How to Order More Trackers
    
-   Live Map
    
-   Cameras
    -   FAQ
-   Webinar Videos
    
-   Walkaround Checklists
    -   Walkaround Checklists
    -   Driver App
    -   Alerts
-   Reports
    -   Reports
    -   Viewing data in reports
-   Fuel
    
-   Dashboard
    
-   Maintain Module
    
-   Driving Style
    
-   Locations
    
-   Cost Management (TCO) Report
    
-   The Notification Features
    
-   Hardware and Installation
    
-   Removal & Repair of Hardware
    -   Requesting a Repair or a Deinstallation
-   Cameras & GDPR Guidelines
    
-   Scheduled Reports
    
-   Safety Program
    
-   Fleet Manager App
    
-   Users & Permissions
    
-   Alerts
    
-   Policies & Documents
    
-   Privacy Policy and Terms & Conditions
    -   RoPA
-   API
    
-   Transpoco User Manuals
    
-   Settings
    -   Garage
-   Whats New?
    
-   Account Mangement Services
    
-   Driver ID process
    
-   Security
    
-   Transpoco Locate
    
-   Subscriptions & Invoices
    
-   Tutorial videos
    
-   Cancelling your account
    
-   VOR
    
-   Installation
    
-   BIKLY
    

# How to change the custom' status of a vehicle

## How to enable the view/change custom' status option for the vehicles in the Synx Manager App

**Note:** In order to be able to view and change a vehicle’s status, the option to do this must first have been enabled in your user profile.

**Note:** Only users with sufficient permissions can edit user profiles.

Click on your user account name on the far right of the tabbed menu bar.

Click on **Settings**.

Settings menu-5

To check which profile has been assigned to you / the user, click on ‘Users’ under **Users & Permissions** in the Settings menu.

Settings Menu - Users & Permissions - Users

Scroll down the list of users to find the assigned profile.

Users - list - find profile

Click on **Settings** in the navigation breadcrumbs, or click on your browser’s back button.

Click on ‘Profiles’ under **Users & Permissions** in the Settings menu.

User Profiles - list

Find the required profile in the list and click on the **Edit** button.

Update user profiles - modules (some off)

In the **Modules** tab, check the ‘FleetManager App’ box if not already checked.

Update user profiles - modules - fleet manager app2

Click on the **down arrow** for ‘Live Map’.

Check both boxes for ‘Access to view/edit vehicles custom status’ if not already checked.

Update user profiles - modules - live map

Click the **up arrow** to close the box.

The vehicle status will now be available in the Fleet Managers App – for individual vehicles on the live map and in the list of vehicles.

To view the status of a vehicle on the live map, touch the vehicle on the map.

Screenshot\_20191007\_235555\_com.synx.fleetmanager

Tap on **Change status** and select a status from the list.

To see the status of all vehicles which have a status assigned, tap on **Select Vehicles** from the live map.

**NOTE:** The colour of the vehicle name denotes its current engine status: Green – vehicle has its engine on; Red – vehicle has its engine off; and Yellow – vehicle is not sending data updates.

Screenshot\_20191008\_000411\_com.synx.fleetmanager
