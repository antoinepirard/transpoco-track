# Walkaround Checklists

Back to home

1.  Knowledge Base 
3.  Walkaround Checklists 

-   Logging-in to your Transpoco account
    -   Login to your Transpoco account
    -   Transpoco Smartphone Apps
    -   2 Factor Authentication
    -   System requirements
    -   Overview of Transpoco
    -   Implementation
-   How to organise your account to achieve the best results
    
-   How to use each feature - step by step guides
    -   Users and permissions
    -   Walkaround Checks module
    -   Fuel/Electric Vehicles Module
    -   Maintain Module
    -   Dashboard
    -   Messaging module
    -   Scheduled Reports
-   How to Order More Trackers
    
-   Live Map
    
-   Cameras
    -   FAQ
-   Webinar Videos
    
-   Walkaround Checklists
    -   Walkaround Checklists
    -   Driver App
    -   Alerts
-   Reports
    -   Reports
    -   Viewing data in reports
-   Fuel
    
-   Dashboard
    
-   Maintain Module
    
-   Driving Style
    
-   Locations
    
-   Cost Management (TCO) Report
    
-   The Notification Features
    
-   Hardware and Installation
    
-   Removal & Repair of Hardware
    -   Requesting a Repair or a Deinstallation
-   Cameras & GDPR Guidelines
    
-   Scheduled Reports
    
-   Safety Program
    
-   Fleet Manager App
    
-   Users & Permissions
    
-   Alerts
    
-   Policies & Documents
    
-   Privacy Policy and Terms & Conditions
    -   RoPA
-   API
    
-   Transpoco User Manuals
    
-   Settings
    -   Garage
-   Whats New?
    
-   Account Mangement Services
    
-   Driver ID process
    
-   Security
    
-   Transpoco Locate
    
-   Subscriptions & Invoices
    
-   Tutorial videos
    
-   Cancelling your account
    
-   VOR
    
-   Installation
    
-   BIKLY
    

# Walkaround Checklists

#### Walkaround Checklists

###### 

-   Walkaround Module Video Demonstration
-   Walkaround Checks: Where in my Transpoco account can I see the checklists submitted by drivers?
-   Walkaround Checks: How do I filter or search for checklists in the Walkaround dashboard?
-   Templates for customised walkaround checklists.
-   Walkaround Checks: How do I view a list of individual vehicle checks and issues in the dashboard?
-   How to create customised walkaround checklist
-   Walkaround Checks: How do I filter or search for a question/answer in the Walkaround list of checks?
-   Walkaround Checks: How do I customise the time between questions?
-   Walkaround Checks: How do I export the weekly checklists from the Walkaround dashboard?
-   Walkaround Checks: Can I action required services/repairs through the Walkaround Dashboard?
-   Walkaround Checks: How do I assign a user to a profile with access to the web module?
-   Walkaround Checks: How can I view the results of the Driver app Walkaround checks in Transpoco?
-   Walkaround Checks: How do users access the Walkaround module?
-   Walkaround Checks: How can I action services/repairs from the Walkaround Dashboard List of Checks?
-   Walkaround Checks: How can I action services/repairs from the Walkaround Dashboard Weekly View?
-   Walkaround Checks: Can I sort the weekly results by vehicle in the dashboard?
-   Walkaround Checks: How do I create a new profile for the Walkaround module?
-   Walkaround Checks: How do I access the Walkaround web dashboard?
-   Driven Without Check Report

See more

#### Driver App

###### 

-   Explainer video for the Transpoco Driver App
-   How to provide a driver with access to the Driver app
-   Walkaround Checks: How do I enable/disable mobile data in the Transpoco Driver app?
-   Walkaround Checks: How do I change the language of the Transpoco Driver app?
-   Walkaround Checks: How do I view a vehicle's history in the Transpoco Driver app?
-   Walkaround Checks: Transpoco Drivers app home page
-   Walkaround Checks: What is the Repeat feature in the Transpoco Driver app?
-   Walkaround Checks: How do I perform a walkaround vehicle check using the Transpoco Driver app?
-   Walkaround Checks: How do I create a driver declaration using the Driver app?
-   Walkaround Checks: How do I create an accident report using the Transpoco Driver app?
-   Walkaround Checks: How do I perform a site inspection using the Transpoco Driver app?
-   Walkaround Checks: How can I see my historic driver checklists in the Transpoco Driver app?
-   Walkaround Checks: How do I reset my password in the Transpoco Driver app?
-   Walkaround Checks: How do I exit the TranspocoDriver app?
-   Walkaround Checks: How do I access technical help from Transpoco in the SynX Driver app?
-   How to use the Transpoco Driver App
-   Walkaround Checks: How do I add a photo to the Transpoco Driver app?
-   Walkaround Check Submission - No Coverage Available

See more

#### Alerts

###### 

-   Walkaround Checks: How do I set up an alert to notify me of defects?
-   Walkaround Checks: How do I set up a Driven Without Check alert?
-   Walkaround Checks: How can I be alerted about vehicle checks?
-   Walkaround Checks: How do I view and/or modify an alert?
-   Walkaround Checks: How do I delete an alert?

See more
