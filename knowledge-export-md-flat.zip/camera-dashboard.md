# Camera - Dashboard

Back to home

1.  Knowledge Base 
3.  Dashboard 

-   Logging-in to your Transpoco account
    -   Login to your Transpoco account
    -   Transpoco Smartphone Apps
    -   2 Factor Authentication
    -   System requirements
    -   Overview of Transpoco
    -   Implementation
-   How to organise your account to achieve the best results
    
-   How to use each feature - step by step guides
    -   Users and permissions
    -   Walkaround Checks module
    -   Fuel/Electric Vehicles Module
    -   Maintain Module
    -   Dashboard
    -   Messaging module
    -   Scheduled Reports
-   How to Order More Trackers
    
-   Live Map
    
-   Cameras
    -   FAQ
-   Webinar Videos
    
-   Walkaround Checklists
    -   Walkaround Checklists
    -   Driver App
    -   Alerts
-   Reports
    -   Reports
    -   Viewing data in reports
-   Fuel
    
-   Dashboard
    
-   Maintain Module
    
-   Driving Style
    
-   Locations
    
-   Cost Management (TCO) Report
    
-   The Notification Features
    
-   Hardware and Installation
    
-   Removal & Repair of Hardware
    -   Requesting a Repair or a Deinstallation
-   Cameras & GDPR Guidelines
    
-   Scheduled Reports
    
-   Safety Program
    
-   Fleet Manager App
    
-   Users & Permissions
    
-   Alerts
    
-   Policies & Documents
    
-   Privacy Policy and Terms & Conditions
    -   RoPA
-   API
    
-   Transpoco User Manuals
    
-   Settings
    -   Garage
-   Whats New?
    
-   Account Mangement Services
    
-   Driver ID process
    
-   Security
    
-   Transpoco Locate
    
-   Subscriptions & Invoices
    
-   Tutorial videos
    
-   Cancelling your account
    
-   VOR
    
-   Installation
    
-   BIKLY
    

# Camera - Dashboard

## You can add Camera metrics to your Synx Dashboard. There are two types of camera. One is the front face camera which faces the driver with AI and the another one is the camera which faces the road with advanced driver-assistance systems (ADAS).

### **Create the dashboard:**

1.  Log on to your Transpoco account.
2.  Click Services > Dashboard.  
    
3.  Click add New on the top right corner of the dashboard.  
    
4.  For the Front Face Camera, please choose a **Title, Metric Type, Vehicle Group, Period** and **Alerts Camera** in the dialog. 

**Note:** 

-   Choose **AI Camera alerts** as **Metric type**.
-   **The Comparison Period** and **Weekdays** are not available for this metric.
-   Front Face Camera options - **Driver Yawns, Driver Distraction, Driver Call, Driver smoking, Driver fatigue** and **No driver**.

5.  For the ADAS Camera dashboard, repeat the process above.

**Note:** 

-   Choose **AI Camera alerts** as **Metric type**.
-   **The Comparison Period** and **Weekdays** are not available for this dashboard.
-   ADAS Camera options - **Forward Collision, Lane Departure, Distance Alarm,** and **Too close distance**.

6.  Click Save when you are ready . 

7.  Then you will see these two camera dashboards here, one is the front face camera which faces the driver and the another one is the camera which faces the road. 

**Note:**  You can find all Camera Alert examples in this article.
