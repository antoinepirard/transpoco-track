# What is the Journeys Report?

Back to home

1.  Knowledge Base 
3.  Reports 
5.  Reports 

-   Logging-in to your Transpoco account
    -   Login to your Transpoco account
    -   Transpoco Smartphone Apps
    -   2 Factor Authentication
    -   System requirements
    -   Overview of Transpoco
    -   Implementation
-   How to organise your account to achieve the best results
    
-   How to use each feature - step by step guides
    -   Users and permissions
    -   Walkaround Checks module
    -   Fuel/Electric Vehicles Module
    -   Maintain Module
    -   Dashboard
    -   Messaging module
    -   Scheduled Reports
-   How to Order More Trackers
    
-   Live Map
    
-   Cameras
    -   FAQ
-   Webinar Videos
    
-   Walkaround Checklists
    -   Walkaround Checklists
    -   Driver App
    -   Alerts
-   Reports
    -   Reports
    -   Viewing data in reports
-   Fuel
    
-   Dashboard
    
-   Maintain Module
    
-   Driving Style
    
-   Locations
    
-   Cost Management (TCO) Report
    
-   The Notification Features
    
-   Hardware and Installation
    
-   Removal & Repair of Hardware
    -   Requesting a Repair or a Deinstallation
-   Cameras & GDPR Guidelines
    
-   Scheduled Reports
    
-   Safety Program
    
-   Fleet Manager App
    
-   Users & Permissions
    
-   Alerts
    
-   Policies & Documents
    
-   Privacy Policy and Terms & Conditions
    -   RoPA
-   API
    
-   Transpoco User Manuals
    
-   Settings
    -   Garage
-   Whats New?
    
-   Account Mangement Services
    
-   Driver ID process
    
-   Security
    
-   Transpoco Locate
    
-   Subscriptions & Invoices
    
-   Tutorial videos
    
-   Cancelling your account
    
-   VOR
    
-   Installation
    
-   BIKLY
    

# What is the Journeys Report?

This report gives details on each trip from Point A to Point B across the selected time frame. Essentially, it's anytime a vehicle is turned on to when the vehicle is next turned off. This report is useful when looking to pinpoint a specific part of a driver's day. Route playback allows you to follow the snail trail of the vehicle's journey.

You can view this report as a data set, chart or route playback. This report can be exported.

-   *Default data points include:* Vehicle Registration, Date, Journey Start Time, Journey Start Location, Journey Stop Time, Journey Stop Location, Journey Time, Idling time, Distance, Route Playback

This is the Table view of the Journeys Report: 

This is the Chart View of the Journeys Report:

This is the Route Playback View. Route playback will play any journey as a snail trail of the trip, as well as the data points related. The journey can be exported as a spreadsheet or a google earth map:
