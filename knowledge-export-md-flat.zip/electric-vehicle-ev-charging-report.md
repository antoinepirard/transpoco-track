# Electric Vehicle (EV) Charging Report

Back to home

1.  Knowledge Base 
3.  Fuel 

-   Logging-in to your Transpoco account
    -   Login to your Transpoco account
    -   Transpoco Smartphone Apps
    -   2 Factor Authentication
    -   System requirements
    -   Overview of Transpoco
    -   Implementation
-   How to organise your account to achieve the best results
    
-   How to use each feature - step by step guides
    -   Users and permissions
    -   Walkaround Checks module
    -   Fuel/Electric Vehicles Module
    -   Maintain Module
    -   Dashboard
    -   Messaging module
    -   Scheduled Reports
-   How to Order More Trackers
    
-   Live Map
    
-   Cameras
    -   FAQ
-   Webinar Videos
    
-   Walkaround Checklists
    -   Walkaround Checklists
    -   Driver App
    -   Alerts
-   Reports
    -   Reports
    -   Viewing data in reports
-   Fuel
    
-   Dashboard
    
-   Maintain Module
    
-   Driving Style
    
-   Locations
    
-   Cost Management (TCO) Report
    
-   The Notification Features
    
-   Hardware and Installation
    
-   Removal & Repair of Hardware
    -   Requesting a Repair or a Deinstallation
-   Cameras & GDPR Guidelines
    
-   Scheduled Reports
    
-   Safety Program
    
-   Fleet Manager App
    
-   Users & Permissions
    
-   Alerts
    
-   Policies & Documents
    
-   Privacy Policy and Terms & Conditions
    -   RoPA
-   API
    
-   Transpoco User Manuals
    
-   Settings
    -   Garage
-   Whats New?
    
-   Account Mangement Services
    
-   Driver ID process
    
-   Security
    
-   Transpoco Locate
    
-   Subscriptions & Invoices
    
-   Tutorial videos
    
-   Cancelling your account
    
-   VOR
    
-   Installation
    
-   BIKLY
    

# Electric Vehicle (EV) Charging Report

## This is a report designed for Electric Vehicles only.

1) Select the "Fuel Reports" option

2) Click on the "EV Charging" option

3) You will be able to select the time range, vehicle group and/or vehicle you need

Note: If you have a question related to a column meaning, there is a question mark icon where you can hover over and a tip will be displayed with an explanation.

Note 2: To set the usable capacity of a vehicle you need to go to Settings -> Vehicles -> Edit the vehicle related -> Add the usable battery capacity -> Update.

If you don't have the field to add the "Usable Battery Capacity" in your vehicle edition, you need to add it via profile edition. Please follow the steps below.

4) To add the "Usable Battery Capacity" to the Vehicles edition page, you need to go to:

Settings -> Profile -> Edit Profile -> Garage Customisation tab -> Drag the attribute option from the left and drop it to the right side under "Customizable Columns" -> Update Profile.
