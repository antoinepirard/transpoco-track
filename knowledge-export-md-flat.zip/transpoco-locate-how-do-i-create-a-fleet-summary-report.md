# Transpoco Locate: How do I create a Fleet Summary Report?

Back to home

1.  Knowledge Base 
3.  Transpoco Locate 

-   Logging-in to your Transpoco account
    -   Login to your Transpoco account
    -   Transpoco Smartphone Apps
    -   2 Factor Authentication
    -   System requirements
    -   Overview of Transpoco
    -   Implementation
-   How to organise your account to achieve the best results
    
-   How to use each feature - step by step guides
    -   Users and permissions
    -   Walkaround Checks module
    -   Fuel/Electric Vehicles Module
    -   Maintain Module
    -   Dashboard
    -   Messaging module
    -   Scheduled Reports
-   How to Order More Trackers
    
-   Live Map
    
-   Cameras
    -   FAQ
-   Webinar Videos
    
-   Walkaround Checklists
    -   Walkaround Checklists
    -   Driver App
    -   Alerts
-   Reports
    -   Reports
    -   Viewing data in reports
-   Fuel
    
-   Dashboard
    
-   Maintain Module
    
-   Driving Style
    
-   Locations
    
-   Cost Management (TCO) Report
    
-   The Notification Features
    
-   Hardware and Installation
    
-   Removal & Repair of Hardware
    -   Requesting a Repair or a Deinstallation
-   Cameras & GDPR Guidelines
    
-   Scheduled Reports
    
-   Safety Program
    
-   Fleet Manager App
    
-   Users & Permissions
    
-   Alerts
    
-   Policies & Documents
    
-   Privacy Policy and Terms & Conditions
    -   RoPA
-   API
    
-   Transpoco User Manuals
    
-   Settings
    -   Garage
-   Whats New?
    
-   Account Mangement Services
    
-   Driver ID process
    
-   Security
    
-   Transpoco Locate
    
-   Subscriptions & Invoices
    
-   Tutorial videos
    
-   Cancelling your account
    
-   VOR
    
-   Installation
    
-   BIKLY
    

# Transpoco Locate: How do I create a Fleet Summary Report?

## How to run the Fleet Summary Report in Locate to see an overview of your vehicles' activity.

The Fleet Summary Report shows high-level activity information about all the vehicles.

**Note:** If you require more detailed information about how to run the report, see How do I create a report?

1.  Select the **Vehicle(s)**.
2.  Select ‘Fleet Summary’ from the **Report** drop-down list.
3.  Select the **date** range.
4.  Click on the **View Report** button.

Fleet Summary Report

The standard information contained in this report covers the following for the selected period:

-   Description: Vehicle description
-   Registration: Vehicle number plate
-   No. Journeys: Total number of separate journeys undertaken
-   Travel Time: Total hours and minutes vehicle was moving
-   Distance: Total distance (in km or miles) covered
-   Idling Time: Total hours & minutes vehicle had ignition on but not moving
-   Days Driven: Number of days the vehicle was driven out of the total period.
-   % Days Driven: The number of days as a percentage of the total.

The totals for the fleet (or selected group of vehicles) are in the pink row.

‘Distance’, ‘Idling Times’ and ‘% Days Driven’ columns can be sorted into ascending and descending order. The default is for the summary to be listed in descending distance order, so the higher use vehicles are at the top. This is because travelling and idling use fuel, and over- and under-utilised vehicles can be easily identified in the report.

To sort the columns into a different order, click the **small black arrow** on the column heading.

To export the data as .csv or .xls format, click on the **Export** icon above the far right column. For more information see How do I export a report?
