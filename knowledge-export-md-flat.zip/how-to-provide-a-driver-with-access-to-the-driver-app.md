# How to provide a driver with access to the Driver app

Back to home

1.  Knowledge Base 
3.  Walkaround Checklists 
5.  Driver App 

-   Logging-in to your Transpoco account
    -   Login to your Transpoco account
    -   Transpoco Smartphone Apps
    -   2 Factor Authentication
    -   System requirements
    -   Overview of Transpoco
    -   Implementation
-   How to organise your account to achieve the best results
    
-   How to use each feature - step by step guides
    -   Users and permissions
    -   Walkaround Checks module
    -   Fuel/Electric Vehicles Module
    -   Maintain Module
    -   Dashboard
    -   Messaging module
    -   Scheduled Reports
-   How to Order More Trackers
    
-   Live Map
    
-   Cameras
    -   FAQ
-   Webinar Videos
    
-   Walkaround Checklists
    -   Walkaround Checklists
    -   Driver App
    -   Alerts
-   Reports
    -   Reports
    -   Viewing data in reports
-   Fuel
    
-   Dashboard
    
-   Maintain Module
    
-   Driving Style
    
-   Locations
    
-   Cost Management (TCO) Report
    
-   The Notification Features
    
-   Hardware and Installation
    
-   Removal & Repair of Hardware
    -   Requesting a Repair or a Deinstallation
-   Cameras & GDPR Guidelines
    
-   Scheduled Reports
    
-   Safety Program
    
-   Fleet Manager App
    
-   Users & Permissions
    
-   Alerts
    
-   Policies & Documents
    
-   Privacy Policy and Terms & Conditions
    -   RoPA
-   API
    
-   Transpoco User Manuals
    
-   Settings
    -   Garage
-   Whats New?
    
-   Account Mangement Services
    
-   Driver ID process
    
-   Security
    
-   Transpoco Locate
    
-   Subscriptions & Invoices
    
-   Tutorial videos
    
-   Cancelling your account
    
-   VOR
    
-   Installation
    
-   BIKLY
    

# How to provide a driver with access to the Driver app

In this video we demonstrate the steps to provide a driver with access to the **Transpoco Driver app** for walkaround checklists.

How provide a driver with access to the Transpoco Driver app for Walkaround checks? Please follow these steps.

Open the **Settings menu** and under **Garage** select **Drivers.**

You can provide access to a driver with an existing Driver profile or create a new profile for the driver.

Provide a first name and last name. 

You can ignore the fields for the Supervisor and Driver pay as these fields are not essential for this process. 

Provide a unique email address (this part is important as the email address will serve as the username).

In '**Driver app'** ('Grant access to driver app'**) -**open the drop down and change **No** to **Yes**

In '**Select Profile'** select **'Driver app access'**

**In Vehicle Group Access  -** you can provide access to the driver to see all vehicle registrations by selecting **'All Vehicles'** or you can assign 1 or more 2 customised vehicle groups.

After you have made these changes go to the bottom of the page and click the **'Create driver'** button or the **'Update driver'** button if you are editing an exiting profile.

An email will be sent to the driver to notify them that they have been given access to the Transpoco Driver app. The email will contain links to create a password and to download the Transpoco Driver app.

If you have access to the Transpoco Walkaround module the app is free to download.
