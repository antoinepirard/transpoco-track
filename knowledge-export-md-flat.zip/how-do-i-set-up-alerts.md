# How do I set up alerts?

Back to home

1.  Knowledge Base 
3.  Alerts 

-   Logging-in to your Transpoco account
    -   Login to your Transpoco account
    -   Transpoco Smartphone Apps
    -   2 Factor Authentication
    -   System requirements
    -   Overview of Transpoco
    -   Implementation
-   How to organise your account to achieve the best results
    
-   How to use each feature - step by step guides
    -   Users and permissions
    -   Walkaround Checks module
    -   Fuel/Electric Vehicles Module
    -   Maintain Module
    -   Dashboard
    -   Messaging module
    -   Scheduled Reports
-   How to Order More Trackers
    
-   Live Map
    
-   Cameras
    -   FAQ
-   Webinar Videos
    
-   Walkaround Checklists
    -   Walkaround Checklists
    -   Driver App
    -   Alerts
-   Reports
    -   Reports
    -   Viewing data in reports
-   Fuel
    
-   Dashboard
    
-   Maintain Module
    
-   Driving Style
    
-   Locations
    
-   Cost Management (TCO) Report
    
-   The Notification Features
    
-   Hardware and Installation
    
-   Removal & Repair of Hardware
    -   Requesting a Repair or a Deinstallation
-   Cameras & GDPR Guidelines
    
-   Scheduled Reports
    
-   Safety Program
    
-   Fleet Manager App
    
-   Users & Permissions
    
-   Alerts
    
-   Policies & Documents
    
-   Privacy Policy and Terms & Conditions
    -   RoPA
-   API
    
-   Transpoco User Manuals
    
-   Settings
    -   Garage
-   Whats New?
    
-   Account Mangement Services
    
-   Driver ID process
    
-   Security
    
-   Transpoco Locate
    
-   Subscriptions & Invoices
    
-   Tutorial videos
    
-   Cancelling your account
    
-   VOR
    
-   Installation
    
-   BIKLY
    

# How do I set up alerts?

Alerts allow you to monitor various aspects of your operations with real time notifications via text or email. Alerts also allow you to create reports based on your specific needs. Navigate to Settings>Alerts>Manage Alerts and click “Add New Alert”

To create an alert, first create a descriptive name and select the vehicles you’d like to create the alert for, then you’ll create the alert. Each alert should suit one specific need, such as speeding or location. Do not combine alerts.

You can create alerts based on:

-   Locations
-   Speeding
-   Rapid Acceleration
-   Harsh Braking
-   Shift Start Time
-   Weekend Driving
-   After-Hours Driving
-   Driving Duration
-   PTO
-   Driver ID Use
-   Battery Voltage/True Idle

To create an alert we recommend using the following statement to select the parameters. Say it out loud - if it doesn’t make sense, edit your alert.

**Create an alert IF** \[Parameter\] is \[equal, greater, less than etc\] than \[value\]

**AND** \[Parameter\] is \[equal, greater, less than etc\] than \[value\]

Here are a couple of examples of correct and incorrect alerts:

**Correct:**

Use case: I want to create an alert for when my trucks leave the depot in the morning after 8 am.

**IF** *Hour* is *greater than* *8:00*

**AND** *Exit Location* is *equal* to *Truck Depot*

Why it works: The initial parameter of 8:00 tells the system to alert only after 8:00 am and the second parameter tells the system that after 8:00 am, if the vehicle exits the location an alert should trigger.

 **Incorrect:**

Use case: I want to create an alert to monitor driver safety

**IF** *Speed over the limit* is *greater than* *20*km/hr

**AND** *Harsh braking* *equals detected*

**AND** *Rapid Acceleration equals detected*

  
Why it doesn’t work: The initial parameter will trigger if the driver is speeding 20km/hr, but the following parameters need to be met too, so that means that the vehicle needs to be going 20km/hr over the speed limit while also harsh braking and rapidly accelerating at the same time. That is impossible.
