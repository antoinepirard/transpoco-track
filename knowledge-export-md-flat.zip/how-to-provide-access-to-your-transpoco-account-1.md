# How to provide access to your Transpoco account

Back to home

1.  Knowledge Base 
3.  How to use each feature - step by step guides 
5.  Users and permissions 

-   Logging-in to your Transpoco account
    -   Login to your Transpoco account
    -   Transpoco Smartphone Apps
    -   2 Factor Authentication
    -   System requirements
    -   Overview of Transpoco
    -   Implementation
-   How to organise your account to achieve the best results
    
-   How to use each feature - step by step guides
    -   Users and permissions
    -   Walkaround Checks module
    -   Fuel/Electric Vehicles Module
    -   Maintain Module
    -   Dashboard
    -   Messaging module
    -   Scheduled Reports
-   How to Order More Trackers
    
-   Live Map
    
-   Cameras
    -   FAQ
-   Webinar Videos
    
-   Walkaround Checklists
    -   Walkaround Checklists
    -   Driver App
    -   Alerts
-   Reports
    -   Reports
    -   Viewing data in reports
-   Fuel
    
-   Dashboard
    
-   Maintain Module
    
-   Driving Style
    
-   Locations
    
-   Cost Management (TCO) Report
    
-   The Notification Features
    
-   Hardware and Installation
    
-   Removal & Repair of Hardware
    -   Requesting a Repair or a Deinstallation
-   Cameras & GDPR Guidelines
    
-   Scheduled Reports
    
-   Safety Program
    
-   Fleet Manager App
    
-   Users & Permissions
    
-   Alerts
    
-   Policies & Documents
    
-   Privacy Policy and Terms & Conditions
    -   RoPA
-   API
    
-   Transpoco User Manuals
    
-   Settings
    -   Garage
-   Whats New?
    
-   Account Mangement Services
    
-   Driver ID process
    
-   Security
    
-   Transpoco Locate
    
-   Subscriptions & Invoices
    
-   Tutorial videos
    
-   Cancelling your account
    
-   VOR
    
-   Installation
    
-   BIKLY
    

# How to provide access to your Transpoco account

The majority of users in your Transpoco account will only require access to view vehicles relevant to their role. Also the majority of users will not be entitled to have administrator access to your  account. 

In this article we will explain how you can create vehicle groups which will allow you to assign 1 or more vehicle groups to a new user. We will also demonstrate how you can create a customised user profile. All customers are provided with 1 user profile which is an administrator profile. We suggest you create customised user profiles which will have different levels of access.

Finally we will demonstrate how you can provide access to a new user which will involve assigning a user profile and assigning vehicle groups. Please follow the 3 steps below:

**Step 1: Create vehicle groups**

In this video we will demonstrate how you can create vehicle groups. By creating vehicle groups you can assign users with vehicles which are only relevant to their role or vehicles which they are entitled to view. 

Just to point out that you can add a vehicle to as many vehicle groups as you want. 

Vehicle groups do not update automatically. If a new vehicle is added to your Transpoco account you will need to assign the vehicle to relevant vehicle groups.

**Step 2: Create customised user profiles** 

After creating vehicle groups the next step is to create 1 or more customised user profiles. The majority of users in your account will only require access to view vehicles on the live map and run reports on the vehicles, these users will not be entitled to have administrator access to the account.

In this video we will demonstrate how you can create a sample profile.

We suggest creating users profiles for supervisors, managers and directors.

As we have demonstrated in the video your Transpoco account consists of lot of modules. To help you to understand each module we have created this article which explains each module.

**Step 3: Provide access to new users**

After you have created vehicle groups and user profiles you can now provide access to users in your organisation. In this video I will demonstrate how you can provide access to a new user.
