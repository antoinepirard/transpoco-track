# Driver App - Driving Style

Back to home

1.  Knowledge Base 
3.  Driving Style 

-   Logging-in to your Transpoco account
    -   Login to your Transpoco account
    -   Transpoco Smartphone Apps
    -   2 Factor Authentication
    -   System requirements
    -   Overview of Transpoco
    -   Implementation
-   How to organise your account to achieve the best results
    
-   How to use each feature - step by step guides
    -   Users and permissions
    -   Walkaround Checks module
    -   Fuel/Electric Vehicles Module
    -   Maintain Module
    -   Dashboard
    -   Messaging module
    -   Scheduled Reports
-   How to Order More Trackers
    
-   Live Map
    
-   Cameras
    -   FAQ
-   Webinar Videos
    
-   Walkaround Checklists
    -   Walkaround Checklists
    -   Driver App
    -   Alerts
-   Reports
    -   Reports
    -   Viewing data in reports
-   Fuel
    
-   Dashboard
    
-   Maintain Module
    
-   Driving Style
    
-   Locations
    
-   Cost Management (TCO) Report
    
-   The Notification Features
    
-   Hardware and Installation
    
-   Removal & Repair of Hardware
    -   Requesting a Repair or a Deinstallation
-   Cameras & GDPR Guidelines
    
-   Scheduled Reports
    
-   Safety Program
    
-   Fleet Manager App
    
-   Users & Permissions
    
-   Alerts
    
-   Policies & Documents
    
-   Privacy Policy and Terms & Conditions
    -   RoPA
-   API
    
-   Transpoco User Manuals
    
-   Settings
    -   Garage
-   Whats New?
    
-   Account Mangement Services
    
-   Driver ID process
    
-   Security
    
-   Transpoco Locate
    
-   Subscriptions & Invoices
    
-   Tutorial videos
    
-   Cancelling your account
    
-   VOR
    
-   Installation
    
-   BIKLY
    

# Driver App - Driving Style

## Driving Style inside Driver App

-   ### Access the Driving Style feature
    

Before accessing the features, you need to access the App first. 

Download and install the **Transpoco Driver app** from Google Play or the App Store.

\-no-subject-david-mccarthy-transpoco-com-Transpoco-Mail-12-20-2024\_04\_11\_PM

-   Open the app to the login page.

-   Enter your assigned **username** and **password** and tap on **Login**

After you login for the first time your phone could prompt you to save the login details and for convenience we recommend you save the login details.

The very first time you log in, the app may take time to load to the home page.

IMG\_0314-12-20-2024\_04\_03\_PM

The app opens to the home page which includes the Walkaround Check feature (this is covered in a separate user guide) as well as the Driving Style feature (left image).

You can also access the Driving Style features from any page within the App by tapping on the **three horizontal lines** at the top left of the screen to access the drop-down menu (right image).

**After you are all set, please have a look at how you can enjoy all these new features:**

**On the Driver App**

-   ### **Driving Summary**
    

Your Drivers will be able to check their *Speeding, Harsh Braking, Rapid Acceleration and Harsh Cornering percentages* as the calculation is based on how much they drive. Also, they can find their score which will be used for the Rank in a near future.

**Note:** Fleet Managers can define the type of driving events to display and use inside the Settings section in the Driving Style module.

-   From either the home page or the drop-down menu, tap on **Driving Style**.

-   Tap on **Driving Summary**.

The Driving Summary opens to show driving events for the current week (default).

Note: If your fleet uses **Transpoco camera**s, drivers can also see their own camera's data in the app. Their score might me affected with these events, depending on what is set from the admin side (Settings page from the Driving Style module).

The default driving summary displays the following:

-   Speeding %: Percentage of events of speeding over the speed limit
-   Harsh Braking: Events per 100km
-   Rapid Acceleration: Events per 100km
-   Harsh Cornering: Events per 100km
-   Score %: Calculated from driving events and their weightings

-   To change the date period, tap on the **date**.

-   Tap on a date to set the start date.
-   Tap on a second date to set the end date.

Note: If you're using **Transpoco cameras**, it might also display the following:

-   Distracted Driver: Events per 100km
-   Driver Making Calls: Events per 100km
-   Fatigue Driving: Events per 100km
-   Driver Smoking: Events per 100km
-   Driver Yawning: Events per 100km
-   Forward Collision: Events per 100km
-   Too Close Distance: Events per 100km

**Note:** The green highlighted date denotes the current day.

**PS: As the Fleet Manager, you are the one that can define the type of events you want to display and use in Score calculation inside the Settings section in the web module.**

-   ### **Speed Summary**
    

Your Drivers will be able to check their *Speeding* regarding the percentage *over Speed Limit*. Fleet Managers also can define what percentages they want to be displayed in the Settings section of the web module.

**Note:** Fleet Managers can define what percentages are to be displayed in the Settings section in the Driving Style module.

-   From either the home page or the drop-down menu, tap on **Driving Style**.

-   Tap on **Speed Summary**.

The Speed Summary opens to show speeding events for the current week (default).

The default speed summary displays the following:

-   Total: Percentage of events of speeding over all speed limits
-   1% to 10% Over Limit: Percentage of speeding events 1-10% over the speed limit
-   11% to 20% Over Limit: Percentage of speeding events 11-20% over the speed limit
-   21% to 30% Over Limit: Percentage of speeding events 21-30% over the speed limit
-   \>30% Over Limit: Percentage of speeding events greater than 30% over the  
    speed limit

-   To change the date period, tap on the **date**.

-   Tap on a **date** to set the start date.

-   Tap on a **second date** to set the end date.

**Note:** the green highlighted date denotes the current day.

-   ### **Driving Trend**
    

Your Drivers will be able t*o check their score for the* past weeks in a trend graphic which will help them improve their safety each week.

You can check your scores in a trend graphic to help you improve your driving behaviour.

-   From either the home page or the drop-down menu, tap on **Driving Style**.

-   Tap on **Driving Trend**.

The Driving Trend opens to show total scores calculated from driving events and their weightings for the last 7 days (default interval).

**Note:** Scroll down the list to see all the days and scores.

-   To see the breakdown of driving events and their scores, tap on the **date** in the table.

-   To change the interval, tap on **Last seven days** (or other interval) at the top of the screen.

-   Tap on the required **interval**.

The following images show a 3-week interval and a 12-week interval as examples. As can be seen, over the last three weeks the driver has increased their bad driving events.

-   To see the breakdown of driving events and their scores, tap on the **week** in the table.

**P.S.: The data started to be collected 7 days ago, so you should search for data from the last 7 days only. It is now collecting data so the gap will disappear.**

-   ### **Driver Rank**
    

Drivers Rank is based on your drivers’ score from the day before which means the Rank can change on a daily basis. At the moment, you can follow it from the Driving Summary which is ordered by score as well. You just need to change the calendar filter to reflect data from the desired day.

Driver Rank is based on each driver’s score from the previous day so the Rank can change on a daily basis.

-   From either the home page or the drop-down menu, tap on **Driving Style**.

-   Tap on **Driver Rank**.

The Driver Rank opens to display your position compared with other drivers in the fleet / driver group selected. 

Note: As a driver, you will only see the Driver Groups set for your account.

-   **Note:** You can also disable it for particular drivers by checking out the Driving Style option in their profile.

-   ### **Driver Mileage**
    

Driver Mileage displays the 'Total business distance' driven and the 'Total private distance' driven in KM or MI depending on the user preferences. 

-   From either the home page or the drop-down menu, tap on **Driving Style**.

-   Tap on **Driver Mileage Summary**.
-   Then, select the period you wish.

-   ### **Offline Mode**
    

If there is no internet connection, the checklist is saved for future sending.
