# How to block speeding alerts in certain location(s)

Back to home

1.  Knowledge Base 
3.  Driving Style 

-   Logging-in to your Transpoco account
    -   Login to your Transpoco account
    -   Transpoco Smartphone Apps
    -   2 Factor Authentication
    -   System requirements
    -   Overview of Transpoco
    -   Implementation
-   How to organise your account to achieve the best results
    
-   How to use each feature - step by step guides
    -   Users and permissions
    -   Walkaround Checks module
    -   Fuel/Electric Vehicles Module
    -   Maintain Module
    -   Dashboard
    -   Messaging module
    -   Scheduled Reports
-   How to Order More Trackers
    
-   Live Map
    
-   Cameras
    -   FAQ
-   Webinar Videos
    
-   Walkaround Checklists
    -   Walkaround Checklists
    -   Driver App
    -   Alerts
-   Reports
    -   Reports
    -   Viewing data in reports
-   Fuel
    
-   Dashboard
    
-   Maintain Module
    
-   Driving Style
    
-   Locations
    
-   Cost Management (TCO) Report
    
-   The Notification Features
    
-   Hardware and Installation
    
-   Removal & Repair of Hardware
    -   Requesting a Repair or a Deinstallation
-   Cameras & GDPR Guidelines
    
-   Scheduled Reports
    
-   Safety Program
    
-   Fleet Manager App
    
-   Users & Permissions
    
-   Alerts
    
-   Policies & Documents
    
-   Privacy Policy and Terms & Conditions
    -   RoPA
-   API
    
-   Transpoco User Manuals
    
-   Settings
    -   Garage
-   Whats New?
    
-   Account Mangement Services
    
-   Driver ID process
    
-   Security
    
-   Transpoco Locate
    
-   Subscriptions & Invoices
    
-   Tutorial videos
    
-   Cancelling your account
    
-   VOR
    
-   Installation
    
-   BIKLY
    

# How to block speeding alerts in certain location(s)

## First thing to do is to have the custom locations set in your account. Then, you will block the speeding events inside these locations.

1- Access the Location Module, on the Services menu.

  

2 - In the location module, search for the map location where speeding alerts will be ignored. For this action, you can use the search feature on the top-right of the map.

  

  

3 -  Then zoom in on the place you want to block speeding alerts and simply right-click or left-click on the desired location and choose the “Add as custom location” option.

  

4 - The system will display a menu on the left side of the map where you will enter the location’s name and select a group for it. In the example below we are creating a Toll group (this means you can add the different tolls around Ireland and group them with a tag). Then, click on “Save location” to confirm the creation.

  

  

**Note:**  When doing this creation, you can also change the poligon’s size and format to better fit it to the location by dragging its limits like in the example below:  

  

5 - After creating the custom location, you will need to log out and log in again to reload the cache of your browser.

  

6 - When logged in again, please access the settings option on the Driving Style module:

  
  

7 - Select the tab “Speed Summary Settings” and finally select the custom location group(s) that you want to block speeding alerts in this zone.

  

  

8 - Click on the option “Apply changes” to confirm them. Now, the system will automatically ignore all speed alerts from the location(s) selected.
