# How request video from a camera from a Journeys Report

Back to home

1.  Knowledge Base 
3.  Cameras 

-   Logging-in to your Transpoco account
    -   Login to your Transpoco account
    -   Transpoco Smartphone Apps
    -   2 Factor Authentication
    -   System requirements
    -   Overview of Transpoco
    -   Implementation
-   How to organise your account to achieve the best results
    
-   How to use each feature - step by step guides
    -   Users and permissions
    -   Walkaround Checks module
    -   Fuel/Electric Vehicles Module
    -   Maintain Module
    -   Dashboard
    -   Messaging module
    -   Scheduled Reports
-   How to Order More Trackers
    
-   Live Map
    
-   Cameras
    -   FAQ
-   Webinar Videos
    
-   Walkaround Checklists
    -   Walkaround Checklists
    -   Driver App
    -   Alerts
-   Reports
    -   Reports
    -   Viewing data in reports
-   Fuel
    
-   Dashboard
    
-   Maintain Module
    
-   Driving Style
    
-   Locations
    
-   Cost Management (TCO) Report
    
-   The Notification Features
    
-   Hardware and Installation
    
-   Removal & Repair of Hardware
    -   Requesting a Repair or a Deinstallation
-   Cameras & GDPR Guidelines
    
-   Scheduled Reports
    
-   Safety Program
    
-   Fleet Manager App
    
-   Users & Permissions
    
-   Alerts
    
-   Policies & Documents
    
-   Privacy Policy and Terms & Conditions
    -   RoPA
-   API
    
-   Transpoco User Manuals
    
-   Settings
    -   Garage
-   Whats New?
    
-   Account Mangement Services
    
-   Driver ID process
    
-   Security
    
-   Transpoco Locate
    
-   Subscriptions & Invoices
    
-   Tutorial videos
    
-   Cancelling your account
    
-   VOR
    
-   Installation
    
-   BIKLY
    

# How request video from a camera from a Journeys Report

## In this article we will explain how you can request video from a Journeys Report

1\. Run a Journeys report and then click the Route Playback icon beside the Journey you want to select.

Screenshot 1

2\. When you click Route Playback you will see the full list of GPS updates made during the journey. When you have identified the part of the journey you want to investigate click the camera icon to source the video footage.

Screenshot 2

3\. When you click the camera icon you will receive the following message below.

If the vehicle engine is on you the footage will accessible to download in a few minutes. If the engine is off you you will be notified when the engine is turned on.

Screenshot 4

4\. When the requested video footage is accessible you will receive an email notifying and you.

Screenshot 5

5\. After downloading the file the section of video footage you requested will be viewable.

Screenshot 6

6\. Your history of video requests is accessible in the 'Cameras' section of your Transpoco account and you can playback the videos from this page.

Screenshot 3
