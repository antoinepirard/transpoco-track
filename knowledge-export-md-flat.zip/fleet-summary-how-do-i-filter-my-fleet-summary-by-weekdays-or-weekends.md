# Fleet Summary - How do I filter my fleet Summary by Weekdays or Weekends?

Back to home

1.  Knowledge Base 
3.  Reports 
5.  Reports 

-   Logging-in to your Transpoco account
    -   Login to your Transpoco account
    -   Transpoco Smartphone Apps
    -   2 Factor Authentication
    -   System requirements
    -   Overview of Transpoco
    -   Implementation
-   How to organise your account to achieve the best results
    
-   How to use each feature - step by step guides
    -   Users and permissions
    -   Walkaround Checks module
    -   Fuel/Electric Vehicles Module
    -   Maintain Module
    -   Dashboard
    -   Messaging module
    -   Scheduled Reports
-   How to Order More Trackers
    
-   Live Map
    
-   Cameras
    -   FAQ
-   Webinar Videos
    
-   Walkaround Checklists
    -   Walkaround Checklists
    -   Driver App
    -   Alerts
-   Reports
    -   Reports
    -   Viewing data in reports
-   Fuel
    
-   Dashboard
    
-   Maintain Module
    
-   Driving Style
    
-   Locations
    
-   Cost Management (TCO) Report
    
-   The Notification Features
    
-   Hardware and Installation
    
-   Removal & Repair of Hardware
    -   Requesting a Repair or a Deinstallation
-   Cameras & GDPR Guidelines
    
-   Scheduled Reports
    
-   Safety Program
    
-   Fleet Manager App
    
-   Users & Permissions
    
-   Alerts
    
-   Policies & Documents
    
-   Privacy Policy and Terms & Conditions
    -   RoPA
-   API
    
-   Transpoco User Manuals
    
-   Settings
    -   Garage
-   Whats New?
    
-   Account Mangement Services
    
-   Driver ID process
    
-   Security
    
-   Transpoco Locate
    
-   Subscriptions & Invoices
    
-   Tutorial videos
    
-   Cancelling your account
    
-   VOR
    
-   Installation
    
-   BIKLY
    

# Fleet Summary - How do I filter my fleet Summary by Weekdays or Weekends?

## In Synx Live Map > Fleet Summary, you can filter the report by weekdays or weekends additionally based on the chosen period of date.

1\. After choosing the Fleet Summary as the report type, you can select a vehicle group and also the period for the report.

2\. In addition, you can select either weekdays or weekends based on the chosen period of the report.

Note: If you choose the “Weekend Only” option, the report will bring the data related to the weekends (only Saturday and Sunday) from the period selected. The “Weekdays only” option is taking into consideration Monday to Friday days from the period selected.

3.  Then, click to view the report    

4.  You can also download your report by clicking on the “export” button on the upper right corner of it.

Note: The report will be downloaded in XLS format or be sent via email.
