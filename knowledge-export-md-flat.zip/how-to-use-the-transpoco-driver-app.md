# How to use the Transpoco Driver App

Back to home

1.  Knowledge Base 
3.  Walkaround Checklists 
5.  Driver App 

-   Logging-in to your Transpoco account
    -   Login to your Transpoco account
    -   Transpoco Smartphone Apps
    -   2 Factor Authentication
    -   System requirements
    -   Overview of Transpoco
    -   Implementation
-   How to organise your account to achieve the best results
    
-   How to use each feature - step by step guides
    -   Users and permissions
    -   Walkaround Checks module
    -   Fuel/Electric Vehicles Module
    -   Maintain Module
    -   Dashboard
    -   Messaging module
    -   Scheduled Reports
-   How to Order More Trackers
    
-   Live Map
    
-   Cameras
    -   FAQ
-   Webinar Videos
    
-   Walkaround Checklists
    -   Walkaround Checklists
    -   Driver App
    -   Alerts
-   Reports
    -   Reports
    -   Viewing data in reports
-   Fuel
    
-   Dashboard
    
-   Maintain Module
    
-   Driving Style
    
-   Locations
    
-   Cost Management (TCO) Report
    
-   The Notification Features
    
-   Hardware and Installation
    
-   Removal & Repair of Hardware
    -   Requesting a Repair or a Deinstallation
-   Cameras & GDPR Guidelines
    
-   Scheduled Reports
    
-   Safety Program
    
-   Fleet Manager App
    
-   Users & Permissions
    
-   Alerts
    
-   Policies & Documents
    
-   Privacy Policy and Terms & Conditions
    -   RoPA
-   API
    
-   Transpoco User Manuals
    
-   Settings
    -   Garage
-   Whats New?
    
-   Account Mangement Services
    
-   Driver ID process
    
-   Security
    
-   Transpoco Locate
    
-   Subscriptions & Invoices
    
-   Tutorial videos
    
-   Cancelling your account
    
-   VOR
    
-   Installation
    
-   BIKLY
    

# How to use the Transpoco Driver App

## This article will explain how to use the Transpoco Driver app to submit a walkaround checklist.

### 1\. How to download the Transpoco Driver app

Download and install the **Transpoco Driver app** from Google Play or the App Store.

The app is free to download if you have access to the Walkaround module in your Transpoco account

### 2\. How to login to the Driver app

An Administrator will provide a driver with access to the Driver app through the Transpoco account.

The driver will receive a confirmation email and as part of the confirmation process the driver will create a password. The email address for the driver will serve as the username.

After the driver has confirmed their account open the app to the login page.

Enter the assigned **username** and **password** and tap on **Login**.

After you login for the first time your phone could offer you the opportunity to save the login details for future logins.

The very first time you log in, the app may take time to load to the home page.

IMG\_0375-1

### 3\. Opening the Driver app 

The Drivers app opens to the Walkaround home page which has a link to **perform a new walkaround check**, a link to view the vehicle history and the **Menu** (left image).

**Note:** Once you have completed a Walkaround report, the home page will include a link to view driver history and an option to repeat the last check (centre image).

To come back to this page from elsewhere in the app, tap on the **three horizontal lines** at the top left of the screen to access the drop-down menu and select ‘Walkaround’ (right image).

Screenshot\_20190725\_120322\_com.synx.driver     Screenshot\_20190727\_150357\_com.synx.driver     Screenshot\_20190725\_120330\_com.synx.driver          

### **4\. Submitting a walkaround checklist**

From the Walkaround Home Page, tap on **Start Walkaround**.

Either scroll down the full list of vehicles or search for a vehicle by typing in part or all of a registration number or vehicle/driver name in the search box.

Tap on the required vehicle.

Screenshot\_20190727\_145518\_com.synx.driver

In our demonstration account we have a lot of demonstration checklists. In most accounts, there will be 2 default checklists; **a HGV checklist and an LCV checklist**.

You can also create customised checklists, click here to learn more.

Screenshot\_20190725\_150619\_com.synx.driver

**Note:** For the purpose of this article, the **HGV** checklist has been selected. The HGV and LCV checklists are default checklists provided to each customer

Each checklist will differ, as customers to create their checklists to suit their requirements, but this article will demonstrate the experience of submitting a checklist.

You can also create customised walkaround checklists, **click here** to learn how to create a customised checklist.

When selecting the HGV checklist, you are presented with the option to start with the inside or the outside of the vehicle.

**Note:** For the purpose of this article, ‘Inside’ is selected first.

Screenshot\_20190725\_144936\_com.synx.driver

Select **Inside**.

There now follows a series of questions about the interior of the vehicle – each question must be answered to continue to the next, which will appear automatically.

For each question (except for those that require direct input, such as odometer reading), answer in the positive or negative.

**Note:** The app measures the time taken to answer each question and if it deems the time is too quick, it will produce a pop-up warning. This is to help ensure that the checks on the vehicle are being carried out.

Screenshot\_20190729\_182647\_com.synx.driver     Screenshot\_20190725\_142600\_com.synx.driver

If the response is **positive** (there are no defects), either tap on the **green tick** or **swipe right**.

The app will advance to the next question.

If the response is **negative** (there is a defect), either tap on the **red cross** or **swipe left**.

A Notes page will pop up and the app will ask for details on the defect.

Screenshot\_20190725\_145105\_com.synx.driver

As shown in the above image, type in brief notes about the defect found.

If relevant, add a photo of the defect by selecting **Photo**.

**NOTE:** For instructions on how to add a photo from your camera's library or by taking a photo, see Walkaround Checks: How do I add a photo to the Driver app?

Tap on the green **Save** button.

The app will automatically advance to the next question.

Screenshot\_20190725\_152517\_com.synx.driver

Continue with the rest of the questions for the interior check.

On the final question, enter the number of passengers there will be for that journey; enter 0 if there are no passengers.

After this last question, the app will take you to the Inside/ Outside menu. Select **Outside**.

There now follows a series of questions about the exterior of the vehicle – each question must be answered to continue to the next.

Follow the instructions as per the inside questions above.

When all checks have been completed, the app shows the following screen:

Screenshot\_20190731\_182931\_com.synx.driver

Type any comments or provide further details in the text box if desired.

To submit the checklist without reviewing, tap on **Submit Checklist**.

To review the checklist before submitting, tap on **Review Checklist**.

Scroll down to review each check.

Screenshot\_20190729\_183116\_com.synx.driver     Screenshot\_20190729\_183130\_com.synx.driver     Screenshot\_20190729\_183142\_com.synx.driver

Scroll down to review each declaration. Click on **Edit** for any item that requires amending or additional information.

Scroll to the end of the checklist and tap on **Submit Checklist**.

Screenshot\_20190725\_153432\_com.synx.driver

2) From the Walkaround Home Page, tap on **View Vehicle History**.

If the categories are not showing (as in right image), tap on **Filters** (left image).

Screenshot\_20190725\_122516\_com.synx.driver     Screenshot\_20190801\_180006\_com.synx.driver

Tap on **All Groups** if you want to select a vehicle group.

Select the vehicle group from the list, scrolling down or typing in all or part of the group name in the text box if required (the list will filter automatically).

Screenshot\_20190725\_122529\_com.synx.driver      Screenshot\_20190801\_180248\_com.synx.driver

Tap on **All Vehicles** if you want to select a specific vehicle in your chosen vehicle group.

Select the vehicle from the list, scrolling down or typing in all or part of the group name in the text box if required (the list will filter automatically).

Screenshot\_20190727\_145518\_com.synx.driver      Screenshot\_20190801\_180255\_com.synx.driver

**Note:** You do not need to select a vehicle group first, but for a large fleet this makes it easier to find a specific vehicle.

To change the dates from today’s date (default), tap on the **first** **date** (first image).

Screenshot\_20190801\_180255\_com.synx.driver NEW2     Screenshot\_20190801\_022917\_com.synx.driver     Screenshot\_20190801\_180311\_com.synx.driver

Tap on the required **start** **date** in the calendar and tap on **OK**.

From the Filters page, tap on the **second** **date** (first image below).

Screenshot\_20190801\_180311\_com.synx.driver NEW2     Screenshot\_20190801\_022938\_com.synx.driver    Screenshot\_20190801\_180322\_com.synx.driver

Tap on **View Vehicle History** from the filters page.

Screenshot\_20190801\_180421\_com.synx.driver

Scroll down to check that all checklists have been submitted.

**Note:** The paper plane icon denotes a checklist that has not yet been submitted.

If there is a checklist that needs submitting, follow the instructions for View Driver History if you were the driver, or contact the relevant driver to request they submit the checklist.

3) From the Walkaround Home Page, tap on **View Driver History**.

Screenshot\_20190725\_150702\_com.synx.driver

The table shows the checklists you have carried out, with the date and status.

Screenshot\_20190801\_180540\_com.synx.driver

Click on the eye to view that checklist.

If a checklist has not yet been submitted, tap on the **Submit** button.

4) Select **Repeat** from the Walkaround Home Page and carry out the checks as per the article  Walkaround Checks: How do I perform a walkaround vehicle check using the SynX Driver app? 

Screenshot\_20190727\_150357\_com.synx.driver
