# Transpoco Locate: How do I create an Idling Report?

Back to home

1.  Knowledge Base 
3.  Transpoco Locate 

-   Logging-in to your Transpoco account
    -   Login to your Transpoco account
    -   Transpoco Smartphone Apps
    -   2 Factor Authentication
    -   System requirements
    -   Overview of Transpoco
    -   Implementation
-   How to organise your account to achieve the best results
    
-   How to use each feature - step by step guides
    -   Users and permissions
    -   Walkaround Checks module
    -   Fuel/Electric Vehicles Module
    -   Maintain Module
    -   Dashboard
    -   Messaging module
    -   Scheduled Reports
-   How to Order More Trackers
    
-   Live Map
    
-   Cameras
    -   FAQ
-   Webinar Videos
    
-   Walkaround Checklists
    -   Walkaround Checklists
    -   Driver App
    -   Alerts
-   Reports
    -   Reports
    -   Viewing data in reports
-   Fuel
    
-   Dashboard
    
-   Maintain Module
    
-   Driving Style
    
-   Locations
    
-   Cost Management (TCO) Report
    
-   The Notification Features
    
-   Hardware and Installation
    
-   Removal & Repair of Hardware
    -   Requesting a Repair or a Deinstallation
-   Cameras & GDPR Guidelines
    
-   Scheduled Reports
    
-   Safety Program
    
-   Fleet Manager App
    
-   Users & Permissions
    
-   Alerts
    
-   Policies & Documents
    
-   Privacy Policy and Terms & Conditions
    -   RoPA
-   API
    
-   Transpoco User Manuals
    
-   Settings
    -   Garage
-   Whats New?
    
-   Account Mangement Services
    
-   Driver ID process
    
-   Security
    
-   Transpoco Locate
    
-   Subscriptions & Invoices
    
-   Tutorial videos
    
-   Cancelling your account
    
-   VOR
    
-   Installation
    
-   BIKLY
    

# Transpoco Locate: How do I create an Idling Report?

## How to run a report on idling events in Locate.

Idling is classified as ignition on but the vehicle not moving (speed of vehicle is zero). An Idling Report shows the location and duration of all idling.

**Note:** If you require more detailed information about how to run the report, see How do I create a report?.

1.  Select the **Vehicle(s)**.
2.  Select ‘Idling’ from the **Reports** drop-down.
3.  Select the **date**.
4.  Click on the **View Report**.

The idling duration for the fleet (or selected group of vehicles) is in the pink row.

The standard information contained in this report covers the following for each day during the selected period:

-   Idling Start: The time (in hours & minutes) the vehicle stopped with engine on
-   Location: Where the idling event occurred
-   Idling Stop: The time (in hours & minutes) the vehicle starting moving
-   Idling Duration: Length of time (in hours & minutes) the vehicle stopped with engine on
-   Event: Engine on, speed zero
-   Map: View the location of the idling on the map
-   Street View: View the location of the idling in Street View

In addition, the Idling Report can be filtered to only display idling events greater or lesser than a certain length of time in minutes. The default is greater than 1 minute.

1.  Click on the **down arrow** and select either > (greater than) or < (less than).
2.  Type the number of minutes in the text box.
3.  Click on the green **refresh icon**.

The table will be refreshed with the filtered data.

To export the data as .csv or .xls format, click on the **Export** icon above the far right column. For more information, see How do I export a report? 

### View all idling events on the map

In Table view, click on the **Map**.

The map will include all the idling events specified in the Report Generator and Duration filter.

Idling events may be clustered on the map when viewing the area small scale.

Use the Google tools to zoom in to see the stop locations individually.

To see details of the idling (vehicle/driver, location, idling start and end times, and duration), hover the cursor over the blue pin and the details will pop up.

To scroll through the idling events, click on **Previous Idling** or **Next Idling**.

To view the map in full screen, click on the **Full Screen** icon in the top left-hand corner.

To exit the full screen mode, click on the icon again or press the **ESC** key on your keyboard.

### View idling individually on the map

To view an individual idling location on the map, click the **Map** icon (blue pin) at the end of the row in the table. The blue pin bounces up and down over the duration time, and the vehicle and location details are in the status bar.

**Tip:** Turning on the OSM layer can give more information about the idling location (in this case, the vehicle has been idling by a cemetery for 16 minutes).

To scroll through the idling events on the map, click on **Previous Idling** or **Next Idling**.

To view the map in full screen, click on the **Full Screen** icon in the top left-hand corner.

To return to the table view, click on the **Table**.

To view an individual idling location in Street View, click **Pegman** at the end of the row or drag and drop Pegman onto the map.

To scroll through the idling events in Street View, click on **Previous Idling** or **Next Idling**.

To view the map in full screen, click on the **Full Screen** icon in the top left-hand corner.

To return to the Map view, click the **left** **arrow** in the left-hand corner of the screen.

To return to the Table view, click on the **Table** tab.
