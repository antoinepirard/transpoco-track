# [Fleet Summary Scheduled Report] - How to add additional vehicle columns to your Fleet Summary Schedule Report?

Back to home

1.  Knowledge Base 
3.  Reports 
5.  Reports 

-   Logging-in to your Transpoco account
    -   Login to your Transpoco account
    -   Transpoco Smartphone Apps
    -   2 Factor Authentication
    -   System requirements
    -   Overview of Transpoco
    -   Implementation
-   How to organise your account to achieve the best results
    
-   How to use each feature - step by step guides
    -   Users and permissions
    -   Walkaround Checks module
    -   Fuel/Electric Vehicles Module
    -   Maintain Module
    -   Dashboard
    -   Messaging module
    -   Scheduled Reports
-   How to Order More Trackers
    
-   Live Map
    
-   Cameras
    -   FAQ
-   Webinar Videos
    
-   Walkaround Checklists
    -   Walkaround Checklists
    -   Driver App
    -   Alerts
-   Reports
    -   Reports
    -   Viewing data in reports
-   Fuel
    
-   Dashboard
    
-   Maintain Module
    
-   Driving Style
    
-   Locations
    
-   Cost Management (TCO) Report
    
-   The Notification Features
    
-   Hardware and Installation
    
-   Removal & Repair of Hardware
    -   Requesting a Repair or a Deinstallation
-   Cameras & GDPR Guidelines
    
-   Scheduled Reports
    
-   Safety Program
    
-   Fleet Manager App
    
-   Users & Permissions
    
-   Alerts
    
-   Policies & Documents
    
-   Privacy Policy and Terms & Conditions
    -   RoPA
-   API
    
-   Transpoco User Manuals
    
-   Settings
    -   Garage
-   Whats New?
    
-   Account Mangement Services
    
-   Driver ID process
    
-   Security
    
-   Transpoco Locate
    
-   Subscriptions & Invoices
    
-   Tutorial videos
    
-   Cancelling your account
    
-   VOR
    
-   Installation
    
-   BIKLY
    

# \[Fleet Summary Scheduled Report\] - How to add additional vehicle columns to your Fleet Summary Schedule Report?

## You can add extra columns with Vehicle information to the Fleet Summary Schedule Report in your account now.

1.  Log in to your Transpoco account.
2.  Click the Services > Analytics > Scheduled Reports.

 3.   You will see the Scheduled Report page. 

  4.   Then click on the “+ Add New Schedule Report” .

  5.   Firstly, you need to add a subject and a description.

  6.   Then select the Report Types.   

  7.  Then you can add different vehicle groups or all vehicles.  

  8.  Then click on the “Next” .

  9.   Then set up the following options, Schedule period, Schedule Time, Report Language, Time Zone and Distance Unit.

  
  10.   Then select CSV as the File Format. 

**The next step is where you can add extra columns to the schedule report.**

 11.   Then a new option “Extra Columns (Fleet Summary Report)” will appear at the bottom. Then you can add extra columns with Vehicle information to your scheduled report.

 12.   Then click on the “Next” again.  

 13.   Then choose the users who would like to receive the report based on scheduled period and time; as well as the users who can manage the schedule report.   

 14.   Click on the “Confirm” once you are done.

 15.   Then you will receive the customized schedule report (Fleet Summary Report) via email, including the extra columns you have added previously. 

 16.   You can always edit, view history and delete the reports. .

**Note:** You can view more detailed instructions regarding the overall Schedule report feature in this article.
