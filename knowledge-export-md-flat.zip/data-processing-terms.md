# Data Processing Terms

Back to home

1.  Knowledge Base 
3.  Privacy Policy and Terms & Conditions 

-   Logging-in to your Transpoco account
    -   Login to your Transpoco account
    -   Transpoco Smartphone Apps
    -   2 Factor Authentication
    -   System requirements
    -   Overview of Transpoco
    -   Implementation
-   How to organise your account to achieve the best results
    
-   How to use each feature - step by step guides
    -   Users and permissions
    -   Walkaround Checks module
    -   Fuel/Electric Vehicles Module
    -   Maintain Module
    -   Dashboard
    -   Messaging module
    -   Scheduled Reports
-   How to Order More Trackers
    
-   Live Map
    
-   Cameras
    -   FAQ
-   Webinar Videos
    
-   Walkaround Checklists
    -   Walkaround Checklists
    -   Driver App
    -   Alerts
-   Reports
    -   Reports
    -   Viewing data in reports
-   Fuel
    
-   Dashboard
    
-   Maintain Module
    
-   Driving Style
    
-   Locations
    
-   Cost Management (TCO) Report
    
-   The Notification Features
    
-   Hardware and Installation
    
-   Removal & Repair of Hardware
    -   Requesting a Repair or a Deinstallation
-   Cameras & GDPR Guidelines
    
-   Scheduled Reports
    
-   Safety Program
    
-   Fleet Manager App
    
-   Users & Permissions
    
-   Alerts
    
-   Policies & Documents
    
-   Privacy Policy and Terms & Conditions
    -   RoPA
-   API
    
-   Transpoco User Manuals
    
-   Settings
    -   Garage
-   Whats New?
    
-   Account Mangement Services
    
-   Driver ID process
    
-   Security
    
-   Transpoco Locate
    
-   Subscriptions & Invoices
    
-   Tutorial videos
    
-   Cancelling your account
    
-   VOR
    
-   Installation
    
-   BIKLY
    

# Data Processing Terms

## You can find all detailed information regarding how we process your personal data within this article.

**Acceptance of the Agreement.** By signing the digital signature on the initial Order and clicking the “I Accept” button, the Customer accepts this Agreement. All subsequent purchases shall be also subject to this Agreement.  “Agreement” as used herein includes our Data Processing Terms and any other referenced policies and attachments.

**INTRODUCTION**

This document explains what information E-pire limited, trading as Transpoco, collects about you and why, what we do with that information, how we share it, and how we handle the content you place in our products and services. It also explains the choices available to you regarding our use of your personal information and how you can access and update this information.

#### **DEFINITIONS**

-   **Content:** any information or data that you upload, submit, post, create, transmit, store, or display in Transpoco Services.
-   **Device**: any computer used to access the Transpoco Services, including without limitation a desktop, laptop, mobile phone, or tablet.
-   **Data Protection Legislation:** the Data Protection Acts 1988 and 2003 and, with effect from 25 May 2018, the General Data Protection Regulation (EU) 2016/679 and any legislation implementing Regulation (EU) 2016/679.
-   **Transpoco Services:** Transpoco’s products and/or services provided.
-   **Personal Information:** information that may be used to readily identify or contact you as an individual person, such as name, address, email address, or phone number. Personal Information does not include information that has been anonymized such that it does not allow for the ready identification of specific individuals.
-   **Controller:** the natural or legal person, public authority, agency, or any other body which alone or jointly with others determines the purposes and means of the processing of personal data as meant in the Data Protection Law.
-   **GDPR:** The General Data Protection Regulation (GDPR), which went into effect May 25, 2018. The regulation contains the most significant changes to European data privacy legislation in the last 20 years, replacing European Privacy Directive 95/46/EC. It is designed to give EU citizens more control over their data and seeks to unify a number of existing privacy and security laws under one comprehensive law.

#### **SCOPE OF THESE DATA PROCESSING TERMS**

These Data Processing Terms apply to the information that we obtain through your use of "Transpoco Services" via a "Device" or when you otherwise interact with Transpoco. We will not collect any personal data about you without your permission or other than in accordance with the Data Protection Legislation.

Transpoco will only process personal data received from you according to these Data Processing Terms.

By registering for or using Transpoco Services you consent to the collection, transfer, processing, storage, disclosure, and other uses described in this document.

The terms defined in Transpoco’s GDPR page are also part of these Data Processing Terms.

**Information you provide to us**

Account and Profile Information: Transpoco respects the rights of users of our Services and is committed to protecting your privacy in accordance with Data Protection Legislation at all times. We collect information about you and your company as you register for an account, create or modify your profile, make purchases, use, access, or interact with Transpoco Services (including but not limited to when you upload, download, collaborate on, or share Content). Information we collect includes:

-   Contact information such as name, email address, mailing address, and phone number
-   Any financial data is handled by a 3rd party provider who has been audited by a PCI-certified auditor and is certified to PCI Service Provider Level 1 standard. Last card details will be kept to help in future purchases. But you do have the right to request the use of a different card in your purchases.

You may provide this information when you talk to the Transpoco Sales or Support Team.

In some cases, another user (such as a system administrator) may create an account on your behalf and may provide your information, including Personal Information (most commonly when your company requests that you use our products). We collect Information under the direction of our customers and often have no direct relationship with the individuals whose personal data we process.

If you are an employee of one of our customers and would no longer like us to process your information, we recommend you contact your employer. But if you want to contact us directly please be aware we will contact your employer as part of our internal security checking

If you are providing information (including Personal Information) about someone else, you must have the authority to act for them and to consent to the collection and use of their Personal Information as described in these Data Processing Terms. The person who signed the contract is responsible for requests regarding data management.

Content: We collect and store Content that you create, input, submit, post, upload, transmit, store, or display in the process of using our products. Such Content includes any personal information or other sensitive information that you choose to include.

If you have drivers that are using their vehicle for both business and private use, those drivers should have the option to activate a privacy mode for private driving. If your drivers are doing some private driving and you have no privacy switch currently installed, please contact us and we can set this up for you.

**Information we collect from your use of Transpoco Services**

Analytics Information Derived from Content: Analytics information also consists of data we collect as a result of running queries against Content across our user base for the purposes of generating Usage Data. "Usage Data" is aggregated data about a group or category of services, features, or users that may contain Personal Information. For example, the Journeys Report may contain Driver identification.

**Information we collect from other sources**

Information from third-party services: We also obtain information from third parties and combine that with information we collect through Transpoco Services. For example, trackers send data to a third-party supplier which sends this data to our servers. Any access that we have to such information from a third party is in accordance with the authorization procedures determined by that service. By authorizing us to connect with a third-party service, you authorize us to access and store the data that the third-party service makes available to us and to use and disclose it in accordance with this document.

**How we use the Information we collect**

General Uses: We use the Information we collect about you (including Personal Information to the extent applicable) for a variety of purposes, including:

-   Provide, operate, maintain, improve, and promote Transpoco Services;
-   Enable you to access and use Transpoco Services, including uploading, downloading, collaborating on, and sharing Content;
-   Process and complete transactions, and send you related information, including purchase confirmations and invoices;
-   Send transactional messages, including responding to your comments, questions, and requests; providing customer service and support; and sending you technical notices, updates, security alerts, and support and administrative messages;
-   Make extensive use of analytics information (including log and configuration data) to understand how our products are being configured and used, how they can be improved for the benefit of all of our users, and to develop new products and services. As such we generate data from the analytics logs described above, including the content elements captured in such logs, as well as from the content stored in the Products.

You can find the complete list of processing activities (ROPA) here.

Notwithstanding the foregoing, we will not use personal information appearing in our Analytics Logs for any purpose other than the purposes disclosed in this policy.

Transpoco ensures the staff who access and process Transpoco customer personal data have been trained in handling that data and are bound to maintain the confidentiality and security of that data.

**Information sharing and disclosure**

We will not share or disclose any of your Personal Information or Content with third parties except as described in this policy. We do not sell your Personal Information or Content. If Data Subjects, competent authorities, or any other third parties request information from us regarding the processing of Personal Information covered by this Agreement, we shall refer such request to you as soon as possible and no later than 24 hours after receipt of such request. 

Aggregated or Anonymized Data: Transpoco may use vehicle data to create an anonymised traffic data product. This product is used to display real-time and historic traffic movement. Speed and location data is gathered from individual vehicles, the data is anonymised so the vehicle, company, and driver cannot be recognised. This anonymised product may be sold to third parties. No individual vehicle or driver data is visible to the third party.

You should be aware that the account administrator of your instance of Transpoco Services may be able to:

-   access information in and about your Transpoco Services account;
-   access communications history, including file attachments, for your Transpoco Services account;
-   disclose, restrict, or access information that you have provided or that is made available to you when using your Transpoco Services account, including your content; and
-   control how your Transpoco Services account may be accessed or deleted.

Service Providers, Business Partners, and Others: We work with third-party service providers to provide website, application development, hosting, maintenance, backup, storage, virtual infrastructure, payment processing, analysis, and other services for us. These service providers may have access to or process your Information for the purpose of providing those services for us. Some of our pages utilize white-labeling techniques to serve content from our service providers while providing the look and feel of our site. Please be aware that you are providing your Information to these third parties acting on behalf of Transpoco. You can find the complete and most up-to-date list of our sub-processors here. 

International transfers to third parties: Some of the third parties described in this document, which provide services to us under contract, are based in other countries that may not have equivalent privacy and data protection laws to the country in which you reside. When we engage in such transfers, we use a variety of legal mechanisms to help ensure your rights and protections travel with your data, at least one of the following safeguards is implemented:

-   We will only transfer your Personal Data to countries that have been deemed to provide an adequate level of protection for Personal Data by the European Commission. The full list of these countries is available here.
    
-   Where we use certain service providers, we may use specific contracts approved by the European Commission which give Personal Data the same protection it has in Europe.
    
-   Where we use providers based in the US, we may transfer data to them if the appropriate Standard Contract Clauses (SCCs) are in place which require them to provide similar protection to Personal Data shared between Europe and the US.
    
-   We will implement supplementary measures where appropriate, including additional security measures to ensure adequate protection for Personal Data in line with our obligations as a responsible data controller.
    

Compliance with Laws and Law Enforcement Requests; Protection of Our Rights: We may disclose your Information (including your Personal Information) to a third party if (a) we believe that disclosure is reasonably necessary to comply with any applicable law, regulation, legal process or governmental request, (b) to enforce our agreements, policies, and terms of service, (c) to protect the security or integrity of Transpoco’s products and services, (d) to protect Transpoco, our customers or the public from harm or illegal activities, or (e) to respond to an emergency which we believe in the good faith requires us to disclose information to assist in preventing the death or serious bodily injury of any person.

We will inform you of such legal requirement prior to such processing, unless a law of the European Union or a Member State to which we are subject prohibits it from doing so or we intend to disclose Personal Data to any Supervisory authority or other competent public authority.

We shall immediately inform you, if in our opinion, an instruction infringes the Data Protection Laws or if we become aware of any circumstance or change in applicable Data Protection Law that is likely to have a substantial adverse effect on our ability to meet its obligations.

Customer data may be used as part of development and testing of Transpoco products.

**Data storage, transfer, and security**

Transpoco hosts data with an ISO27001 compliant hosting company based in the EU region. The servers on which Personal Information is stored are kept in a controlled environment. While we take reasonable efforts to guard your Personal Information, no security system is impenetrable and due to the inherent nature of the Internet as an open global communications vehicle, we cannot guarantee that information, during transmission through the Internet or while stored on our systems or otherwise in our care, will be absolutely safe from intrusion by others, such as hackers. In addition, we cannot guarantee that any incidentally-collected Personal Information you choose to store in our Products are maintained at levels of protection to meet specific needs or obligations you may have relating to that information.

Transpoco implements security procedures to help protect your data from security attacks. However, you understand that use of the Hosted Services necessarily involves transmission of your data over networks that are not owned, operated, or controlled by us, and we are not responsible for any of your data lost, altered, intercepted, or stored across such networks. We cannot guarantee that our security procedures will be error-free, that transmissions of your data will always be secure or that unauthorized third parties will never be able to defeat our security measures or those of our third-party service providers.

Transpoco hereby disclaims, as far as permitted by local laws, any liability for itself and its affiliates and contractors for any Personal Data we collect in connection with your application that is lost, misused, illegally accessed, disclosed, altered, or destroyed, or not timely delivered to our Site.

Where data is transferred over the Internet as part of our Products, the data is encrypted using industry standard SSL (HTTPS). We are taking all steps reasonably necessary to ensure that your data is treated securely and in accordance with Data Protection Legislation.

The Customer will take responsibility for any data exported from the system via user interface download or via API.

The Supplier shall notify the Controller without undue delay, and in any case within twenty-four (24) hours, after becoming aware of a Personal Data Breach. 

In the event of a Personal Data Breach, the Supplier shall promptly take adequate remedial measures. Furthermore, the Supplier shall fully cooperate with Controller to develop and execute a response plan to address the Personal Data Breach taken and provide Controller with a copy thereof.  

**Accessing and updating your information**

You may often correct, update, amend, or remove your Personal Information in your account settings or by directing your query to your account administrator. You may also contact our Support Team who will initially respond to your request for access within 1 week. The request can be made in writing (email or support ticket). If made orally, Transpoco will record the time and details of the request verbally made and follow it up with individuals in writing (email or support ticket) to confirm that they have correctly understood the request.

You can often remove content using editing tools associated with that content. In some cases, you may need to contact your account administrator to request they remove the content. You can contact us to request removal of Personal Information from Transpoco services.

Data might not have to be erased if any of the following applies:

-   The "right of freedom of expression";
-   For supporting legal claims.

Any data on backup will be deleted within 30 days.

You or your account administrator may be able to deactivate your Transpoco Services account. If you can deactivate your own account, you can most often do so in your account settings. Otherwise, please contact your account administrator. To deactivate an organization account or an account made for you without authorization, please contact our Support Team.

Upon deactivation of an organization account, Supplier shall, at the option of Controller, return the Personal Data and copies thereof to Controller and/or shall securely destroy such Personal Data, except to the extent the Agreement or applicable law provides otherwise. In that case, we shall no longer Process the Personal Data, except to the extent required by the Agreement or applicable law. 

By default, we will retain your account information for as long as your account is active, or as reasonably useful for commercial purposes or as necessary to comply with our legal obligations, resolve disputes, and enforce our agreements. Otherwise, your account and data will be deleted 30 days after account cancellation. 

If your account is managed by an account administrator, that account administrator may have control with regards to how your account information is retained and deleted.

**Our policy towards children**

Transpoco services are not directed to individuals under 13. We do not knowingly collect Personal Information from children under 13. If we become aware that a child under 13 has provided us with Personal Information, we will take steps to delete such information. If you become aware that a child has provided us with Personal Information, please contact our Support Team.

**Transpoco has a privacy complaints process**

If you wish to complain about how we have handled your personal information, please provide our Support Team with full details of your complaint and any supporting documentation by opening a Support Ticket or chat through your SynX product.

After full details are provided, our Data Protection Officer (DPO) will endeavour to:

-   provide an initial response to your query or complaint within 10 business days, and
-   investigate and attempt to resolve your query or complaint within 30 business days or such longer period as is necessary and notified to you by our Data Protection Office.

**How can I request Transpoco’s ISO 27001:2013 and ISO 9001:2015 certificates?**

You can reach out to Transpoco’s Support team for the certificate.

**This policy may be updated from time to time**

Transpoco reserves the right to change this Policy at any time, and any amended Policy is effective upon posting to this Website. Transpoco will make every effort to communicate any significant changes to you via email or notification inside Transpoco’s Products. Your continued use of the Service will be deemed acceptance of any amended Policy.

If you disagree with any changes to these Data Processing Terms, you will need to stop using Transpoco Services and deactivate your account(s).

Last updated: January 2022
