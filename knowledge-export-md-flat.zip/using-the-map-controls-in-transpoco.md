# Using the map controls in Transpoco

Back to home

1.  Knowledge Base 
3.  Logging-in to your Transpoco account 
5.  Overview of Transpoco 

-   Logging-in to your Transpoco account
    -   Login to your Transpoco account
    -   Transpoco Smartphone Apps
    -   2 Factor Authentication
    -   System requirements
    -   Overview of Transpoco
    -   Implementation
-   How to organise your account to achieve the best results
    
-   How to use each feature - step by step guides
    -   Users and permissions
    -   Walkaround Checks module
    -   Fuel/Electric Vehicles Module
    -   Maintain Module
    -   Dashboard
    -   Messaging module
    -   Scheduled Reports
-   How to Order More Trackers
    
-   Live Map
    
-   Cameras
    -   FAQ
-   Webinar Videos
    
-   Walkaround Checklists
    -   Walkaround Checklists
    -   Driver App
    -   Alerts
-   Reports
    -   Reports
    -   Viewing data in reports
-   Fuel
    
-   Dashboard
    
-   Maintain Module
    
-   Driving Style
    
-   Locations
    
-   Cost Management (TCO) Report
    
-   The Notification Features
    
-   Hardware and Installation
    
-   Removal & Repair of Hardware
    -   Requesting a Repair or a Deinstallation
-   Cameras & GDPR Guidelines
    
-   Scheduled Reports
    
-   Safety Program
    
-   Fleet Manager App
    
-   Users & Permissions
    
-   Alerts
    
-   Policies & Documents
    
-   Privacy Policy and Terms & Conditions
    -   RoPA
-   API
    
-   Transpoco User Manuals
    
-   Settings
    -   Garage
-   Whats New?
    
-   Account Mangement Services
    
-   Driver ID process
    
-   Security
    
-   Transpoco Locate
    
-   Subscriptions & Invoices
    
-   Tutorial videos
    
-   Cancelling your account
    
-   VOR
    
-   Installation
    
-   BIKLY
    

# Using the map controls in Transpoco

## How to navigate the map in Transpoco?

Our Maps are powered by Google Maps Premier. You can navigate (move your view) in three dimensions in any Google Map – up/down, left/right and zoom in/out.

### Panning the map

To pan the map up/down or left/right, click the hand cursor on the map and hold it while dragging the map.

**Note:** If you click but don’t drag straight away, a **location menu** may pop up; close this by clicking the **X** in the right-hand corner of the pop-up box.

Pop up location menu

If you are using a touch screen device, pan the map using your finger or stylus.

### Zoom in/out of the map

To zoom in and out the map, you can:

-   Use the ‘+’ and ‘-’ Google icons
-   Use the mouse tracker wheel
-   Spread/pinch on a touch screen
-   or use any other interface control

To zoom into Street View, grab and drag **Pegman** to the required location.

Google map controls

### View map full screen

Click on the window icon in the top right of the map to view it full screen.

Toggle to full screen

To exit full screen, either:

-   Press the **ESC** key on your keyboard, or
-   Click on the window icon again.

Toggle to reduced screen
