# How to use the Fuel/Electric Vehicles module - Fuel Reports

Back to home

1.  Knowledge Base 
3.  How to use each feature - step by step guides 
5.  Fuel/Electric Vehicles Module 

-   Logging-in to your Transpoco account
    -   Login to your Transpoco account
    -   Transpoco Smartphone Apps
    -   2 Factor Authentication
    -   System requirements
    -   Overview of Transpoco
    -   Implementation
-   How to organise your account to achieve the best results
    
-   How to use each feature - step by step guides
    -   Users and permissions
    -   Walkaround Checks module
    -   Fuel/Electric Vehicles Module
    -   Maintain Module
    -   Dashboard
    -   Messaging module
    -   Scheduled Reports
-   How to Order More Trackers
    
-   Live Map
    
-   Cameras
    -   FAQ
-   Webinar Videos
    
-   Walkaround Checklists
    -   Walkaround Checklists
    -   Driver App
    -   Alerts
-   Reports
    -   Reports
    -   Viewing data in reports
-   Fuel
    
-   Dashboard
    
-   Maintain Module
    
-   Driving Style
    
-   Locations
    
-   Cost Management (TCO) Report
    
-   The Notification Features
    
-   Hardware and Installation
    
-   Removal & Repair of Hardware
    -   Requesting a Repair or a Deinstallation
-   Cameras & GDPR Guidelines
    
-   Scheduled Reports
    
-   Safety Program
    
-   Fleet Manager App
    
-   Users & Permissions
    
-   Alerts
    
-   Policies & Documents
    
-   Privacy Policy and Terms & Conditions
    -   RoPA
-   API
    
-   Transpoco User Manuals
    
-   Settings
    -   Garage
-   Whats New?
    
-   Account Mangement Services
    
-   Driver ID process
    
-   Security
    
-   Transpoco Locate
    
-   Subscriptions & Invoices
    
-   Tutorial videos
    
-   Cancelling your account
    
-   VOR
    
-   Installation
    
-   BIKLY
    

# How to use the Fuel/Electric Vehicles module - Fuel Reports

## In this article we will explain the reports available in your Transpoco account for fuel and electric vehicles.

#### How to find the Fuel Reports

To access the fuel reports click on the **Services Menu** options under Fuel OR click on **Fuel/Electric Vehicles**

**Fuel/Electric Vehicles**

#### **1\. EV Suitability Report**

You can find the details of this report here

#### **2\. EV Charging**

You can find the details of this report here.

#### **3\. Fuel Transactions**

You can find all details about Fuel Transactions here.

#### **4\. Fuel Consumption Summary**

Fuelconsumption summary-1

**Column headings in the Fuel Consumption Report:**

**Vehicle:** Displays the vehicle registration

**Refills:** The number of refills during the selected time range

**Refills Quantity (L):** The total number of refill litres  

**Distance:** The distance the vehicle covers between the 1st fill and the 1st refill and the following refills during the selected time range.

**Consumption Ratio**: The consumption ratio is expressed as L/100KM. The ratio is the total number of refill litres divided by distance multiplied by 100/1.

**Consumption Target:**  The purpose of this column is to allow you to enter the expected consumption of the vehicle. **Click here to view a video which demonstrates how to enter a fuel consumption target**. Consumption targets can be found online, we suggest you try Fuelly.com which gathers consumptions targets for most vehicle models.

**Carbon Footprint:**  See the **Carbon Footprint Calculations** report below for an explanation of the Carbon Footprint.

**How is Fuel Consumption calculated?**

Example: Between 01/01/2021 and 31/03/2021 vehicle X is responsible for 12 fuel transactions. **A fuel consumption report will only consider the refills;**  the 2nd fuel transaction up to the 12th fuel transaction. The 1st fill is excluded as this is the starting point.

The report will then consider the distance between the vehicle leaving the location of the 1st fill and distance to the 1st refill and all refills up to the 11th fill.

Using the total number of refill litres and distance between refills we generate fuel consumption.  **Refill Litres/Distance x 100/1 = Actual Fuel Consumption**

A Fuel Consumption Summary report will only display vehicles which are responsible for 1 or more refills during the selected time range. **If a vehicle does not appear in fuel consumption report the most likely explanation is the vehicle was involved in 1 transaction - there were no refills.**

#### **5\. Fuel Consumption**

#### **fuelconsumption**

The Fuel Consumption Report is a more detailed version of the Fuel Consumption Summary. In this report we display the details of each refill transaction for each vehicle during the selected time range. 

We also display the location of the fuel station involved in each transaction.

Using the litres from the fuel transactions and the distance we track we can produce a L/100km or MPG figure for each vehicle for a selected time period.

#### **6\. Fuel Purchase Summary**

In this report you will find a link to all the purchases made and the total of distance driven by vehicle for the period selected. You can also export it as usual. The objective of this report is to show the **total purchases** made not the consumption over the period selected.

Once you click on the quantity link in blue, the system will show you the transactions related:

#### **7\. Fuel Transactions GPS Verified**

**gpstransactions-1**

**GPS Verified (Green) -** Represents fuel transactions automatically or manually assigned to a vehicle registration

**GPS Not Verified (Red) -** Represents transactions not assigned to a registrations; these transactions with either the status **'No vehicle assigned'** or **'No station found'.**

To ensure accurate fuel consumption reports try to assign a registration to every transaction and achieve 100% verified transactions. 

The default option is the last 4 weeks but click **View Report** to change the time range.  In the example above the chart displays the 'last 6 weeks' view.

You can also select the fuel transactions linked to vehicles in a specific vehicle group.

Below the chart we display the percentages in a table format- see the example below: 

gpstransactionspercentage

#### **8\. Carbon Footprint Calculations**

The Carbon Footprint Calculations report displays the carbon generated during the selected period by the fuel types below:

-   Diesel
-   Petrol 
-   Natural Gas
-   Electricity
-   HVO
-   Unknown Fuel type (this includes AdBlue)

The Carbon Footprint column is displayed in Kilograms. In the example below, the selected time range is the 'last 6 months'.

Fuel-Control (9)

In each week or month (depending on the selected time range) we breakdown the total number of litres / Kg / KWh purchased. 

In the bottom half of the Carbon Footprint Calculations report we display the same detail in table format - see the example below:

Fuel-Control (9)-1

**How is the Carbon Footprint calculated?**

First of all, what is the Carbon Footprint? According to the World Heath Organisation, *''a carbon footprint is a measure of the impact your activities have on the amount of carbon dioxide (CO2) produced through the burning of fossil fuels and is expressed as a weight of CO2 emissions produced in tonnes''.*

**For each litre of diesel 2.7kg of CO2 is generated.**

**For each litre of petrol 2.3kg of CO2 is generated.**

**For each kilo of natural gas 2.4kg of CO2 is generated.**

**For each kWh of electricity 0.2958kg of CO2 is generated.**

**For each litre of HVO 0.35kg of CO2 is generated.**

#### **9\. Settings**

9.1 Fuel Accounts

You can find all the details about Fuel Accounts here.

9.2 Fuel Cards

You can find all the details about Fuel Cards here.
