# Driver FAQ - AI cameras

Back to home

1.  Knowledge Base 
3.  Cameras 
5.  FAQ 

-   Logging-in to your Transpoco account
    -   Login to your Transpoco account
    -   Transpoco Smartphone Apps
    -   2 Factor Authentication
    -   System requirements
    -   Overview of Transpoco
    -   Implementation
-   How to organise your account to achieve the best results
    
-   How to use each feature - step by step guides
    -   Users and permissions
    -   Walkaround Checks module
    -   Fuel/Electric Vehicles Module
    -   Maintain Module
    -   Dashboard
    -   Messaging module
    -   Scheduled Reports
-   How to Order More Trackers
    
-   Live Map
    
-   Cameras
    -   FAQ
-   Webinar Videos
    
-   Walkaround Checklists
    -   Walkaround Checklists
    -   Driver App
    -   Alerts
-   Reports
    -   Reports
    -   Viewing data in reports
-   Fuel
    
-   Dashboard
    
-   Maintain Module
    
-   Driving Style
    
-   Locations
    
-   Cost Management (TCO) Report
    
-   The Notification Features
    
-   Hardware and Installation
    
-   Removal & Repair of Hardware
    -   Requesting a Repair or a Deinstallation
-   Cameras & GDPR Guidelines
    
-   Scheduled Reports
    
-   Safety Program
    
-   Fleet Manager App
    
-   Users & Permissions
    
-   Alerts
    
-   Policies & Documents
    
-   Privacy Policy and Terms & Conditions
    -   RoPA
-   API
    
-   Transpoco User Manuals
    
-   Settings
    -   Garage
-   Whats New?
    
-   Account Mangement Services
    
-   Driver ID process
    
-   Security
    
-   Transpoco Locate
    
-   Subscriptions & Invoices
    
-   Tutorial videos
    
-   Cancelling your account
    
-   VOR
    
-   Installation
    
-   BIKLY
    

# Driver FAQ - AI cameras

## Driver's Frequently Asked Questions regarding AI cameras.

### **FAQs:**

1.  Why are we installing cameras?
2.  Why is there a camera facing me as I drive?
3.  Why is there such a focus on safety, I am an excellent driver?
4.  Why is there such a focus on safety, I am an excellent driver?
5.  How long is the footage stored?
6.  How does the camera work?

### **Answers:** 

1.  **Why are we installing cameras?**  
    Camera technology is being installed to reduce our risk on the road. We have selected cameras that have artifcial intelligence features that will detect driving risk and generate alerts. We expect the technology to reduce the number of accidents. In the event of us having an accident, we will also have video evidence of the incident that will be valuable in terms of our investigation.
2.  **Why is there a camera facing me as I drive?**  
    The camera facing the driver is important for detecting risk. It contains AI technology and detects risks as you driver, for example distration, fatigure, talking on a mobile phone, etc.
3.  **Why is there such a focus on safety, I am an excellent driver?**  
    In a fleet risk is spread across all of the drivers and vehicles. We are employing this technology and policies in order to redce risk across the whole fleet.
4.  **Why is there such a focus on safety, I am an excellent driver?**  
    Your company have access to the account and control who has access to data. Information about who has access to the data will be contained in your fleet policy.
5.  **How long is the footage stored?**  
    The footage is stored on the camera for roughly 80 hours, this depends on the subject being recorded. The oldest footage stored on the camera is over written as new footage is recorded. It means the footage is erased as needed on a FIFO basis so that at any given time, the previous 80 hours footage is on the camera.
6.  **How does the camera work?**  
    There are two cameras. One points forward, getting a view of the road in front of the vehicle and the second points at the driver. Both cameras record all driving and stores it on the memory in the camera. Video footage can be downloaded from the camera if required. Both cameras use AI technology, this technology is used to detect events. The forward facing camera detects events such as lane departure and getting too close to the car in front. The driver facing camera detects events such as talking on a mobile phone, distraction events, driver fatigue, non wearing of a seatbelt and smoking. These events generate audible alert in the vehicle and also generate an alert and send footage of the incident to the cloud platform.
