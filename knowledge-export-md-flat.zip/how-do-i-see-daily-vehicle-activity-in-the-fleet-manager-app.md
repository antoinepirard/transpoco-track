# How do I see daily vehicle activity in the Fleet Manager App?

Back to home

1.  Knowledge Base 
3.  Fleet Manager App 

-   Logging-in to your Transpoco account
    -   Login to your Transpoco account
    -   Transpoco Smartphone Apps
    -   2 Factor Authentication
    -   System requirements
    -   Overview of Transpoco
    -   Implementation
-   How to organise your account to achieve the best results
    
-   How to use each feature - step by step guides
    -   Users and permissions
    -   Walkaround Checks module
    -   Fuel/Electric Vehicles Module
    -   Maintain Module
    -   Dashboard
    -   Messaging module
    -   Scheduled Reports
-   How to Order More Trackers
    
-   Live Map
    
-   Cameras
    -   FAQ
-   Webinar Videos
    
-   Walkaround Checklists
    -   Walkaround Checklists
    -   Driver App
    -   Alerts
-   Reports
    -   Reports
    -   Viewing data in reports
-   Fuel
    
-   Dashboard
    
-   Maintain Module
    
-   Driving Style
    
-   Locations
    
-   Cost Management (TCO) Report
    
-   The Notification Features
    
-   Hardware and Installation
    
-   Removal & Repair of Hardware
    -   Requesting a Repair or a Deinstallation
-   Cameras & GDPR Guidelines
    
-   Scheduled Reports
    
-   Safety Program
    
-   Fleet Manager App
    
-   Users & Permissions
    
-   Alerts
    
-   Policies & Documents
    
-   Privacy Policy and Terms & Conditions
    -   RoPA
-   API
    
-   Transpoco User Manuals
    
-   Settings
    -   Garage
-   Whats New?
    
-   Account Mangement Services
    
-   Driver ID process
    
-   Security
    
-   Transpoco Locate
    
-   Subscriptions & Invoices
    
-   Tutorial videos
    
-   Cancelling your account
    
-   VOR
    
-   Installation
    
-   BIKLY
    

# How do I see daily vehicle activity in the Fleet Manager App?

## How to view the Daily Summary Report showing vehicle activity in the Transpoco Fleet Manager App

Tap on the three horizontal lines at the top left of the screen to access the drop-down menu.

Screenshot\_20190502\_192050\_com.synx.fleetmanager

Select **Daily Summary Report** to view the report.

Screenshot\_20190502\_193055\_com.synx.fleetmanager

To view all the journeys for a vehicle, tap the row and the Journey Report will open.

To select a vehicle group and/or vehicle or to change the date, tap on **Filters**.

Screenshot\_20190520\_022029\_com.synx.fleetmanager

If required, tap on **All Groups** and select a vehicle group from the list, and/or tap on **All Vehicles** and select just one vehicle.

Screenshot\_20190519\_132718\_com.synx.fleetmanager      Screenshot\_20190523\_235420\_com.synx.fleetmanager

**Note:** In the list of vehicles, vehicles in red currently have their engines off and those in green have their engine on.

If required, change from the current date to a previous date by tapping on **Date** and selecting the required date from the calendar.

**Note:** the current date is green and the selected date is in a green circle.

Screenshot\_20190519\_235408\_com.synx.fleetmanager

Tap on **OK**.
