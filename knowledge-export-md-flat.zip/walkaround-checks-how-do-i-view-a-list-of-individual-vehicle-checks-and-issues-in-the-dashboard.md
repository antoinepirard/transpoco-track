# Walkaround Checks: How do I view a list of individual vehicle checks and issues in the dashboard?

Back to home

1.  Knowledge Base 
3.  Walkaround Checklists 
5.  Walkaround Checklists 

-   Logging-in to your Transpoco account
    -   Login to your Transpoco account
    -   Transpoco Smartphone Apps
    -   2 Factor Authentication
    -   System requirements
    -   Overview of Transpoco
    -   Implementation
-   How to organise your account to achieve the best results
    
-   How to use each feature - step by step guides
    -   Users and permissions
    -   Walkaround Checks module
    -   Fuel/Electric Vehicles Module
    -   Maintain Module
    -   Dashboard
    -   Messaging module
    -   Scheduled Reports
-   How to Order More Trackers
    
-   Live Map
    
-   Cameras
    -   FAQ
-   Webinar Videos
    
-   Walkaround Checklists
    -   Walkaround Checklists
    -   Driver App
    -   Alerts
-   Reports
    -   Reports
    -   Viewing data in reports
-   Fuel
    
-   Dashboard
    
-   Maintain Module
    
-   Driving Style
    
-   Locations
    
-   Cost Management (TCO) Report
    
-   The Notification Features
    
-   Hardware and Installation
    
-   Removal & Repair of Hardware
    -   Requesting a Repair or a Deinstallation
-   Cameras & GDPR Guidelines
    
-   Scheduled Reports
    
-   Safety Program
    
-   Fleet Manager App
    
-   Users & Permissions
    
-   Alerts
    
-   Policies & Documents
    
-   Privacy Policy and Terms & Conditions
    -   RoPA
-   API
    
-   Transpoco User Manuals
    
-   Settings
    -   Garage
-   Whats New?
    
-   Account Mangement Services
    
-   Driver ID process
    
-   Security
    
-   Transpoco Locate
    
-   Subscriptions & Invoices
    
-   Tutorial videos
    
-   Cancelling your account
    
-   VOR
    
-   Installation
    
-   BIKLY
    

# Walkaround Checks: How do I view a list of individual vehicle checks and issues in the dashboard?

## SynX also provides an at-a-glance list of all the vehicle checks that have been made during the weekly period by each driver. This list can be exported to Excel.

Click on **Walkaround** in the header navigation menu in SynX.

The Walkaround dashboard will open on the default Weekly View.

Select the **List of Checks** tab.

The information contained in this table covers the following information about the checklists undertaken during the selected week:

-   **Defect:** Green denotes all checks OK; red denotes at least one check has a problem
-   **Completion Time:** When the check was completed in the app
-   **Received Time:** When the check was submitted to the web
-   **Vehicle:** Vehicle to which the check relates
-   **Odometer:** Vehicle mileage at time of check (if relevant to check)
-   **Location:** Vehicle location at time of check (if relevant to check)
-   **Additional Comments:** Added during walkaround check
-   **Inspector:** Who carried out the walkaround check
-   **Type:** Type of checklist

To change the week, click on the **blue arrows** situated either side of the date range.

To see the walkaround checks undertaken, click on the **black arrow** on the left of a row.

This shows the checks/issues and the answers given during the walkaround check.

Icon red - expanded

To view a photo(s) uploaded during the walkaround check, click on the **orange icon** in the ‘Actions’ column to open the Image Gallery.

Image Gallery

Use the **left and right arrows** to scroll through the images.

Click the **bottom arrow** to play the images in sequence.

To view the image full screen, click on the **full screen icon** on the right.

To return to the normal screen, click on the **icon** on the right-hand side of the screen.

Return from full screen-1

Close the Image Gallery by clicking the **x** in the top right corner.
