# Vehicle Custom Status

Back to home

1.  Knowledge Base 
3.  Settings 

-   Logging-in to your Transpoco account
    -   Login to your Transpoco account
    -   Transpoco Smartphone Apps
    -   2 Factor Authentication
    -   System requirements
    -   Overview of Transpoco
    -   Implementation
-   How to organise your account to achieve the best results
    
-   How to use each feature - step by step guides
    -   Users and permissions
    -   Walkaround Checks module
    -   Fuel/Electric Vehicles Module
    -   Maintain Module
    -   Dashboard
    -   Messaging module
    -   Scheduled Reports
-   How to Order More Trackers
    
-   Live Map
    
-   Cameras
    -   FAQ
-   Webinar Videos
    
-   Walkaround Checklists
    -   Walkaround Checklists
    -   Driver App
    -   Alerts
-   Reports
    -   Reports
    -   Viewing data in reports
-   Fuel
    
-   Dashboard
    
-   Maintain Module
    
-   Driving Style
    
-   Locations
    
-   Cost Management (TCO) Report
    
-   The Notification Features
    
-   Hardware and Installation
    
-   Removal & Repair of Hardware
    -   Requesting a Repair or a Deinstallation
-   Cameras & GDPR Guidelines
    
-   Scheduled Reports
    
-   Safety Program
    
-   Fleet Manager App
    
-   Users & Permissions
    
-   Alerts
    
-   Policies & Documents
    
-   Privacy Policy and Terms & Conditions
    -   RoPA
-   API
    
-   Transpoco User Manuals
    
-   Settings
    -   Garage
-   Whats New?
    
-   Account Mangement Services
    
-   Driver ID process
    
-   Security
    
-   Transpoco Locate
    
-   Subscriptions & Invoices
    
-   Tutorial videos
    
-   Cancelling your account
    
-   VOR
    
-   Installation
    
-   BIKLY
    

# Vehicle Custom Status

## Vehicle Custom Status Manual Update on the Fleet Manager APP

Follow the steps below to enable the option to view and/or edit the custom status of vehicles.

Step 1

You need to change the user profile to allow the user to change the custom status on the Fleet Manager APP.

1.  You need to give access to the profile to view and/or edit the custom status on the Fleet Manager APP;
2.  Also, the permission to access the APP should be given;

Annotation 2020-06-09 164157  
  
  

3.  If you want to see the status on the last location report, you need to add the “status” column to the report through the “Report Customisation” tab;  

  
  
Annotation 2020-06-09 164232  
Step 2

1.  On the Fleet Manager APP, you can change the status just clicking on the vehicle on the live map and then clicking on the option “Change status” there. Please look at the screenshot below:
2.  Also, you can see the status of each vehicle on the vehicles list when clicking on the bottom button to pick a vehicle. Please check the screenshot below:

Annotation 2020-06-09 164426

Step 3

After changing the status on the Fleet Manager APP, you can also see the changes on the Last Location report in the Web Platform if the column was added to the report via profile (you can check how to add it in step 1).

Annotation 2020-06-09 164517
