# A quick tour of the screen layout

Back to home

1.  Knowledge Base 
3.  Logging-in to your Transpoco account 
5.  Overview of Transpoco 

-   Logging-in to your Transpoco account
    -   Login to your Transpoco account
    -   Transpoco Smartphone Apps
    -   2 Factor Authentication
    -   System requirements
    -   Overview of Transpoco
    -   Implementation
-   How to organise your account to achieve the best results
    
-   How to use each feature - step by step guides
    -   Users and permissions
    -   Walkaround Checks module
    -   Fuel/Electric Vehicles Module
    -   Maintain Module
    -   Dashboard
    -   Messaging module
    -   Scheduled Reports
-   How to Order More Trackers
    
-   Live Map
    
-   Cameras
    -   FAQ
-   Webinar Videos
    
-   Walkaround Checklists
    -   Walkaround Checklists
    -   Driver App
    -   Alerts
-   Reports
    -   Reports
    -   Viewing data in reports
-   Fuel
    
-   Dashboard
    
-   Maintain Module
    
-   Driving Style
    
-   Locations
    
-   Cost Management (TCO) Report
    
-   The Notification Features
    
-   Hardware and Installation
    
-   Removal & Repair of Hardware
    -   Requesting a Repair or a Deinstallation
-   Cameras & GDPR Guidelines
    
-   Scheduled Reports
    
-   Safety Program
    
-   Fleet Manager App
    
-   Users & Permissions
    
-   Alerts
    
-   Policies & Documents
    
-   Privacy Policy and Terms & Conditions
    -   RoPA
-   API
    
-   Transpoco User Manuals
    
-   Settings
    -   Garage
-   Whats New?
    
-   Account Mangement Services
    
-   Driver ID process
    
-   Security
    
-   Transpoco Locate
    
-   Subscriptions & Invoices
    
-   Tutorial videos
    
-   Cancelling your account
    
-   VOR
    
-   Installation
    
-   BIKLY
    

# A quick tour of the screen layout

## Know all the features of Transpoco

This article covers the layout of the Transpoco home page, including the live map and functions, report generator, menu options and logging out of the software.

Transpoco will open onto the **Home Page**; unless customised to be a different page, this will be the Last Location map showing the real-time location of all the vehicles in the fleet and the Report Generator.

The main components of the software interface are:

#### **Transpoco software menus**

-   Synx functionality as a tabbed menu at the top of the screen – the current function in use is highlighted in light blue.
-   Drop-down menu at the top right for quick access to the Settings menu and log out.
-   Icon at bottom left for quick access to the online Knowledge Base for help.
-   All these menus remain in view, whatever you are doing in Transpoco.

#### **Map functions**

-   Google Map layers – view area in different ways, e.g. as satellite view, and/or overlay Google and Transpoco map data (for more information about map layers, see **Using map layers to organise map features** ).
-   Transpoco map functionality – toggle full screen view and toggle **vehicle clustering** \[hidden in image\].
-   Google Map controls – including Pegman to connect to **Google Street View**, and zoom buttons.

#### **Report Generator**

-   Use drop-down menus and pop-up calendars to add parameters to create your reports (see **Creating a report**).
-   Hide/open the panel with a click on the arrow.

#### **Vehicle details**

-   Hover your mouse over a vehicle to see pop-up details.
-   Click on a vehicle to view the details on the status bar at the bottom of the map.

### **Reduced browser window width**

If the browser window is reduced in width, the software menu will eventually become hidden.

If this happens:

1.  Click on the menu icon in the top right-hand corner. The icon will turn grey and the menu will drop down as vertical list.
2.  Select the required menu item. The item will be highlighted.
3.  Click again on the menu icon to close the list.
