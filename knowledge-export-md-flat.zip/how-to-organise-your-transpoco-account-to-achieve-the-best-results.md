# How to organise your Transpoco account to achieve the best results

Back to home

1.  Knowledge Base 
3.  How to organise your account to achieve the best results 

-   Logging-in to your Transpoco account
    -   Login to your Transpoco account
    -   Transpoco Smartphone Apps
    -   2 Factor Authentication
    -   System requirements
    -   Overview of Transpoco
    -   Implementation
-   How to organise your account to achieve the best results
    
-   How to use each feature - step by step guides
    -   Users and permissions
    -   Walkaround Checks module
    -   Fuel/Electric Vehicles Module
    -   Maintain Module
    -   Dashboard
    -   Messaging module
    -   Scheduled Reports
-   How to Order More Trackers
    
-   Live Map
    
-   Cameras
    -   FAQ
-   Webinar Videos
    
-   Walkaround Checklists
    -   Walkaround Checklists
    -   Driver App
    -   Alerts
-   Reports
    -   Reports
    -   Viewing data in reports
-   Fuel
    
-   Dashboard
    
-   Maintain Module
    
-   Driving Style
    
-   Locations
    
-   Cost Management (TCO) Report
    
-   The Notification Features
    
-   Hardware and Installation
    
-   Removal & Repair of Hardware
    -   Requesting a Repair or a Deinstallation
-   Cameras & GDPR Guidelines
    
-   Scheduled Reports
    
-   Safety Program
    
-   Fleet Manager App
    
-   Users & Permissions
    
-   Alerts
    
-   Policies & Documents
    
-   Privacy Policy and Terms & Conditions
    -   RoPA
-   API
    
-   Transpoco User Manuals
    
-   Settings
    -   Garage
-   Whats New?
    
-   Account Mangement Services
    
-   Driver ID process
    
-   Security
    
-   Transpoco Locate
    
-   Subscriptions & Invoices
    
-   Tutorial videos
    
-   Cancelling your account
    
-   VOR
    
-   Installation
    
-   BIKLY
    

# How to organise your Transpoco account to achieve the best results

## In this article we will explain how vehicle groups are the key to achieving great results with your Transpoco account.

To utilise the potential of your Transpoco account and to achieve results we recommend you create vehicle groups.  From our experience most customers do not use the option to create vehicle groups. However, the best performing accounts are built on vehicle groups and in this article we will explain how you can achieve the same success.

### Why create vehicle groups?

1\. To create insightful KPI metrics in your dashboard, which compare the performance of groups of vehicles from different departments, divisions, regions, store locations, etc. 

2\. The best performing Transpoco accounts involve staff at all levels of the organisation from directors to supervisors. You can assign vehicle groups to the users responsible for these groups. You can create and assign profiles which prevent users from accessing vehicle groups outside of their responsibility.

Before we starting explaining these 2 reasons in more detail we will explain vehicle groups and how to create vehicle groups.

### **What are vehicle groups?**

You can divide the vehicles we are tracking into groups which will allow you to run reports on a group or to compare groups.

You can create vehicle groups to suit the structure of your company, here are some suggestions:

-   Create vehicle groups for the vehicles assigned to each store location
-   Create vehicle groups for the vehicles assigned to each company department 
-   Create vehicle group for the vehicles assigned to each region 
-   Create vehicle groups for the vehicles assigned vehicles assigned to each supervisor/manager/director                                             

You can also create vehicle groups to help you to compare the fuel efficiency of vehicles:

-   Create a vehicle for each vehicle size (small, medium, large)
-   Create a vehicle group for each vehicle make and model.

**Tips from Transpoco**

A vehicle can be included in more than 1 vehicle group, there is no limit. You can include a vehicle in multiple vehicle groups.

You can also create as many vehicle groups as you want, there is no limit.

### **How to create a vehicle group?**

In this video we demonstrate how you can create vehicle groups in your Transpoco account. 

If you do not have access to the **Settings** menu in your account then please talk to the administrator of your Transpoco account to request access.

### **Creating vehicle groups will help you to create insightful KPI metrics in your Dashboard**

To achieve the best results from your Transpoco account we recommend you use our You make You can create a range of KPI metrics in the Dashboard and the Dashboard will become the focus of attention for the administrators of the account.

The best KPI metrics compare the performance of divisions/departments, store locations, regions or vehicles assigned to managers/supervisors. The best performing Transpoco accounts use the Dashboard to provide a quick snap shot of the performance of their fleets, the metrics can be as detailed as you want. 

Here are some examples:

Dashboard (1)

Dashboard (1)-1

Dashboard (1)-2

**To reach this level of KPI reporting you need to create your vehicle groups.** 

**What is the Dashboard?**

If you are not familiar with the Dashboard please watch the video below to learn how to access the Dashboard and how to create KPI metrics. Click here to learn more about the Dashboard and learn some tips to organise your Dashboard to measure success.

### **Creating vehicle groups will allow you to assign the right vehicles groups to the right users**

Customers who successfully integrate Transpoco into their organisations involve employees at levels of the organisation. To help you to involve staff at all levels there are 2 things you need to do:

1.  Create customised profiles with different levels of access  (this article demonstrates how you can create a customised profile)
2.  Create vehicle groups  (this article explains how to create a vehicle group)

Once you have created customised profiles and vehicle groups you can assign access to an employee. This video demonstrates how you can provide access to an employee.

The key to success is assigning vehicles groups to the users responsible for these groups. For example:

-   An area manager will be assigned the vehicle group containing the vehicles for his area
-   The sales manager will be assigned the vehicle groups representing each area
-   The managing director will be assigned all vehicles groups on the account
