# How can I compare metric data from two periods in the Dashboard?

Back to home

1.  Knowledge Base 
3.  Dashboard 

-   Logging-in to your Transpoco account
    -   Login to your Transpoco account
    -   Transpoco Smartphone Apps
    -   2 Factor Authentication
    -   System requirements
    -   Overview of Transpoco
    -   Implementation
-   How to organise your account to achieve the best results
    
-   How to use each feature - step by step guides
    -   Users and permissions
    -   Walkaround Checks module
    -   Fuel/Electric Vehicles Module
    -   Maintain Module
    -   Dashboard
    -   Messaging module
    -   Scheduled Reports
-   How to Order More Trackers
    
-   Live Map
    
-   Cameras
    -   FAQ
-   Webinar Videos
    
-   Walkaround Checklists
    -   Walkaround Checklists
    -   Driver App
    -   Alerts
-   Reports
    -   Reports
    -   Viewing data in reports
-   Fuel
    
-   Dashboard
    
-   Maintain Module
    
-   Driving Style
    
-   Locations
    
-   Cost Management (TCO) Report
    
-   The Notification Features
    
-   Hardware and Installation
    
-   Removal & Repair of Hardware
    -   Requesting a Repair or a Deinstallation
-   Cameras & GDPR Guidelines
    
-   Scheduled Reports
    
-   Safety Program
    
-   Fleet Manager App
    
-   Users & Permissions
    
-   Alerts
    
-   Policies & Documents
    
-   Privacy Policy and Terms & Conditions
    -   RoPA
-   API
    
-   Transpoco User Manuals
    
-   Settings
    -   Garage
-   Whats New?
    
-   Account Mangement Services
    
-   Driver ID process
    
-   Security
    
-   Transpoco Locate
    
-   Subscriptions & Invoices
    
-   Tutorial videos
    
-   Cancelling your account
    
-   VOR
    
-   Installation
    
-   BIKLY
    

# How can I compare metric data from two periods in the Dashboard?

## How to compare two periods of data in a metric, e.g. current and previous weeks.

For most metrics, you can compare two periods (e.g. compare last week and this week).

Click on the **edit icon** in the header.

Edit chart

The edit metric form will open.

Edit form

Check the **Comparison Period** The second Period will no longer be greyed out.

Select the second **Period** from the drop-down menu. This can be one of the default periods such as ‘Last Week’, ‘Last Month’ etc. Note: ‘Year To Date’ is the period from 1st Jan until now.

Comparison Periods

Alternatively, to set a different period, select ‘Custom Period’ from the list.

The current week will then be selected by default.

Click on the **calendar icon**.

Comparison Custom Periods1

The calendar will open with the default current week highlighted. **Note:** The start date is highlighted in the Custom Period box with a green underline.

Comparison Calendars

Click on your required **start date**. **Note:** The selected day turns darker green and the date appears in the Custom Period box. The green underline switches to the end date.

Comparison Calendar start date

Click on your required **end date**.

The Calendar will close and your chosen period will appear in the Custom Period box.

Comparison Custom Periods2

If you want to change the start date, click on the **first date** in the Custom Period box to re-open the calendar and select a new start date.

If you want to change the end date, click on the **second date** in the Custom Period box to re-open the calendar and select a new end date.

To return to the drop-down list of default periods, click on **default periods** above the Custom Period box.

**Note:** If you need to change the dates in the first Period, repeat the steps above.

Click on the green **Save** button.

The metric will refresh and show the values in both comparison periods.

Metric with two compared periods
