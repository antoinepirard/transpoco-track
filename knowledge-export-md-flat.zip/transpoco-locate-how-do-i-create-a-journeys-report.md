# Transpoco Locate: How do I create a Journeys Report?

Back to home

1.  Knowledge Base 
3.  Transpoco Locate 

-   Logging-in to your Transpoco account
    -   Login to your Transpoco account
    -   Transpoco Smartphone Apps
    -   2 Factor Authentication
    -   System requirements
    -   Overview of Transpoco
    -   Implementation
-   How to organise your account to achieve the best results
    
-   How to use each feature - step by step guides
    -   Users and permissions
    -   Walkaround Checks module
    -   Fuel/Electric Vehicles Module
    -   Maintain Module
    -   Dashboard
    -   Messaging module
    -   Scheduled Reports
-   How to Order More Trackers
    
-   Live Map
    
-   Cameras
    -   FAQ
-   Webinar Videos
    
-   Walkaround Checklists
    -   Walkaround Checklists
    -   Driver App
    -   Alerts
-   Reports
    -   Reports
    -   Viewing data in reports
-   Fuel
    
-   Dashboard
    
-   Maintain Module
    
-   Driving Style
    
-   Locations
    
-   Cost Management (TCO) Report
    
-   The Notification Features
    
-   Hardware and Installation
    
-   Removal & Repair of Hardware
    -   Requesting a Repair or a Deinstallation
-   Cameras & GDPR Guidelines
    
-   Scheduled Reports
    
-   Safety Program
    
-   Fleet Manager App
    
-   Users & Permissions
    
-   Alerts
    
-   Policies & Documents
    
-   Privacy Policy and Terms & Conditions
    -   RoPA
-   API
    
-   Transpoco User Manuals
    
-   Settings
    -   Garage
-   Whats New?
    
-   Account Mangement Services
    
-   Driver ID process
    
-   Security
    
-   Transpoco Locate
    
-   Subscriptions & Invoices
    
-   Tutorial videos
    
-   Cancelling your account
    
-   VOR
    
-   Installation
    
-   BIKLY
    

# Transpoco Locate: How do I create a Journeys Report?

## How to create a Journeys Report in Locate, which provides a detailed breakdown of each journey taken, including route replay on the map.

The Journey Report show all journeys made by each vehicle in a day. A journey is defined as engine turned on to engine turned off.

**Note:** If you require more detailed information about how to run the report, see How do I create a report?

1.  Select the **Vehicle(s)**.
2.  Select ‘Journeys’ from the **Reports** drop-down list.
3.  Select the **date** range.
4.  Click on the **View Report** button.

Journeys Report

The totals for the fleet (or selected group of vehicles) are in the pink row.

The standard information contained in this report covers the following for each day during the selected period:

-   Start Time: The time the journey started (engine on)
-   Start Location: Where the journey started
-   Stop Time: The time the journey started (engine off)
-   Stop Location: Where the journey ended
-   Journey Time: Length of time in hours & minutes that the engine was on
-   Idling Time: Length of time the engine was on but vehicle did not move
-   Distance: Distance (in km or miles) of journey
-   Route Playback: Mapped route of the journey between start time and stop time

To export the data as .csv or .xls format, click on the **Export** icon above the far right column. For more information see How do I export a report?

### View route

To view on the map a replay of the journey of any vehicle on any day, click the **Route Playback** icon at the end of that row.

Journeys Report - view route

The journey is mapped from start (green pin) to finish (red pin).

The rows show the individual driving events and driving time intervals (usually every ~30 seconds) that sent data from the GPS unit to the software.

The standard information contained in this table covers the following for each driving event and part of the journey:

-   Date: Shows the date of the journey
-   Location: Where the driving event took place
-   Speed: Snapshot of the speed when driving data was sent
-   Driver: Assigned driver to vehicle
-   Satellites: Number of satellites tracking the vehicle GPS
-   Engine: Ignition on or off
-   Event: Vehicle data updates on movement and time intervals
-   Coordinates: Map coordinates of location

Click on rows in the table to view the corresponding event on the journey as black arrows.

Journeys Report - detailed rows

Use the **map controls** to zoom into parts of the journey or view in Street View.

By default, the map and table are split 50/50 on the screen. To show the map full screen, click on the **Split Screen** icon (top icon) in the top left-hand corner. The system will remember your choice.

Summary Map toggle icons

As the map will fill now the screen, scroll down to view the table rows.

Click the icon again to return to 50/50 split screen.

To view only the map in full screen, click on the **Full Screen** icon (bottom icon) in the top left-hand corner.

To exit the full screen mode, click on the icon again or press the **ESC** key on your keyboard.

To export the data as .csv or .xls format, click on the **Export** icon above the far right column. For more information see How do I export a report?

### Chart view

The Journey chart view graphs the Travel Time and Idling Time per vehicle per day.

From the main tabular report, click on the **Chart** tab.

Journeys Report - chart
