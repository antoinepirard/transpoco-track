# How do I add drivers to my Transpoco account?

Back to home

1.  Knowledge Base 
3.  Settings 
5.  Garage 

-   Logging-in to your Transpoco account
    -   Login to your Transpoco account
    -   Transpoco Smartphone Apps
    -   2 Factor Authentication
    -   System requirements
    -   Overview of Transpoco
    -   Implementation
-   How to organise your account to achieve the best results
    
-   How to use each feature - step by step guides
    -   Users and permissions
    -   Walkaround Checks module
    -   Fuel/Electric Vehicles Module
    -   Maintain Module
    -   Dashboard
    -   Messaging module
    -   Scheduled Reports
-   How to Order More Trackers
    
-   Live Map
    
-   Cameras
    -   FAQ
-   Webinar Videos
    
-   Walkaround Checklists
    -   Walkaround Checklists
    -   Driver App
    -   Alerts
-   Reports
    -   Reports
    -   Viewing data in reports
-   Fuel
    
-   Dashboard
    
-   Maintain Module
    
-   Driving Style
    
-   Locations
    
-   Cost Management (TCO) Report
    
-   The Notification Features
    
-   Hardware and Installation
    
-   Removal & Repair of Hardware
    -   Requesting a Repair or a Deinstallation
-   Cameras & GDPR Guidelines
    
-   Scheduled Reports
    
-   Safety Program
    
-   Fleet Manager App
    
-   Users & Permissions
    
-   Alerts
    
-   Policies & Documents
    
-   Privacy Policy and Terms & Conditions
    -   RoPA
-   API
    
-   Transpoco User Manuals
    
-   Settings
    -   Garage
-   Whats New?
    
-   Account Mangement Services
    
-   Driver ID process
    
-   Security
    
-   Transpoco Locate
    
-   Subscriptions & Invoices
    
-   Tutorial videos
    
-   Cancelling your account
    
-   VOR
    
-   Installation
    
-   BIKLY
    

# How do I add drivers to my Transpoco account?

## To add a new driver to your Transpoco account please see information below.

Start off by going to the settings section whilst on the Live Map homepage. When hovering over the drop down settings menu click drivers under the heading 'Garage.' 

When the drivers page is open it will show you the full list of drivers already registered on the account.

Information on the page includes drivers email addresses, contact numbers, iButton, RFID identification numbers, group membership and if a driver has access to the Driver Application or not. 

On this page click Add New Driver. 

Add New Driver

A page will then open and ask you to fill out the required information surrounding the individual driver.

Driver Details-1

To assign a KeyFob/iButton or RFID ID Card to a driver you must click the drop down section on the 'Vehicle Assignment' option and click which mode of driver identification your company currently uses. You can then add the driver ID button number in the Driver iButton section. This number is the 16 digit character code that is located on the front face of each driver ID fob.

ibutton numberingYou can add more details by clicking the plus sign beside the 'More Details' option at the bottom of the page which allows you to add more specific information about each driver. 

More Details-1

When the information is added to the page you can click 'Create Driver' which will then add that driver to the list of registered drivers.
