# Walkaround Checks: Can I action required services/repairs through the Walkaround Dashboard?

Back to home

1.  Knowledge Base 
3.  Walkaround Checklists 
5.  Walkaround Checklists 

-   Logging-in to your Transpoco account
    -   Login to your Transpoco account
    -   Transpoco Smartphone Apps
    -   2 Factor Authentication
    -   System requirements
    -   Overview of Transpoco
    -   Implementation
-   How to organise your account to achieve the best results
    
-   How to use each feature - step by step guides
    -   Users and permissions
    -   Walkaround Checks module
    -   Fuel/Electric Vehicles Module
    -   Maintain Module
    -   Dashboard
    -   Messaging module
    -   Scheduled Reports
-   How to Order More Trackers
    
-   Live Map
    
-   Cameras
    -   FAQ
-   Webinar Videos
    
-   Walkaround Checklists
    -   Walkaround Checklists
    -   Driver App
    -   Alerts
-   Reports
    -   Reports
    -   Viewing data in reports
-   Fuel
    
-   Dashboard
    
-   Maintain Module
    
-   Driving Style
    
-   Locations
    
-   Cost Management (TCO) Report
    
-   The Notification Features
    
-   Hardware and Installation
    
-   Removal & Repair of Hardware
    -   Requesting a Repair or a Deinstallation
-   Cameras & GDPR Guidelines
    
-   Scheduled Reports
    
-   Safety Program
    
-   Fleet Manager App
    
-   Users & Permissions
    
-   Alerts
    
-   Policies & Documents
    
-   Privacy Policy and Terms & Conditions
    -   RoPA
-   API
    
-   Transpoco User Manuals
    
-   Settings
    -   Garage
-   Whats New?
    
-   Account Mangement Services
    
-   Driver ID process
    
-   Security
    
-   Transpoco Locate
    
-   Subscriptions & Invoices
    
-   Tutorial videos
    
-   Cancelling your account
    
-   VOR
    
-   Installation
    
-   BIKLY
    

# Walkaround Checks: Can I action required services/repairs through the Walkaround Dashboard?

## Issues found during the walkaround can be actioned directly from the dashboard.

1.  Log in to your Transpoco Synx account.
2.  Click on the Services > WalkAround.  
    
3.  Then you could choose either "Weekly View" or "List od checks" in the WalkAround Dashboard. (Weekly View is the default page).  
    
4.  Click on the **green** **\+ icon** for the defect.  
    
5.  The New Service form will open. Please fill all the required field.   
    New service2
6.  Then click on "confirm". The alert has now been set up and the chosen recipients will receive an email when the alert is triggered.
    

Note: Please click the links below to view the detailed article regarding the two ways to set up services and maintenance for vehicles from within the SynX Walkaround Dashboard:

-   Within Weekly View
-   Within List of Checks

7.   You could also view the service information by clicking on the link below each vehicle.

8.   It can get you to the Maintain module filtered by specific vehicle and Service Status.
