# Private Mode Data Collection

Back to home

1.  Knowledge Base 
3.  Users & Permissions 

-   Logging-in to your Transpoco account
    -   Login to your Transpoco account
    -   Transpoco Smartphone Apps
    -   2 Factor Authentication
    -   System requirements
    -   Overview of Transpoco
    -   Implementation
-   How to organise your account to achieve the best results
    
-   How to use each feature - step by step guides
    -   Users and permissions
    -   Walkaround Checks module
    -   Fuel/Electric Vehicles Module
    -   Maintain Module
    -   Dashboard
    -   Messaging module
    -   Scheduled Reports
-   How to Order More Trackers
    
-   Live Map
    
-   Cameras
    -   FAQ
-   Webinar Videos
    
-   Walkaround Checklists
    -   Walkaround Checklists
    -   Driver App
    -   Alerts
-   Reports
    -   Reports
    -   Viewing data in reports
-   Fuel
    
-   Dashboard
    
-   Maintain Module
    
-   Driving Style
    
-   Locations
    
-   Cost Management (TCO) Report
    
-   The Notification Features
    
-   Hardware and Installation
    
-   Removal & Repair of Hardware
    -   Requesting a Repair or a Deinstallation
-   Cameras & GDPR Guidelines
    
-   Scheduled Reports
    
-   Safety Program
    
-   Fleet Manager App
    
-   Users & Permissions
    
-   Alerts
    
-   Policies & Documents
    
-   Privacy Policy and Terms & Conditions
    -   RoPA
-   API
    
-   Transpoco User Manuals
    
-   Settings
    -   Garage
-   Whats New?
    
-   Account Mangement Services
    
-   Driver ID process
    
-   Security
    
-   Transpoco Locate
    
-   Subscriptions & Invoices
    
-   Tutorial videos
    
-   Cancelling your account
    
-   VOR
    
-   Installation
    
-   BIKLY
    

# Private Mode Data Collection

In respect and to promote transparency to our customers, Transpoco hereby clarifies what is monitored when a driver identification fob or switch is enabled for private mode within our system. 

Normally the Transpoco GPS device will capture information like below: 

  

**Time of** 

**Update**

**GPS** 

**Latitude**

**GPS** 

**Longitude**

**GPS Speed**

**Ignition status**

**GPS mileage**

2021-09-21 

16:37:08

54.5556933

\-5.9928514

20 km/h

On 

550

  
  

When a driver logs into a vehicle with the private mode fob or uses a private mode switch, the GPS location and speed data is removed, the board below is applied internally: 

**Time of** 

**Update**

**GPS** 

**Latitude**

**GPS** 

**Longitude**

**GPS Speed**

**Ignition status**

**GPS mileage**

2021-09-21 

16:37:08

O

O

O

On 

550

Note: The time of update won't be displayed in the manager reports, it's only for internal control.

When the vehicle is in private mode and the engine is turned OFF, the vehicle remains in private mode. Once the engine is turned ON, the driver will have a few seconds to remain in private mode if he uses the related fob during the beeping time. Otherwise, the vehicle will be back to business mode automatically.

Transpoco follows the principles of transparency and minimisation, as required on GDPR's article 5, collecting the minimal data required to provide the service sold to our customers. 

Therefore when the private mode is activated, there will be no collection of personal data, to protect the driver's privacy.
