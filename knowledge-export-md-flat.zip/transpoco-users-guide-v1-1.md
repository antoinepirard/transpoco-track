# Transpoco Users Guide v1.1

Back to home

1.  Knowledge Base 
3.  Transpoco User Manuals 

-   Logging-in to your Transpoco account
    -   Login to your Transpoco account
    -   Transpoco Smartphone Apps
    -   2 Factor Authentication
    -   System requirements
    -   Overview of Transpoco
    -   Implementation
-   How to organise your account to achieve the best results
    
-   How to use each feature - step by step guides
    -   Users and permissions
    -   Walkaround Checks module
    -   Fuel/Electric Vehicles Module
    -   Maintain Module
    -   Dashboard
    -   Messaging module
    -   Scheduled Reports
-   How to Order More Trackers
    
-   Live Map
    
-   Cameras
    -   FAQ
-   Webinar Videos
    
-   Walkaround Checklists
    -   Walkaround Checklists
    -   Driver App
    -   Alerts
-   Reports
    -   Reports
    -   Viewing data in reports
-   Fuel
    
-   Dashboard
    
-   Maintain Module
    
-   Driving Style
    
-   Locations
    
-   Cost Management (TCO) Report
    
-   The Notification Features
    
-   Hardware and Installation
    
-   Removal & Repair of Hardware
    -   Requesting a Repair or a Deinstallation
-   Cameras & GDPR Guidelines
    
-   Scheduled Reports
    
-   Safety Program
    
-   Fleet Manager App
    
-   Users & Permissions
    
-   Alerts
    
-   Policies & Documents
    
-   Privacy Policy and Terms & Conditions
    -   RoPA
-   API
    
-   Transpoco User Manuals
    
-   Settings
    -   Garage
-   Whats New?
    
-   Account Mangement Services
    
-   Driver ID process
    
-   Security
    
-   Transpoco Locate
    
-   Subscriptions & Invoices
    
-   Tutorial videos
    
-   Cancelling your account
    
-   VOR
    
-   Installation
    
-   BIKLY
    

# Transpoco Users Guide v1.1

Transpoco User Guide        

**Contents**

**Preface        4**

**1**  **System requirements        5**

1.1  Access via a web browser        5

1.2  Access via the mobile app  5

**2**  **Logging into SynX        6**

**3**  **Screen layout        7**

3.1  Reduced browser window width        8

3.2  Map controls        9

3.2.1  Panning the map        9

3.2.2  Zoom in/out of the map        9

3.2.3  View map full screen        9

3.3  Logging out of SynX        10

**4**  **Map view        11**

4.1  Viewing vehicles in real time        11

4.1.1  Vehicle clustering        11

4.1.2  View and follow selected vehicles        12

4.1.3  View and follow a single vehicle        13

4.2  Viewing historic routes        14

4.3  Using map layers to organise map features        14

4.3.1  Map layer        15

4.3.2  Map with Terrain        15

4.3.3  Satellite        16

4.3.4  OSM        16

4.3.5  Traffic        17

4.3.6  Locations        17

4.3.7  Routes        18

4.4  Searching for locations        19

4.5  Using Google Street View        19

4.6  Adding a custom location        20

4.7  Sending a location to a phone        20

4.8  Locating nearest vehicles        21

**5**  **Viewing data in reports        22**

5.1  SynX Report Generator        22

5.1.1  Creating a report        23

5.1.2  Other statistical formats        23

5.1.3  Exporting data        24

5.2  Last Location Report        24

5.3  Fleet Summary Report        25

5.4  Summary Report        26

5.4.1  View route        28

5.4.2  Chart view        30

5.5  Journeys Report        30

5.5.1  View route        31

5.5.2  Chart view        34

5.6  Stops Report        34

5.6.1  View all Stops on the map        35

5.6.2  View Stops individually on the map        37

5.7  Idling Report        38

5.7.1  View all idling events on the map        40

5.7.2  View idling individually on the map        41

5.8  Stops/Idling Report        42

5.8.1  View all stops/idling events on the map        44

5.8.2  View a stop/idling individually on the map        45

5.9  Locations Report        46

5.9.1  View route or stop        47

5.10  Route Completion Summary Report        49

5.11  Route Completion Report        50

5.12  Operating Report        51

5.13  Operating Summary Report        53

5.14  Driving Summary Report        54

5.14.1  View a vehicle’s speeding events        58

5.14.2  View a vehicle’s harsh braking, rapid acceleration and harsh cornering events        60

5.14.3  View all of a vehicle’s driving events        62

5.14.4  Driving Summary Settings        63

5.15  Speed Summary Report        64

5.15.1  View one speeding range for a vehicle        68

5.15.2  View all of a vehicle’s speeding events        70

**6**  **Sending Scheduled Reports        73**

6.1  Locate Scheduled Reports        73

6.2  Create new Scheduled Report        74

6.2.1  View Scheduled Report (for recipients only)        78

6.3  Edit Scheduled Report        80

6.4  View schedule history        81

6.5  Delete Scheduled Report        82

**7**  **Alerts (exception reporting)        83**

7.1  View alerts in a report        83

7.2  Managing alerts        87

7.2.1  Create an alert        88

7.2.2  Amend an existing alert        91

7.2.3  Delete an existing alert        92

**8**  **Locations Database        93**

8.1  View the locations in the database        93

8.1.1  View an individual location or geofence        94

8.2  Add a custom location/geofence        95

8.3  Edit a location        99

**9**  **Messaging        101**

**10**  **Fuel Control        102**

**11**  **Vehicles and drivers        103**

**12**  **Service management        104**

**13**  **Vehicle walk around checks        105**

**14**  **Import wizard        106**

**15**  **Orders and billing        107**

**16**  **Users and permissions        108**

**17**  **Support and training        109**

**18**  **API resources        110**

****Preface****

Welcome to the SynX User Guide.

This user guide is available in print format and can be viewed and downloaded from the website.

Actions in the guide are denoted by the coloured arrows . Separate steps to perform an action follow a colour pattern: green – orange – light blue – dark blue. These repeat where necessary.

**Please note the following:**

As SynX is completely customisable to your exact needs, in addition to the standard tracking, some of the functionality covered in this user guide is optional.

Users are set up with different permissions on SynX, so some features will not be available to you, for example some settings are only available to users with Administrator privileges.

1.  **System requirements**

1.  ### **Access via a web browser**
    

SynX can be accessed through any HTML5-compliant internet browser on PCs, Macs, laptops, netbooks, smartphones and tablets (Windows, Apple and Android) and any other hand-held device.

Compatible browsers include:

-   Google Chrome (any version)
-   Microsoft Internet Explorer (7 or greater)
-   Safari
-   Firefox (2 and greater)

While not essential we would recommend that you run the latest version of your preferred web browser for improved system speed and general internet security. By default, SynX uses the HTTPS protocol so all the information between your browser and the website is encrypted.

No popup windows are used, so popup blockers can stay enabled.

1.  ### **Access via the mobile app**
    

A mobile version of SynX is also available as our Fleet Manager App and our Driver App, both of which can be downloaded from:

Instructions on using the app are provided separately in section XX.

1.  **Logging into SynX**

The URL for SynX is 

Access is by secure login with unique **username** and **password**. If you have not yet received your login details, please contact your System Administrator.

-   Type the URL into the browser’s address bar. The website will open on the login page.

-   Enter your username and password in the respective fields and click the Login button to access the home page.

**Note:** If you have forgotten your username or password, please see Section XX.

1.  **Screen layout**

SynX will open onto the **Home Page**; unless customised to be a different page, this will be the Last Location map showing the real-time location of all the vehicles in the fleet and Report Generator.

The main components of the software interface are:

**1**  **SynX software menus:**

-   Synx functionality as a tabbed menu at the top of the screen – the current function in use is highlighted in light blue.
-   Drop-down menu at the top right for quick access to the Settings menu and log out.
-   Icon at bottom left for quick access to the chat feature for instant support – also includes notification of system messages (there are currently two unread).
-   All these menus remain in view, whatever you are doing in SynX.

**2**  **Map functions:**

-   Google Map layers – view area in different ways, e.g. as satellite view, and/or overlay Google and SynX map data (for more information about map layers, see Section XX).
-   SynX map functionality – toggle full screen view and toggle vehicle clustering \[hidden in image\].
-   Google Map controls – including Pegman to connect to Google Street View, and zoom buttons.

**3**  **Report Generator:**

-   Use drop-down menus and pop-up calendars to add parameters to create your reports (see Section XX on creating and running reports).

**4**  **Vehicle details:**

-   Hover your mouse over a vehicle to see pop-up details.
-   Click on a vehicle to view the details on the status bar at the bottom of the map.

1.  ### **Reduced browser window width**
    

If the browser window is reduced in width, the software menu will eventually become hidden.

If this happens:

-   Click on the menu icon in the top right-hand corner. The icon will turn grey and the menu will drop down as vertical list.

-   Select the required menu item. The item will be highlighted.

-   Click again on the menu icon to close the list.

1.  ### **Map controls**
    

Our Maps are powered by Google Maps Premier. You can navigate (move your view) in three dimensions in any Google Map – up/down, left/right and zoom in/out.

1.  ### **Panning the map**
    

-   To pan the map up/down or left/right, click the hand cursor on the map and hold it while dragging the map. **Note:** If you click but don’t drag straight away, a location menu may pop up; to close this, click the X in the right-hand corner of the pop-up box.
-   If you are using a touch screen device, pan the map using your finger or stylus.

1.  ### **Zoom in/out of the map**
    

-   To zoom in and out the map, you can:

-   use the ‘+’ and ‘-’ Google icons;
-   use the mouse tracker wheel;
-   spread/pinch on a touch screen;
-   or use any other interface control

-   To zoom into Street View, grab and drag Pegman to the required location.

1.  ### **View map full screen**
    

-   Click on the window icon in the top right of the map to view it full screen.

-   To exit full screen, either:

-   press the **ESC** key,
-   or click on the map icon again.

1.  ### **Logging out of SynX**
    

-   To log out, click on your name in the top right of the screen and select ‘Log out’ from the drop-down menu.

The system returns to the log-in page.

**Note:** For security reasons, you will be logged out of the system if there has been no activity for a defined period.

1.  **Map view**

1.  ### **Viewing vehicles in real time**
    

Map view shows all of the vehicles in their real-time location as well their ignition state on the map (known as Last Location Report). It also shows the direction the vehicles are/where travelling in by the direction of the vehicle icon. The map updates in real-time as the vehicles move (web page automatically refreshes every 15 seconds) so you can follow their route.

The default view upon logging into the system is the whole fleet.

As you zoom in, you will notice that the vehicle icons are in different colours:

Green – vehicle has its engine on

Red – vehicle has its engine off

Yellow – vehicle is not sending data updates

Orange – vehicle is idling

Grey cog – PTO on vehicle is in use

**Incognito icon** – Private driving (when the fob is off)

**Note:** If you notice a vehicle is yellow and tracking should be operating, contact Synx Support.

1.  ### **Vehicle clustering**
    

For large fleets, or where there are a lot of vehicles in a small area, the system can cluster the vehicles on the map when viewing the area small scale.

-   Click on the icon in the top right of the map as shown in the previous image. The vehicles will cluster and the icon shows the number of vehicles in that area.

The clustered vehicle icons are coloured-coded to the predominant ignition/data state of the vehicles as stated in the previous section.

-   Progressively zoom into the map to ungroup the vehicles and eventually show them separately in large scale.

-   Click the cluster icon again if you wish to turn off clustering.

1.  ### **View and follow selected vehicles**
    

-   To view and follow a group of vehicles only, select a group from the drop-down menu of Vehicle Groups (or type and search if the list is very long) in the Report Generator. This could be any group that was created to suit your fleet requirements, such as by site, department, vehicle type, or even all active/non-active vehicles.

The map will automatically zoom into the area covered by the vehicle group.

1.  ### **View and follow a single vehicle**
    

To view and follow one vehicle only, either:

-   Select the vehicle from the drop-down menu of Vehicles (or type and search if the list is very long). **Note:** The list can be shortened if the correct Vehicle Group is selected first.

The map will automatically zoom into the local area of the single vehicle.

Alternatively, view and follow one vehicle only by selecting the vehicle on the map.

-   Hover your mouse over a vehicle to see pop-up details of the time the vehicle last updated, its location and speed.

-   Click on the vehicle and the map zooms in to street level.

You will see that the vehicle is selected in the Vehicles list in the Report Generator and real-time details displayed in the status bar.

1.  ### **Viewing historic routes**
    

You can see historic routes your vehicles have driven on the map. This is covered in the Creating Reports section.

1.  ### **Using map layers to organise map features**
    

The maps have the following layers, which can be toggled on/off. Some layers can overlap.

1.  ### **Map layer**
    

This is the default 2-D view with standard tiles.

-   If not already in this view, click on Map. This view will remain unless changed to Satellite or OSM maps.

1.  ### **Map with Terrain**
    

This indicates the physical characteristics of the area displayed and is particularly useful in rural areas.

-   Click on Map and check the Terrain box on the drop-down menu.

-   Turn off the terrain layer by clicking on Map and unchecking the Terrain box.

1.  ### **Satellite**
    

This is the photographic view of the area. The labels (road and place names) can be toggled on/off.

-   Click on Satellite. This view will remain unless changed to Map or OSM maps. The default view is with the labels (road names and place names) showing.

-   To turn off the labels (useful for viewing off-road routes), click on Satellite and uncheck the Labels box.

1.  ### **OSM**
    

This is OpenStreetMaps, which is user-generated content. It provides an additional option to view data and is the best quality for industrial/urban areas and for creating geofences.

1.  ### **Traffic**
    

Live traffic information can be overlaid on the standard and satellite maps (toggle on/off).

-   In either Map or Satellite view, click on Traffic.

As in Google, green lines show traffic is flowing, while orange through to dark red lines show increasing traffic congestion.

-   Turn off the traffic layer by clicking on Traffic again.

1.  ### **Locations**
    

Your custom locations in the database can be overlaid on the standard and satellite maps (toggle show/hide). Locations are covered in Section XX.

-   In either Map or Satellite view, click on Locations.

-   Turn off the locations layer by clicking on Locations again.

1.  ### **Routes**
    

Pre-defined set routes added to system can be overlaid on the standard, satellite and OSM maps (toggle show/hide).

-   Click on Routes to bring up a pop-up list of all routes in the system.

-   Select the route to add to the map.

-   Hide the route by clicking again on Routes.

1.  ### **Searching for locations**
    

Using the map search function is covered in the sections on creating locations and geofences.

1.  ### **Using Google Street View**
    

You cannot view your vehicles in Street View as these are made up of Google images, but you can, as examples, view the exact location a vehicle has passed or stopped, follow its route, or see where it was speeding.

To enable Street View, either:

-   Drag the Pegman and drop onto the required blue highlighted road (**note:** if a road is not highlighted in blue, then there are no Street View images available).

Or

-   Right click on a road and select Street View from the pop-up menu.

Once in Street View, you can:

-   Pan the view by left clicking and dragging the view left or right.
-   Follow the road by clicking on the arrow icons displayed on the road or click the arrow under the cursor.
-   Expand to full screen by clicking on the full screen icon in the top right-hand corner of the screen.

-   Exit full screen by pressing the ESC key or clicking on the reduce screen icon in the right-hand corner of the screen.

-   Also view directly in Google Maps by clicking on the link in the top left-hand corner. Google Street Maps will open in a new browser tab so the map is still open in SynX as you left it.
-   Exit Street View and return to the Map view by clicking on the arrow in the left-hand corner of the screen.

1.  ### **Adding a custom location**
    

Adding custom locations is covered in the creating locations sections.

1.  ### **Sending a location to a phone**
    

To send GPS coordinates by SMS:

-   Right-click the location you wish to send.

-   Select Send Location to Phone from the menu.

This will open up the messaging screen with the GPS coordinates attached to the message.

-   Type in more text in the message, if required.

-   Select the recipient(s).

-   Scroll down to the bottom of the screen and click on Send Message.

1.  ### **Locating nearest vehicles**
    

Using Google Map’s advanced geocoding capabilities, Nearest Vehicle Calculator will pinpoint on the map where the next job is, for example, and which is the best vehicle to send. The system lists the three nearest vehicles to the location.

-   Right-click on the map at the exact location.

-   Click on Nearest Vehicles. The three nearest will be listed in ascending order of distance (by road) from the location and estimated driving times.

-   To send a message to the driver, invoke the messaging feature as described in the previous section.

1.  **Viewing data in reports**

1.  ### **SynX Report Generator**
    

The majority of the reports are created using the Report Generator on the left-hand side of the screen. Each report has standard columns, but these can be customised.

The drop-down menus in the Report Generator make it easy for you to select the criteria required for the report. You can choose:

-   Vehicle group (could be type of vehicle, depot, department)
-   Vehicles (one, some (e.g. team) or all)
-   Name of report
-   Dates from/to
-   Shift times (if required)
-   Additional criteria for some reports includes:

-   name of Location or geofence for Location Report
-   name of Route for Route Completion Report
-   type of Alert for specific Exception Reports
-   Driver groups and specified Drivers for Driver Activity Report
-   Driver groups, specified Drivers and name of the Alert for Driver Alerts Summary

In addition, some reports allow for further narrowing of the results with the addition of the Duration calculator. You can run the reports for only those events over or under a specified time, for example Stops or Idling greater than the specified time.

**Note:** Depending on your fleet management requirements, some of the reports and features may not be available in your system.

1.  ### **Creating a report**
    

Unless otherwise stated for a report, they are all created in the following way:

-   Select the Vehicle Group – leave as All Groups or select a group from the drop-down menu.

-   Next select the Vehicles – leave as All Vehicles or select one from the drop-down menu. If the list is very long, start typing the Vehicle name/number in the search box and the list will shorten. For example, in the image below, typing 1 immediately shortens the list to only vehicle numbers beginning with 1.

-   Next, select the type of report you wish to run from the drop-down list.

-   Click on the Begin and End Calendars to select the date range for the report.

-   If appropriate, check the Limit by Shift Time box and select the start and end times from the drop-down lists. The report will only display data between the time range you selected.

-   Click on the View Report button. The report will populate and appear in place of the map. ‘Reports’ will be highlighted in the functionality (top) menu.

1.  ### **Other statistical formats**
    

Some of the reports, where appropriate, include a chart view as well as the table view. This is a useful way to compare data, such as between vehicles, dates, time of day, etc.

Where appropriate, some reports include a map, such as showing where stops or idling have occurred. If not appropriate for the report, the Chart or Map view will be greyed out.

-   Click on the Chart tab or Map tab, if available, at the top of the report.

1.  ### **Exporting data**
    

Historical data in SynX reports can be exported to spreadsheet programs, either emailed to recipients or downloaded locally.

-   To export the data as .csv or .xls format, click on the Export icon above the far right column in the reports.

-   Type in the recipient’s email address if sending the data, or chose from the list of addresses.

-   Select the export format from the drop-down list – either CVS or EXCEL/XLS.

-   Select whether to send the data by email or download as a file onto your system.

-   Press the green Export button.

1.  ### **Last Location Report**
    

This report differs from the others as it is capturing real-time information so the dates cannot be changed.

-   Ensure you are in Live Map view.

-   Select the Vehicle Group and Vehicles.

-   Select Last Location from the drop-down list of reports.

-   Select Reports from the top menu and the real-time data will appear in a table.

The standard information contained in this report is:

-   Vehicle:        Vehicle name/number
-   Date/Time:         Time of last update
-   Last Engine Off Time:         Time engine was last turned off
-   Private Mode:        Private mode enabled by driver, Yes/No
-   Location:         Location at last update
-   Speed:        Speed at last update
-   Engine:        Engine current status, On/Off
-   Driver:        Name of driver if assigned to a vehicle
-   GPS Odometer:        GPS-based mileage counter at last update
-   GPS Signal:        Indication of current GPS signal strength
-   GSM Signal:        Indication of current GSM signal strength
-   Fleet Number:         Number of the fleet (if assigned)
-   PTO:        PTO status if PTO is enabled
-   Engine Warning Light        If enabled in vehicle, icon turns orange if on

**Note:** The columns in the Last Location Report are customisable by user profile, e.g. removing PTO column if not applicable to the fleet.

1.  ### **Fleet Summary Report**
    

The Fleet Summary Report shows high-level activity information about all the vehicles in the whole fleet (or a selected vehicle group).

-   Select the Vehicle Group and Vehicles.

-   Select Fleet Summary from the drop-down list of reports.

-   Choose whether to only show private use – select Yes to Private Mode Only or No to include all business and private use. Note: the default is No.

-   Select the date range, and shift time, if required.

-   Click on the View Report button.

The standard information (can be customised) contained in this report covers the following for the selected period:

-   Description:        Vehicle description
-   Registration:         Vehicle number plate
-   No. Journeys:         Total number of separate journeys undertaken
-   Travel Time:        Total hours and minutes vehicle was moving
-   Distance:         Total distance (in km or miles) covered
-   Private Distance:         Total distance (in km or miles) covered for private use
-   Idling Time:        Total hours & minutes vehicle had ignition on but not moving
-   Days Driven:        Number of days the vehicle was driven out of the total period.
-   % Days Driven:        The number of days as a percentage of the total.

The totals for the fleet (or selected group of vehicles) are in the pink row.

The Distance and Idling Times can be sorted into ascending and descending order. The default is for the summary to be listed in descending distance order, so the higher use vehicles are at the top. This is because travelling and idling use fuel, and over- and under-utilised vehicles can be easily identified in the report.

-   To sort the columns into a different order, click the small black arrow on the column heading.
-   To export the data as .csv or .xls format, click on the Export icon above the far right column.

1.  ### **Summary Report**
    

Similar to the Fleet Summary Report, but the Summary Report can be filtered further to one or more vehicles, and shows start/stop time of the day’s activities and a route replay on the map.

-   Select the Vehicle Group and Vehicles.

-   Select Summary from the drop-down list of reports.

-   Choose whether to only show private use – select Yes to Private Mode Only or No to include all business and private use. Note: the default is No.

-   Select the date range, and shift time, if required.

-   Click on the View Report button.

The totals for the fleet (or selected group of vehicles) are in the pink row.

The standard information (can be customised) contained in this report covers the following for each day during the selected period:

-   Date:         Date vehicle was driven
-   First Start Time:        The first time the engine was started that day in hours & minutes
-   Last Stop Time:        The last time the engine was turned off that day in hours & minutes
-   Shift Duration:         The time between the first engine on and the last engine off
-   No. Journeys:        Total number of separate journeys undertaken that day
-   Travel Time:         Total hours and minutes vehicle was moving
-   Distance:         Total distance (in km or miles) covered that day
-   Private Distance:        Total distance (in km or miles) covered for private use
-   Idling Time:        Total hours & minutes vehicle had ignition on but not moving
-   View route:        Mapped route of the journey between start time and last stop time

The No. Journeys is also a hyperlink to the Journey Report for that vehicle on that day. This report is covered in the next section.

-   To export the data as .csv or .xls format, click on the Export icon above the far right column.

1.  ### **View route**
    

-   To view on the map a replay of the journeys of any vehicle on any day, click the View Route icon at the end of that row.

The journeys are drawn from start to finish mapping out the total driven that day. The first journey starts at the green pin and is displayed in red. The end location of the last journey is displayed with a red icon. Usually the end red pin is in the same place as the start green pin as vehicles return to the site at the end of the day.

The rows show the individual driving events and driving time intervals (usually every ~30 seconds) that sent data from the GPS unit to the software, such as driver activity including harsh braking.

The standard information contained in this table covers the following for each driving event and part of the journey:

-   Date:         Shows the date of the journeys
-   Location:        Where the driving event took place
-   Speed:        Snapshot of the speed when driving data was sent
-   Driver:        Assigned driver to vehicle
-   Satellites:        Number of satellites tracking the vehicle GPS
-   Engine:        Ignition on or off
-   Event:        Vehicle data updates on movement and time intervals
-   Coordinates:        Map coordinates of location

-   Click on rows in the table to view the corresponding event on the journey as black arrows.

-   Use the map controls to zoom into parts of the journey or view in Street View.
-   By default, the map and table are split 50/50 on the screen. To show the map full screen, click on the Split Screen icon (top icon) in the top left-hand corner. The system will remember your choice.

-   As the map will fill now the screen, scroll down to view the table rows.

-   Click the icon again to return to 50/50 split screen.

-   To view only the map in full screen, click on the Full Screen icon (bottom icon) in the top left-hand corner.

-   To exit the full screen mode, click on the icon again or press the ESC key.

-   To export this detailed data in .csv format, click on the Excel icon in the top right-hand corner of the table.
-   To save the report to Google Earth in .kml format, click the Google Earth icon next to the Excel icon. Saved places can be imported into Google Earth on the device on which you saved them.

1.  ### **Chart view**
    

The Summary chart view graphs the Shift Duration, Travel Time, Idling Time and Distance per vehicle per day.

-   Click on the Chart tab.

-   Hover the cursor over the bars to see the information in a pop-up, such as date, duration of the shift and number of journeys in the shift.

1.  ### **Journeys Report**
    

The Journey Report show all journeys made by each vehicle/driver in a day. A journey is defined as engine turned on to engine turned off.

-   Select the Vehicle Group and Vehicles.

-   Select Journeys from the drop-down list of reports.

-   Select the date range, and shift time, if required.

-   Click on the View Report button.

The totals for the fleet (or selected group of vehicles) are in the pink row.

The standard information (can be customised) contained in this report covers the following for each day during the selected period:

-   Driver:         Assigned driver to vehicle
-   Start Time:        The time the journey started (engine on)
-   Start Location:        Where the journey started
-   Stop Time:         The time the journey started (engine off)
-   Stop Location:        Where the journey ended
-   Journey Time:         Length of time in hours & minutes that the engine was on
-   Idling Time:         Length of time the engine was on but vehicle did not move
-   Distance:        Distance (in km or miles) of journey
-   Private Distance:        Total distance (in km or miles) covered for private use
-   Route Playback:        Mapped route of the journey between start time and stop time

-   To export the data as .csv or .xls format, click on the Export icon above the far right column.

1.  ### **View route**
    

-   To view on the map a replay of the journey of any vehicle on any day, click the Route Playback icon at the end of that row.

The journey is drawn from start (green pin) to finish (red pin) mapping out the total driven that day.

The rows show the individual driving events and driving time intervals (usually every ~30 seconds) that sent data from the GPS unit to the software, such as driver activity including harsh braking.

The standard information contained in this table covers the following for each driving event and part of the journey:

-   Date:         Shows the date of the journey
-   Location:        Where the driving event took place
-   Speed:        Snapshot of the speed when driving data was sent
-   Driver:        Assigned driver to vehicle
-   Satellites:        Number of satellites tracking the vehicle GPS
-   Engine:        Ignition on or off
-   Event:        Vehicle data updates on movement and time intervals
-   Coordinates:        Map coordinates of location

-   Click on rows in the table to view the corresponding event on the journey as black arrows.

-   Use the map controls to zoom into parts of the journey or view in Street View.
-   By default, the map and table are split 50/50 on the screen. To show the map full screen, click on the Split Screen icon (top icon) in the top left-hand corner. The system will remember your choice.

-   As the map will fill now the screen, scroll down to view the table rows.

-   Click the icon again to return to 50/50 split screen.

-   To view only the map in full screen, click on the Full Screen icon (bottom icon) in the top left-hand corner.

-   To exit the full screen mode, click on the icon again or press the ESC key.

-   To export this detailed data in .csv format, click on the Excel icon in the top right-hand corner of the table.
-   To save the report to Google Earth in .kml format, click the Google Earth icon next to the Excel icon. Saved places can be imported into Google Earth on the device on which you saved them.

1.  ### **Chart view**
    

The Journey chart view graphs the Travel Time and Idling Time per vehicle per day.

-   Click on the Chart tab.

1.  ### **Stops Report**
    

A Stop is categorised by any time the vehicle’s engine is turned off; the stop ends when the ignition is started. A Stops Report shows the location and duration of every stop made.

-   Select the Vehicle Group and Vehicles.

-   Select Stops from the drop-down list of reports.

-   Select the date range, and shift time, if required.

-   Click on the View Report button.

The total stop duration for the fleet (or selected group of vehicles) is in the pink row.

The standard information (can be customised) contained in this report covers the following for each day during the selected period:

-   Stop Time Begins:         The time (in hours & minutes) the engine was turned off
-   Stop Location:        Where the engine was turned off
-   Stop Time End:         The time (in hours & minutes) the engine was turned on
-   Stop Duration:         Length of time (in hours & minutes) the engine was off
-   Event:        Engine off
-   Map:        View the location of the Stop on the map
-   Street View:        View the location of the Stop in Street View

In addition, the Stop Report can be filtered to only display stops greater or lesser than a certain length of time in minutes. The default is greater than 1 minute.

-   Click on the down arrow and select either > (greater than) or < (less than).

-   Type the number minutes in the text box.

-   Click on the green refresh icon.

The table will be refreshed with the filtered data.

-   To export the data as .csv or .xls format, click on the Export icon above the far right column.

1.  ### **View all Stops on the map**
    

-   In Table view, click on the Map tab. The map will include all the stops specified in the Report Generator and Duration filter.

As with vehicles in the Last Location Map, Stops may be clustered if spread over a large area.

-   Use the Google tools to zoom in to see the stop locations.

The active stop (usually the first stop) will have a bouncing red pin so it can be distinguished against the others.

-   To scroll through the stops, click on Previous Stop or Next Stop.
-   To see details of the stop (vehicle/driver, location, date, duration, and stop start and end times), hover the cursor over the red pin and the details will pop up.

-   To view the map in full screen, click on the Full Screen icon (bottom icon) in the top left-hand corner.

-   To exit the full screen mode, click on the icon again or press the ESC key.        

1.  ### **View Stops individually on the map**
    

-   To view an individual stop location on the map, click the Map icon (red pin) at the end of that row. The red pin bounces up and down over the duration time, and the vehicle and location details are in the status bar.

**Tip:** Turning on the OSM layer can give more information about the stop location (in this case, the vehicle has stopped by shops).

-   To scroll through the stops on the map, click on Previous Stop or Next Stop.

-   To return to the table view, click on the Table tab.

-   To view an individual stop location in Street View, click the Pegman at the end of the row.

-   To scroll through the stops in Street View, click on Previous Stop or Next Stop.

-   To return to the table view, click on the Table tab.

1.  ### **Idling Report**
    

Idling is classified as ignition on but the vehicle not moving (speed of vehicle is zero). An Idling Report shows the location and duration of all idling.

-   Select the Vehicle Group and Vehicles.

-   Select Idling from the drop-down list of reports.

-   Select the date range, and shift time, if required.

-   Click on the View Report button.

The idling duration for the fleet (or selected group of vehicles) is in the pink row.

The standard information (can be customised) contained in this report covers the following for each day during the selected period:

-   Idling Start:         The time (in hours & minutes) the vehicle stopped with engine on
-   Location:        Where the idling event occurred
-   Idling Stop:         The time (in hours & minutes) the vehicle starting moving
-   Idling Duration:         Length of time (in hours & minutes) the vehicle stopped with engine on
-   Event:        Engine on, speed zero
-   Map:        View the location of the idling on the map
-   Street View:        View the location of the idling in Street View

-   As with the Stops Report, to filter the idling results to less or more than a number of minutes, click on the down arrow and select either > (greater than) or < (less than). The default is greater than 1 minute.

-   Type the number minutes in the text box.

-   Click on the green refresh icon.

The table will be refreshed with the filtered data.

-   To export the data as .csv or .xls format, click on the Export icon above the far right column.

1.  ### **View all idling events on the map**
    

-   In Table view, click on the Map tab. The map will include all the idling specified in the Report Generator and Duration filter.

As with vehicles in the Last Location Map, idling events may be clustered if spread over a large area.

-   Use the Google tools to zoom in to see the idling locations.

The active idling event (usually the first) will have a bouncing blue pin so it can be distinguished against the others.

-   To scroll through the idling events, click on Previous Idling or Next Idling.
-   To see details of the idling (vehicle/driver, location, idling start and end times, and duration), hover the cursor over the blue pin and the details will pop up.

-   To view the map in full screen, click on the Full Screen icon in the top left-hand corner.

-   To exit the full screen mode, click on the icon again or press the ESC key.        

1.  ### **View idling individually on the map**
    

-   To view an individual idling location on the map, click the Map icon (blue pin) at the end of that row. The blue pin bounces up and down over the duration time, and the vehicle and location details are in the status bar.

**Tip:** Turning on the OSM layer can give more information about the idling location (in this case, the vehicle has been idling by shops for 10 minutes).

-   To scroll through the idling events on the map, click on Previous Idling or Next Idling.

-   To return to the table view, click on the Table tab.

-   To view an individual idling location in Street View, click the Pegman at the end of the row.

-   To scroll through the idling events in Street View, click on Previous Idling or Next Idling.

-   To return to the table view, click on the Table tab.

1.  ### **Stops/Idling Report**
    

The Stop/Idling Report combines the information from the Stops Report and Idling Report.

-   Select the Vehicle Group and Vehicles.

-   Select Stops/Idling from the drop-down list of reports.

-   Select the date range, and shift time, if required.

-   Click on the View Report button.

The total stops/idling duration for the fleet (or selected group of vehicles) is in the pink row.

The standard information (can be customised) contained in this report covers the following for each day during the selected period:

-   Event Start:         The time (in hours & minutes) the vehicle stopped or began idling
-   Location:        Where the stop or idling event occurred
-   Event Stop:         The time (in hours & minutes) the vehicle starting moving
-   Event Duration:         Length of time (in hours & minutes) the vehicle stopped (engine off & on)
-   Event:        Engine off; or Engine on, speed zero
-   Map:        View the location of the stop or idling on the map
-   Street View:        View the location of the stop or idling in Street View

As in the Stops Report and Idling Report, red pins indicate stops and blue pins indicate idling.

-   As with the Stops Report and Idling Report, to filter the stops/idling results to less or more than a number of minutes, click on the down arrow and select either > (greater than) or < (less than). The default is greater than 1 minute.

-   Type the number minutes in the text box.

-   Click on the green refresh icon.

The table will be refreshed with the filtered data.

-   To export the data as .csv or .xls format, click on the Export icon above the far right column.

1.  ### **View all stops/idling events on the map**
    

-   In Table view, click on the Map tab. The map will include all the stops and idling specified in the Report Generator and Duration filter.

As with vehicles in the Last Location Map, stops and idling events may be clustered if spread over a large area.

-   Use the Google tools to zoom in to see the stops and idling locations.

The active stop or idling event (usually the first event) will have a bouncing red or blue pin so it can be distinguished against the other events. Depending on the type of the first event (stop or idling) or one selected on the map, the Previous/Next will scroll through either stops or idling.

-   To scroll through the stop/idling events, click on Previous Stops/Idling or Next Stops/Idling.
-   To see details of the stop/idling (vehicle/driver, location, start and end times, and duration), hover the cursor over the red/blue pin and the details will pop up.

-   To view the map in full screen, click on the Full Screen icon in the top left-hand corner.

-   To exit the full screen mode, click on the icon again or press the ESC key.        

1.  ### **View a stop/idling individually on the map**
    

-   To view an individual stop/idling location on the map, click the Map icon (red pin for stop or blue pin for idling) at the end of that row. The pin bounces up and down over the duration time, and the vehicle and location details are in the status bar.

-   To scroll through the stop/idling events on the map, click on Previous Stop/Idling or Next Stop/Idling.

-   To return to the table view, click on the Table tab.

-   To view an individual stop/idling location in Street View, click the Pegman at the end of the row.

-   To scroll through the stop/idling events in Street View, click on Previous Stop/Idling or Next Stop/Idling.

-   To return to the table view, click on the Table tab.

1.  ### **Locations Report**
    

The Locations Report allows for analysis of any given location or area (geofence) stored in the Locations Database; for instance, what activity occurred at a site or within an area for the last week.

For instructions on how to create locations and geofences to store in the Locations Database, see Section XX.

-   Select the Vehicle Group and Vehicles.

-   Select Locations from the drop-down list of reports.

-   Select the location or geofence from the drop-down list of locations.

-   Select the date range, and shift time, if required.

-   Click on the View Report button.

The total time spent at the location or within the geofence for the fleet (or selected group of vehicles) is in the pink row.

The standard information (can be customised) contained in this report covers the following for each day during the selected period:

-   Event Time Begin:        The time the vehicle entered the boundary of the location
-   Location:        Where the event happened
-   Event Time End:         The time the vehicle left the boundary of the location
-   Event Duration:        Length of time (in hours & minutes) vehicle was within location
-   Event Type:         Vehicle passing through on journey or stopped within location
-   Map Route:        Route of the journey or exact location of stop shown on map

-   To export the data as .csv or .xls format, click on the Export icon above the far right column.

1.  ### **View route or stop**
    

-   To view on the map a stop or a replay of the journey of a vehicle within the location, click the Map Route icon or red pin Stop icon at the end of that row.

The route travelled inside the location boundary (as defined in SynX) is shown as starting at the green pin and ending at the red pin, which also therefore shows the direction the vehicle was travelling in.

If we look at the boundary created for the location, we can see that the route and the stop both just touch on it. For instructions on how to create locations, see Section XX.

-   By default, the map and table are split 50/50 on the screen. To show the map full screen, click on the Split Screen icon (top icon) in the top left-hand corner. The system will remember your choice.

-   As the map will fill now the screen, scroll down to view the table rows.

-   Click the icon again to return to 50/50 split screen.

-   To view only the map in full screen, click on the Full Screen icon (bottom icon) in the top left-hand corner.

-   To exit the full screen mode, click on the icon again or press the ESC key.

-   Hover the cursor over the route and the red line will become a black arrow to show the direction of travel, and the corresponding event will be highlighted in the rows.

-   To return to the table view from the map view, either re-click on Reports in the navigation menu at the top or click on the View Report button.

-   To export this detailed data in .csv format, click on the Excel icon in the top right-hand corner of the table.
-   To save the report to Google Earth in .kml format, click the Google Earth icon next to the Excel icon. Saved places can be imported into Google Earth on the device on which you saved them.

1.  ### **Route Completion Summary Report**
    

For vehicles or drivers working on set routes, the Route Completion Summary Report shows at a glance the percentage of work that has been completed (or not).

**Note:** For how to add set routes to SynX, see Section XX.

-   Select the Vehicle Group and Vehicles.

-   Select Route Completion Summary from the drop-down list of reports.

-   Select the Route from the drop-down list of pre-defined routes.

-   Select the date range, and shift time, if required.

-   Click on the View Report button.

The totals for the fleet (or selected group of vehicles) are in the pale purple row.

The standard information contained in this report covers the following for the selected period:

-   Date:         The date the routes were driven during the selected period
-   Route Name:        The name of the pre-set route
-   % Driven:         The percentage of the route completed by the vehicle
-   % Operating:        The percentage of the route the PTO equipment was engaged

-   To export the data as .csv or .xls format, click on the Export icon above the far right column.

A breakdown of the route can be seen by clicking on the number in the % Driven column or the % Operating column, and this will open the Route Completion Report.

1.  ### **Route Completion Report**
    

The Route Completion Report shows the breakdown of a pre-set route and whether each part of the route has been covered by the vehicle and if the PTO equipment was operating.

-   To open the Route Completion Report, click on the number in the % Driven column or the % Operating column for a route in the Route Completion Summary Route.

Each route is broken up into a number of checkpoints (as many as required to cover the route adequately). At each checkpoint you can see if the vehicle is driving through the checkpoint and also if the output equipment is engaged. If the answer is no to either of those, the text will be in red.

The standard information contained in this report covers the following for the selected period:

-   Location:         The checkpoint on the route
-   Driven:        Has the vehicle passed the checkpoint?
-   Operating:         Was PTO equipment operating as the vehicle passed the checkpoint?

-   The Operating Report can be directly accessed from the Route Completion Report by clicking on the link in the top right-hand corner.

1.  ### **Operating Report**
    

For vehicles with output connections activated, the Operating Report shows a breakdown of actual operating times, mileage and map views.

There are two ways to access the Operating Report:

-   Click on the link for the Operating Report in the Route Completion Report.

Or

-   Within the Report Generator, select the Vehicle Group and Vehicle.

-   Select Operating Activity from the drop-down list of reports.

-   Select the Auxiliary Vehicle from the drop-down list.

-   Select the date range, and shift time, if required.

-   Click on the View Report button.

As with some other reports, the Operating Report can be filtered to only display durations greater or lesser than a certain length of time in minutes. The default is greater than 0 minutes.

-   Click on the down arrow and select either > (greater than) or < (less than).

-   Type the number minutes in the text box.

-   Click on the green refresh icon.

The table will be refreshed with the filtered data.

-   To export the data as .csv or .xls format, click on the Export icon above the far right column.

1.  **View route on the map**

-   Click on the Route Playback icon at the end of a row to see the checkpoint on the map.
-   Click on the Map icon above the Route Playback column to see the whole route on the map.

The rows show the individual driving events and driving time intervals (usually every ~30 seconds) that sent data from the GPS unit to the software.

The standard information (can be customised) contained in this table covers the following for each checkpoint on the route (**note:** the information depends on the auxiliary vehicle; this example shows a salt spreader):

-   Time:         Time the vehicle passed the checkpoint
-   Speed:        Snapshot of the speed when passing the checkpoint
-   Visible Satellites:        Number of satellites tracking the vehicle GPS
-   Engine:        Ignition on or off
-   Spreader:        PTO equipment engaged or not
-   Width:        Width of salt spread in metres
-   Rate:        Spread rate in grams per metre
-   Salt Error        PTO malfunction
-   Spot Blast:        Function on or off

-   Click on rows in the table to view the corresponding checkpoint on the route.

-   Scroll through the checkpoints by clicking on Previous/Next between the map and the table.

-   Use the map controls to zoom into parts of the journey or view in Street View.
-   By default, the map and table are split 50/50 on the screen. To show the map full screen, click on the Split Screen icon (top icon) in the top left-hand corner. The system will remember your choice.

-   As the map will fill now the screen, scroll down to view the table rows.

-   Click the icon again to return to 50/50 split screen.

-   To view only the map in full screen, click on the Full Screen icon (bottom icon) in the top left-hand corner.

-   To exit the full screen mode, click on the icon again or press the ESC key.

1.  ### **Operating Summary Report**
    

The Operating Summary Report gives an overview of PTO operating data for each vehicle on each day in the selected period.

-   Select the Vehicle Group and Vehicle.

-   Select Operating Summary from the drop-down list of reports.

-   Select the date range, and shift time, if required.

-   Click on the View Report button.

The totals for the fleet (or selected group of vehicles) are in the pink row.

The standard information (can be customised) contained in this report covers the following for each day during the selected period:

-   Date:         Date vehicle/PTO operated
-   Activity:        What took place on that date
-   Engine on Time:        Time the engine was turned on
-   Operating Start Time:        Time the PTO equipment was turned on
-   Operating End Time:        Time the PTO equipment was turned off
-   Engine off Time:         Time the engine was turned off
-   Shift Time:         Length of time (in hours, mins & secs) of driver’s shift
-   Engine on Duration:        Length of time (in hours, mins & secs) engine was turned on
-   Operating Duration:        Length of time (in hours, mins & secs) PTO was operating
-   Idling Duration:        Length of time (in hours, mins & secs) engine on & speed zero
-   Utilisation %        Percentage of operating time against shift time
-   Idling %        Percentage of idling time against shift time

1.  ### **Driving Summary Report**
    

The Driving Summary Report displays a graph and statistics to analyse how each vehicle is being driven. It includes measurements of speeding, harsh braking, rapid acceleration and harsh cornering.

This report is part of SynX Perform, our fuel management software combining the GPS features of SynX Move with an advanced interface to analyse driver behaviour and fuel consumption in order to reduce costs, improve efficiency and, above all, improve driver safety.

-   Click on Driving Style in the top menu. It will open to the default screen of Driving Summary.

The information contained in this report covers the following for driving behaviour during the selected period:

-   Rank:         Ranking of vehicles/drivers based on Score %
-   Vehicle:        Vehicle or driver
-   Speeding %:        Percentage of events of speeding over the speed limit
-   Harsh Braking:        Events per 100km
-   Rapid Acceleration:        Events per 100km
-   Harsh Cornering:        Events per 100km
-   Score %:        Calculated from driving events & their weightings (see Settings)

To filter the results:

-   Click anywhere on the filter options above the chart.

-   Click on the first date to change the start of the required period.

-   Click on the required date and the calendar will close.

-   Click on the second date to set the end of the required period.

-   Click on the required date and the calendar will close.

-   Alternatively, you can click on one of the set periods at the bottom of the calendar pop-up. This will automatically populate the date range.

-   To filter by group, either select a Vehicle Group or a Driver Group by clicking on the respective down arrow and select the group from the drop-down list.

The drivers can also be ranked from ‘best’ to ‘worst’ or ‘worst’ to ‘best’. To define who is a good/bad driver we have found the best method is to rank drivers on the number of bad driving events they generate per 100 km (**Note**: this can be changed to miles if preferred).

-   Choose whether to order the results in ascending or descending order (default is ascending).

-   If you wish to remove the group from the filter so all vehicles or drivers will be included, click on the small x next to the drop-down arrow.

-   Click on the green Apply Filter button. To cancel all the changes, click the Close button. The filter box will close.

-   The numbers in the table are reflected in the chart – hover the cursor over the bars to see the details.

Each type of driving event can be turned on or off in the report.

-   To hide a driving event type(s) from the chart, click on the relevant event type(s) in the chart legend.

-   To turn off a driving event type(s) in the table, uncheck the box next to the event type(s) in the heading of the table. This will automatically hide the event type in the chart.

1.  ### **View a vehicle’s speeding events**
    

-   To see details of each occurrence of speeding and its location on the map, click on the speeding number in the table; for example, clicking on 9.69% (see screen above) will show all speeding occurrences for JHarrington.

The map shows a bouncing red pin which denotes the location of the first event in the table.

-   To see other locations, either click on the address or the map icon at the end of the row.

-   Use the Google map controls to zoom into the map or Street View if required.

The information covers the following for each speeding event during the selected period:

-   Vehicle:         Vehicle/driver
-   Type Description:        Speeding
-   Location:        Address of speeding event
-   Private Mode:        Reads Yes only if private mode has been activated by the driver
-   Allowed Value:        Speed limit of road in km/h (or mph in UK)
-   Value:        Actual speed recorded in km/h (or mph in UK)
-   % Over Limit:        Percentage recorded speed is over speed limit of road
-   Date:        Date & time stamp of speeding event by GPS tracker
-   Map:        Click to view speeding event on map

The columns with black up/down arrows in the headers can be sorted into ascending or descending order.

-   Click the arrow once to sort into descending order (largest value first); click again to re-sort into ascending order (smallest value first).

-   To return to the main report, click on the Return to Driving Summary link above the map.

1.  ### **View a vehicle’s harsh braking, rapid acceleration and harsh cornering events**
    

**Note:** These driving events are all similar in terms of the table information, so the following details cover harsh braking only but can apply to any of them.

-   To see details of each harsh braking occurrence for a vehicle and its location on the map, click on the corresponding number in the table, for example 62.74 for JHarrington in the following image.

The map shows a bouncing red pin which denotes the location of the first event.

-   To see other locations, either click on the address or the map icon at the end of the row.
-   Use the Google map controls to zoom into the map or Street View if required.

The information covers the following for each driving event during the selected period:

-   Vehicle:         Vehicle/driver
-   Type Description:        Type of driving event, e.g. harsh braking
-   Location:        Address of driving event
-   Private Mode:        Reads Yes only if private mode has been activated by the driver
-   Date:        Date & time stamp of driving event by GPS tracker
-   Map:        Click to view driving event on map

The date can be sorted into ascending or descending order.

-   Click the arrow once to sort into descending date/time order (latest time first); click again to re-sort into ascending order (earliest time first).

-   To return to the main report, click on the Return to Driving Summary link above the map.

1.  ### **View all of a vehicle’s driving events**
    

-   To see details of each occurrence of all driving event types and their location on the map, click on the vehicle in the table; for example, clicking on JHarrington will show all driving events for that vehicle/driver.

The map shows a bouncing red pin to denote the location of the first event in the table.

-   To see other locations, either click on the address or the map icon at the end of the row.

-   Use the Google map controls to zoom into the map or Street View if required.

The information covers the following for each speeding event during the selected period:

-   Vehicle:         Vehicle/driver
-   Type Description:        Type of driving event
-   Location:        Address of speeding event
-   Private Mode:        Reads Yes only if private mode has been activated by the driver
-   Allowed Value:        Speed limit of road in km/h (or mph in UK)
-   Value:        Actual speed recorded in km/h (or mph in UK)
-   % Over Limit:        Percentage recorded speed is over speed limit of road
-   Date:        Date & time stamp of driving event by GPS tracker
-   Map:        Click to view driving event on map

The columns with black up/down arrows in the headers can be sorted into ascending or descending order. The default is descending date order.

-   Click the arrow once to sort into descending value order; click again to re-sort into ascending order.

-   To return to the main Summary report, click on the Return to Driving Summary link above the map.

1.  ### Driving Summary Settings
    

In Settings, you can choose the driving events to include and assign weightings to them, depending on the importance you place on them.

-   In the Driving Style menu on the left-hand side, click on Settings.

-   Uncheck parameters (driving events) if you do not want to include them in the overall driving performance; default is for all to be checked.

-   Change a weighting by clicking on the green square and sliding it to the required position; the percentage figure will change accordingly.

-   Click on the Apply Changes button or click Cancel if you wish to discard your changes.

-   Return to the Driving Summary Report by clicking on Driving Summary in the Driving Style menu on the left-hand side.

1.  ### **Speed Summary Report**
    

The Speed Summary Report is populated from alerts set to trigger when the vehicle exceeds the set speed limit for the road. (**Note:** Alerts are covered in Section XX.) This report drills down deeper into the speeding value in the Driving Summary Report by separating it into percentage ranges over the limit.

As with the Driving Summary Report, the Speed Summary Report is part of SynX Perform, our fuel management software combining the GPS features of SynX Move with an advanced interface to analyse driver behaviour and fuel consumption in order to reduce costs, improve efficiency and, above all, improve driver safety.

-   Click on Driving Style in the top menu. It will open to the default screen of the Driving Summary Report.

-   Click on Speed Summary in the Driving Style menu on the left-hand side.

The information contained in this report covers the following for speeding events during the selected period:

-   Vehicle:        Vehicle or driver
-   Total:        Total % of speeding events over road speed limit
-   1-10% Over Limit:        Percentage of speeding events 1-10% over speed limit
-   11-20% Over Limit:        Percentage of speeding events 11-20% over speed limit
-   21-30% Over Limit:        Percentage of speeding events 21- 30% over speed limit
-   \> 30% Over Limit:        Percentage of speeding events more than 30% over speed limit

To filter the results:

-   Click anywhere on the filter options above the chart.

-   Click on the first date to change the start of the required period.

-   Click on the required date and the calendar will close.

-   Click on the second date to set the end of the required period.

-   Click on the required date and the calendar will close.

-   Alternatively, you can click on one of the set periods at the bottom of the calendar pop-up. This will automatically populate the date range.

-   To filter by group, either select a Vehicle Group or a Driver Group by clicking on the respective down arrow and select the group from the drop-down list.

The drivers can also be ranked from ‘best’ to ‘worst’ or ‘worst’ to ‘best’. To define who is a good/bad driver we have found the best method is to rank drivers on the total percentage of speeding above the speed limit they generate (**Note**: can be changed to miles if preferred).

-   Choose whether to order the results in ascending or descending order (default is ascending).

-   If you wish to remove the group from the filter so all vehicles or drivers will be included, click on the small x next to the drop-down arrow.

-   Click on the green Apply Filter button. To cancel all the changes, click the Close button. The filter box will close.

-   The numbers in the table are reflected in the chart – hover the cursor over the bars to see the details.

Each speeding range can be turned on or off in the report.

-   To hide a speeding range(s) from the chart, click on the relevant range(s) in the chart legend.

-   To turn off a speeding range(s) in the table, uncheck the box next to the range(s) in the heading of the table. This will automatically hide the speeding range in the chart.

1.  ### **View one speeding range for a vehicle**
    

-   To see details of each occurrence of a speeding range and their locations on the map, click on the number in the table; for example, clicking on 1.48% (see screen above) will show all Kevin’s speeding occurrences of 21% to 30% Over Limit.

The map shows a bouncing red pin which denotes the location of the first speeding event.

-   To see other locations, either click on the address or the map icon at the end of the row.

-   Use the Google map controls to zoom into the map or Street View if required.

The information in the table covers the following for each speeding event during the selected period:

-   Vehicle:         Vehicle/driver
-   Type Description:        Speeding
-   Location:        Address of speeding event
-   Private Mode:        Reads Yes only if private mode has been activated by the driver
-   Allowed Value:        Speed limit of road in km/h (or mph in UK)
-   Value:        Actual speed recorded in km/h (or mph in UK)
-   % Over Limit:        Percentage recorded speed is over speed limit of road
-   Date:        Date & time stamp of speeding event by GPS tracker
-   Map:        Click to view speeding event on map

The columns with black up/down arrows in the headers can be sorted into ascending or descending order.

-   Click the arrow once to sort into descending order (largest value first); click again to re-sort into ascending order (smallest value first).

-   To return to the main report, click on the Return to Speed Summary link above the map.

1.  ### **View all of a vehicle’s speeding events**
    

-   To see details of each speeding event and their locations on the map, click on the Vehicle name or the Total value in the table; for example, clicking on Peter or 4.49% will show all speeding events for that vehicle/driver.

The map shows a bouncing red pin to denote the location of the first speeding event.

-   To see other locations, either click on the address or the map icon at the end of the row.

-   Use the Google map controls to zoom into the map or Street View if required.

The information in the table covers the following for each speeding event during the selected period:

-   Vehicle:         Vehicle/driver
-   Type Description:        Speeding
-   Location:        Address of speeding event
-   Private Mode:        Reads Yes only if private mode has been activated by the driver
-   Allowed Value:        Speed limit of road in km/h (or mph in UK)
-   Value:        Actual speed recorded in km/h (or mph in UK)
-   % Over Limit:        Percentage recorded speed is over speed limit of road
-   Date:        Date & time stamp of speeding event by GPS tracker
-   Map:        Click to view speeding event on map

The columns with black up/down arrows in the headers can be sorted into ascending or descending order.

-   Click the arrow once to sort into descending order (largest value first); click again to re-sort into ascending order (smallest value first).

-   To return to the main Summary report, click on the Return to Speed Summary link above the map.

1.  **Sending Scheduled Reports**

1.  ### **Locate Scheduled Reports**
    

Scheduled daily/weekly/monthly reports sent to specific personnel/management are accessed from the Settings menu.

-   Click on the user account name on the far right of the tabbed menu bar.

-   Click on Settings.

-   Click on Manage Reports in the Settings menu.

The window opens with a table of current scheduled reports.

The standard information (can be customised) contained in this table covers the following:

-   Report Name:        Name of the Scheduled Report
-   Vehicle Group:        Vehicle Group included in the Scheduled Report
-   Vehicle:         Single vehicle included in the Scheduled Report
-   Reports:        Pre-defined Generated Reports included in the Scheduled Report
-   Schedule:        Frequency of Scheduled Report
-   Created By:        User who created the Scheduled Report
-   Actions:        Edit or delete the Scheduled Report, and show the schedule history

1.  ### **Create new Scheduled Report**
    

-   Click on the blue **New Schedule Report** button above the list of Scheduled Reports.

The form opens with blank fields and three tabs. **Note:** fields with an asterisk must have criteria added.

-   Type a subject name, which will be the name of the Scheduled Report being created (e.g. Evening Journeys).

-   Type a brief description of what the Scheduled Report is about (e.g. All journeys after 6pm).

The Scheduled Report can be filtered by vehicles or drivers.

To filter by **vehicles**:

-   To select a vehicle group to be included in the Scheduled Report, either leave ‘All Vehicles’ (default) or choose one or more vehicle groups from the Filter By Vehicle Group drop-down list.
-   Alternatively, select one vehicle from the Vehicle drop-down list if the Scheduled Report is to only include a specific vehicle.

To filter by **drivers**:

-   To select a driver group to be included in the Scheduled Report, either leave ‘All Driver Groups’ (default) or choose one or more driver groups from the Filter By Driver Group drop-down list.
-   Alternatively, select one driver from the Driver drop-down list if the Scheduled Report is to only include a specific driver.

-   Choose the reports to be included in the Scheduled Report by selecting one or more from the drop-down list (e.g. Journey; Summary).

**Note:** To delete any criteria, click on the ‘x’.

-   Click on the **Next** button to advance to the Configuration tab.

-   Select Daily, Weekly or Monthly from the Schedule drop-down menu (default is Daily).

-   Select the two-hour time slot for creating and sending the report from the Schedule Time drop-down menu (default time is 6am – 8am).

-   Choose the file format (PDF or CSV) in the File Format drop-down menu (default is PDF).

-   Choose the language of the report (currently English, French or Spanish) from the Report Language drop-down menu (default is English).

-   Choose the required time zone (currently Dublin, Paris or Madrid) from the Time Zone drop-down menu (default is Dublin).

-   Choose the preferred unit of distance (kilometres or miles) from the Distance Unit drop-down menu (default is KM, but can be changed to miles for UK users).

-   Type in the start and end shift times that the Scheduled Report will cover in the Shift Time Begin and Shift Time End fields. **Note:** to amend the times, highlight the hours or minutes and click on the up/down arrows.

-   Click on the **Next** button to advance to the Alert and Permission tab.

-   Select the name(s) of the intended recipient(s) of the Scheduled Report from the Send Reports To drop-down menu.

-   Select the name(s) of the users who will be granted access to see, edit and delete the Scheduled Report from the Who Can Manage This Schedule? drop-down menu.

-   Click on the **Confirm** button to create the new Scheduled Report.

SynX will briefly display a message in the bottom left of the screen to confirm the new Scheduled Report has been created.

The new Scheduled Report has been added to the list.

1.  ### **View Scheduled Report (for recipients only)**
    

-   Click on the Download link in the email. The file will open in the preferred format.

-   Print or download the file as required.

1.  ### **Edit Scheduled Report**
    

-   Click on the **green** **edit** icon at the end of the required Scheduled Report row.

-   Select the tab where you want to make the change (e.g. Configuration).

-   Make the required change (e.g. change Daily to Weekly schedule).

-   Click Next to go to the next tabbed page. Repeat if necessary.

-   Click Confirm to complete the update.

SynX will briefly display a message in the bottom left of the screen to confirm the Scheduled Report has been updated.

1.  ### **View schedule history**
    

-   Click on the **blue schedule history** icon at the end of the required Scheduled Report row.

The Schedule History list includes the following:

-   Report Name:        The name of the Scheduled Report.
-   Start Date:        The start date for the vehicle activity.
-   End Date:        The end date for the vehicle activity (**Note:** this is a weekly report, so  
    the start and ends dates are a week apart.)

-   To order the reports in ascending or descending order, click once or twice respectively in the required column header (e.g. in the image above, this is the End Date).

-   Click on the **Download** button to download the report in the preferred format (PDF or CSV).

1.  ### **Delete Scheduled Report**
    

-   Click on the **red delete** icon at the end of the required Scheduled Report row.

-   Click **Delete** on the confirmation pop-up.

SynX will briefly display a message in the bottom left of the screen to confirm the Scheduled Report has been deleted.

1.  **Alerts (exception reporting)**

Exception reporting shows instances in which actual performance deviated from expectations for driving style and safety (speeding, harsh braking, rapid acceleration, idling) or for location and activity (when vehicles start or stop or when they reach a precise location or get in or out of a designed area). These instances can be sent as alerts by email or text to specified recipients, and are viewable in reports.

The following list of alerts is not exhaustive and alerts can be set for any requirement that may arise.

-   Operating out of hours
-   Speeding above threshold
-   Engine On/Off
-   Location activity
-   Geofence entry/exit
-   Unexpected changes in fuel levels/usage
-   Unauthorised use (driver-ID not presented)
-   Excessive idling
-   Rapid/harsh acceleration
-   Harsh braking
-   Impact with both engine on and off
-   Excessive stop time
-   Low battery alerts
-   Failed/disconnected battery alerts
-   External vehicle power off (vehicle battery removed)
-   External vehicle power on (vehicle battery connected)
-   Tow away detected (vehicle is moving, but ignition is off)
-   Tow away completed (vehicle not moving for 5 minutes after a tow away period)
-   GPS tamper (occurs when GPS antenna is removed or a fault occurs)
-   GSM signal jamming detected

1.  ### **View alerts in a report**
    

There are currently two ways to view alerts:

-   Select Alerts from the Reports drop-down menu in the Report Generator.

-   Click on Alerts in the tabbed menu.

Whichever method is used, the default report opens, which contains all alerts for all vehicles for the current day (00.01 to the time the report opened) as shown in the previous image.

The standard information (can be customised) contained in this report covers the following for each exception occurrence:

-   Date:         Date the exception occurrence took place
-   Start Time:        When the exception occurrence started
-   Stop Time:        When the exception occurrence ended
-   Location:        Where the exception occurrence took place
-   Speed:        Speed recorded by the GPS tracker
-   Alert Detail:        Information relevant to the exception occurrence, e.g. the speed limit.

-   To view a specific alert, select that alert from the Alerts drop-down menu.

-   Select the vehicle group that you wish to include in the report from the Vehicle Group drop-down menu, or leave as All Vehicle Groups (default).

-   Select an individual Vehicle from within that group on which to run the report, or leave as All Vehicles (default).

-   Choose the required Begin and End Dates from the Calendar for the period you wish the alerts to cover.

-   If you wish to filter the results to include only alerts incurred during the shift time, check the Limit by Shift Time box, and choose Begin and End Times from the respective drop-down menus. (**Note:** it is possible to view out of hours alerts by selecting evening/nights times.)

The example above shows all occurrences of all vehicles driving at least 10km per hour over the road speed limit on one day.

-   Click the blue map icon on the right side of the row to view that incident on the map.

-   Use the Google map functions to zoom in/out of the map, or view the location in Street View.

The information bar at the bottom shows which number alert of the total alerts is being viewed (e.g. Alert 1 of 49), and the details of the vehicle/driver, date and time, and the location.

-   To view scroll though the alerts, click on the Previous Alert and Next Alert links on the far right of the information bar.

-   To return to the table of alerts, click on the Table tab.

-   To go directly to the location in Street View from the table, click on the yellow Street View icon.

-   As well as the features mentioned above for the map view, Street View includes an option to view in Google Maps. To do this, click on the View on Google Maps link in the top left-hand corner.
-   To return to the map view, click on the left-facing arrow.

-   To return to the table of alerts, click on the Table tab.

**Note:** If the report includes the current day, the results upon returning to the table may now include more occurrences as the report is re-run when it reloads.

1.  ### **Managing alerts**
    

Users with sufficient permissions can create, amend and delete alerts.

-   Click on the user account name on the far right of the tabbed menu bar.

-   Click on Settings.

-   Click on Manage Alerts in the Settings menu.

A table containing all the current available alerts is presented.

1.  ### **Create an alert**
    

-   Click on the **\+ Add New Alert** button above the table. The Setup form opens.

-   Type in the alert name, using something meaningful to describe what it is for (e.g. Idling Over 1 Minute).

-   Choose whether to assign the alert by Vehicles or Vehicle Group in the drop-down menu.

-   If you choose to assign by vehicle, choose the Vehicle Group from the next drop-down list. A list of the vehicles in that group will appear below.

-   Click on the required vehicle in the list, holding down the CTRL key to select more, or click on the link underneath to select all the vehicles in the group.

-   If you choose to assign by vehicle group, a list of all the groups appears below. Choose the required Vehicle Group from the list, holding down the CTRL key to select more, or click on the link underneath to select all the vehicle groups.

-   After selecting the vehicle(s) or vehicle group(s), click on the **Next** button.

Next you will add the parameters for the alert. Combining parameters and values create different alerts, and additional parameters can be added to the available list by administrative users.

As an example, to create an alert on vehicles idling for longer than a minute, do the following:

-   Select **Engine** from the drop-down list of parameters, **Equals** from the drop-down list of Operators and **On** from the drop-down list of values.

-   Click on + Add New **Parameter**.

-   Select **Speed** from the drop-down list of parameters, **Equals** from the drop-down list of Operators and **0** from the drop-down list of values.

-   Click on + Add New **Parameter**.

-   Select **Active Duration** from the drop-down list of parameters, **Greater Than** from the drop-down list of Operators and **1** from the drop-down list of values.

This means SynX will create an alert every time a selected vehicle has its engine on without moving for longer than a minute.

As you can see, the Values change depending on the Parameter.

-   Click the **Next** button.

-   Check the relevant email and/or SMS boxes for the intended recipients of the alert.

You can also enter the URL of an application if the alert is to be deliver there.

-   Check the details for the alert; if you need to make any changes, click the **Change** link for that section.

-   Click the **Save** button.

The new alert is now included in the list of alerts and is immediately active.

Instructions on creating alerts for locations and geofences are included in Section XX.

Help with creating specific alerts can be sought from the Transpoco Support Team.

1.  ### **Amend an existing alert**
    

-   From the list of alerts, click on the relevant **Edit** button.

-   To amend the selected Vehicles / Vehicle Groups, click on the **Change** link above the vehicles/groups.
-   To amend the parameters, click on the **Change** link above the parameters.
-   Amend the recipients and mode of alert delivery if required.

-   Click on the **Update** button.

1.  ### **Delete an existing alert**
    

-   From the list of alerts, click on the relevant **Delete** link.

-   Click the **OK** button on the confirmation pop-up.

1.  **Locations Database**

The Locations Database can hold an unlimited number of your organisation’s locations and geofences. SynX refers to geofences as locations, as the location is saved and the virtual perimeter is set around it as desired. These virtual perimeters can be any shape and can cover any area on the map, including:

-   a building and grounds
-   rail station or airport
-   city or county boundaries
-   a specific road or route

Analysis of any given location or geofence, such as the amount of mileage done inside or outside a geofence, the locations visited within the geofence, and the time spent, is shown in the Locations Report.

1.  ### **View the locations in the database**
    

-   Click on Locations in the tabbed menu. The list of the stored locations is shown on the left and the map of the locations on the right.

**Note:** When there are a lot of locations, the system will cluster them on the map when viewing the area small scale.

-   Use the Google Map functions to progressively zoom into the map to ungroup the locations and eventually show them separately in large scale.
-   To filter the locations, type in the required criteria in the Filter Location text book. For example, ‘Airport’ will bring up all the airports in the database, and a town or city name will bring up all locations with that name.

1.  ### **View an individual location or geofence**
    

-   Click on Locations in the tabbed menu.

There are two ways to view a location/geofence:

-   Click on the location name in the list; or
-   Click on the location icon on the map.

Whichever method is used, a pop-up appears including the following information and options:

-   Address:        Address of the location if available
-   Group:        Types of locations/geofences can be assigned to a group
-   GPS Coordinates:        Latitude and longitude map coordinates of the location
-   Edit Custom Location:        Link to make changes to the location/geofence
-   Send Location to Phone:        Coordinates and map URL sent using SynX messaging
-   Street View:        View the location in Google Street View
-   Location Report:        View the activity for the location in a Location Report
-   Nearest Vehicles:        See the three nearest vehicles in real-time

1.  ### **Add a custom location/geofence**
    

-   Click on Locations in the tabbed menu.

There are two ways to begin adding a location/geofence: 1) search for a location; or 2) click on the map. The second method is quicker but it requires first locating the exact address on the map, whereas the first method will find the address for you.

1.  **Search for a location**

-   Type a postcode/eircode/zip code, name or any part of the address in the search box.

-   SynX will search for and bring up the required address or a list of possible matches.

-   Click on the required address.

The map immediately changes to that location and places a blue pin and a pop-up menu.

1.  **Click on the map**

-   Right-click onto the required location on the map. **Note:** It can help to find a building by using the OSM map layer.

This will instantly add a blue pin and a pop-up menu.

Whichever method to pin the location is used, the instructions from herein are the same.

-   Click on **Add as Custom Location** on the pop-up menu.

A grey square will appear around the location (the map will automatically zoom in if necessary). (**Note:** ignore the yellow pin in the image – this denotes a test tracker at the Transpoco office.)

You will notice that there is a point on each corner and on each side – these are used to resize and reshape the box to fit the location and buffer zone, or in this case, to create the perimeter around the building.

-   Grab the points by left-clicking and holding with the mouse, then dragging to the required location. Release the mouse button when the point is in the right place.

**Note:** You will see that after a point is moved, another point is created between it and its neighbour, which provides more flexibility.

**Note:** To undo the last point movement, click on the undo icon.

-   Continue resizing and repositioning the polygon around the required boundary.

**Note:** Moving the mouse while the cursor is inside the polygon will move the whole polygon.

**Note:** If working on very large, complicated polygons, such as around a district, it is advisable to save the polygon intermittently while working, and continuing by editing the location. See the next section for how to do this.

-   Add the address details on the left.

-   If preferred, the location can be added to a new or existing group (to assist with reporting).

-   Choose a colour for the icon – this can help identify the type of location on the map.

-   Click on the **Save Location** button. The location/geofence is now added to the Locations Database.

**Note:** The perimeter shape disappears from the map and an icon is placed in the top left corner; however, the perimeter is remembered by the system and will appear if the user selects Edit Custom Location.

Once the location is stored in the database, it can be used in reports and alerts, including the Locations Report.

1.  ### **Edit a location**
    

-   Either click on the location name in the list or click on the location icon on the map.

-   Click on the **Edit Custom Location** link in the pop-up menu.

The polygon appears along with the location details.

-   Make the required changes to the location details on the left and/or the polygon.

-   Click on the **Save Location** button to save the changes.

1.  **Mobile app**

1.  **Messaging**

1.  **Fuel control**

1.  **Vehicles and drivers**

1.  **Service management**

1.  **Vehicle walk around checks**

1.  **Import wizard**

1.  **Orders and billing**

1.  **Users and permissions**

1.  **Support and training**

1.  **API resources**

  Page |
