# Orders and billing

Back to home

1.  Knowledge Base 
3.  How to Order More Trackers 

-   Logging-in to your Transpoco account
    -   Login to your Transpoco account
    -   Transpoco Smartphone Apps
    -   2 Factor Authentication
    -   System requirements
    -   Overview of Transpoco
    -   Implementation
-   How to organise your account to achieve the best results
    
-   How to use each feature - step by step guides
    -   Users and permissions
    -   Walkaround Checks module
    -   Fuel/Electric Vehicles Module
    -   Maintain Module
    -   Dashboard
    -   Messaging module
    -   Scheduled Reports
-   How to Order More Trackers
    
-   Live Map
    
-   Cameras
    -   FAQ
-   Webinar Videos
    
-   Walkaround Checklists
    -   Walkaround Checklists
    -   Driver App
    -   Alerts
-   Reports
    -   Reports
    -   Viewing data in reports
-   Fuel
    
-   Dashboard
    
-   Maintain Module
    
-   Driving Style
    
-   Locations
    
-   Cost Management (TCO) Report
    
-   The Notification Features
    
-   Hardware and Installation
    
-   Removal & Repair of Hardware
    -   Requesting a Repair or a Deinstallation
-   Cameras & GDPR Guidelines
    
-   Scheduled Reports
    
-   Safety Program
    
-   Fleet Manager App
    
-   Users & Permissions
    
-   Alerts
    
-   Policies & Documents
    
-   Privacy Policy and Terms & Conditions
    -   RoPA
-   API
    
-   Transpoco User Manuals
    
-   Settings
    -   Garage
-   Whats New?
    
-   Account Mangement Services
    
-   Driver ID process
    
-   Security
    
-   Transpoco Locate
    
-   Subscriptions & Invoices
    
-   Tutorial videos
    
-   Cancelling your account
    
-   VOR
    
-   Installation
    
-   BIKLY
    

# Orders and billing

### **1\. Add new vehicles**

Here you can place an order for new tracked and non-tracked vehicles to your account.

-   Click on **Settings** in the menu header.

-   Click on **Add New Vehicle** under ‘Orders & Billing’ in the drop-down menu.

The self-service Order Placement wizard will open.

### **1.1 Order new tracked vehicles**

-   Click on the **blue** **Add Vehicles** link.
-   Type in the text box the number of vehicles you wish to add to your account.

-   Click on **Submit Order**. 

### **1.2 Order new non-tracked vehicles**

  

-   Click on the **green** **Add Vehicles** link.

-   Either type in the required number in the **Number of Vehicles** box, or click on the up and down arrows on the right to select the required number.

-   Click on **Submit Order**.   

### **2\. View and process orders**

View the status of orders placed using the self-service order system and through Transpoco sales team.

-   Click on **Settings** in the menu header.

-   Click on **View Orders** under ‘Orders & Billing’ in the drop-down menu.

The order history list will open.

-   You can use **Search** to find any particular orders. 
-   You can click drop down button besides the **Show 10** to view more rows.

**Note:** for self-service orders, you will need to use the login of the person that created the order.

### **2.1 Pay for an order**

When an order is raised, it will appear in the list with a status of ‘NEW’.

-   Open the order by clicking on **Click to View Order**.

**Note:** the status of the order will change to ‘Viewed’.

-   Click on **Terms and Conditions** under the ‘Order’ heading.

-   Read through the terms and conditions and if you are in agreement with them, click on

**Accept Terms**.

-   Click on **Continue**.

You are then taken to Step 2 for arrange payment.

-   Click on **Pay with Credit Card**.
-   Follow the instruction and then click **Pay** once you are ready.

-   You can also click on **Gpay.**

-   Click on **Pay**.

The process moves to Step3, Order Complete.

-   To view the quote/order, click on **Here** at the bottom of the message.

Now the order is complete, the status will change to ‘Install Required’ in the table of orders, and you will be contacted to schedule a date for installing the unit.
