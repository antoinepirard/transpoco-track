# Walkaround Checks: How do I reset my password in the Transpoco Driver app?

Back to home

1.  Knowledge Base 
3.  Walkaround Checklists 
5.  Driver App 

-   Logging-in to your Transpoco account
    -   Login to your Transpoco account
    -   Transpoco Smartphone Apps
    -   2 Factor Authentication
    -   System requirements
    -   Overview of Transpoco
    -   Implementation
-   How to organise your account to achieve the best results
    
-   How to use each feature - step by step guides
    -   Users and permissions
    -   Walkaround Checks module
    -   Fuel/Electric Vehicles Module
    -   Maintain Module
    -   Dashboard
    -   Messaging module
    -   Scheduled Reports
-   How to Order More Trackers
    
-   Live Map
    
-   Cameras
    -   FAQ
-   Webinar Videos
    
-   Walkaround Checklists
    -   Walkaround Checklists
    -   Driver App
    -   Alerts
-   Reports
    -   Reports
    -   Viewing data in reports
-   Fuel
    
-   Dashboard
    
-   Maintain Module
    
-   Driving Style
    
-   Locations
    
-   Cost Management (TCO) Report
    
-   The Notification Features
    
-   Hardware and Installation
    
-   Removal & Repair of Hardware
    -   Requesting a Repair or a Deinstallation
-   Cameras & GDPR Guidelines
    
-   Scheduled Reports
    
-   Safety Program
    
-   Fleet Manager App
    
-   Users & Permissions
    
-   Alerts
    
-   Policies & Documents
    
-   Privacy Policy and Terms & Conditions
    -   RoPA
-   API
    
-   Transpoco User Manuals
    
-   Settings
    -   Garage
-   Whats New?
    
-   Account Mangement Services
    
-   Driver ID process
    
-   Security
    
-   Transpoco Locate
    
-   Subscriptions & Invoices
    
-   Tutorial videos
    
-   Cancelling your account
    
-   VOR
    
-   Installation
    
-   BIKLY
    

# Walkaround Checks: How do I reset my password in the Transpoco Driver app?

## How to change your password in the app or reset it if forgotten.

From the login screen, tap on **RESET PASSWORD**.

Screenshot\_20190725\_114705\_com.synx.driver

Type in your email address used for accessing SynX.

Tap on **RESET PASSWORD**.

Screenshot\_20190725\_115014\_com.synx.driver     Screenshot\_20190725\_115153\_com.synx.driver

SynX will now send an email to that address with a link to set a new password.

Open the email and click on the green **Reset your password** button.

Screenshot\_20190725\_115557\_com.android.email

You will be taken to the reset password page on the website version of SynX.

Based on the password requirements, enter your new password twice. If you want to view the characters, tap on the eye icon.

**NOTE:** All four requirements must be met for the new password to be accepted and the **Set Password** button to be activated.

Screenshot\_20190725\_115840\_com.android.chrome     Screenshot\_20190725\_115936\_com.android.chrome

When valid matching passwords have been entered, tap on **Set Password**.

Screenshot\_20190725\_115957\_com.android.chrome

To return to the app, relaunch it and enter your email address and new password.
