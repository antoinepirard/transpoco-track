# Walkaround Checks: How can I action services/repairs from the Walkaround Dashboard Weekly View?

Back to home

1.  Knowledge Base 
3.  Walkaround Checklists 
5.  Walkaround Checklists 

-   Logging-in to your Transpoco account
    -   Login to your Transpoco account
    -   Transpoco Smartphone Apps
    -   2 Factor Authentication
    -   System requirements
    -   Overview of Transpoco
    -   Implementation
-   How to organise your account to achieve the best results
    
-   How to use each feature - step by step guides
    -   Users and permissions
    -   Walkaround Checks module
    -   Fuel/Electric Vehicles Module
    -   Maintain Module
    -   Dashboard
    -   Messaging module
    -   Scheduled Reports
-   How to Order More Trackers
    
-   Live Map
    
-   Cameras
    -   FAQ
-   Webinar Videos
    
-   Walkaround Checklists
    -   Walkaround Checklists
    -   Driver App
    -   Alerts
-   Reports
    -   Reports
    -   Viewing data in reports
-   Fuel
    
-   Dashboard
    
-   Maintain Module
    
-   Driving Style
    
-   Locations
    
-   Cost Management (TCO) Report
    
-   The Notification Features
    
-   Hardware and Installation
    
-   Removal & Repair of Hardware
    -   Requesting a Repair or a Deinstallation
-   Cameras & GDPR Guidelines
    
-   Scheduled Reports
    
-   Safety Program
    
-   Fleet Manager App
    
-   Users & Permissions
    
-   Alerts
    
-   Policies & Documents
    
-   Privacy Policy and Terms & Conditions
    -   RoPA
-   API
    
-   Transpoco User Manuals
    
-   Settings
    -   Garage
-   Whats New?
    
-   Account Mangement Services
    
-   Driver ID process
    
-   Security
    
-   Transpoco Locate
    
-   Subscriptions & Invoices
    
-   Tutorial videos
    
-   Cancelling your account
    
-   VOR
    
-   Installation
    
-   BIKLY
    

# Walkaround Checks: How can I action services/repairs from the Walkaround Dashboard Weekly View?

## How to action issues found during the walkaround directly from the Weekly View of checklists in the SynX Walkaround Dashboard.

Click on **Walkaround** in the header navigation menu in SynX.

The Walkaround dashboard will open on the default Weekly View.

Click on the **green** **\+ icon** for the defect.

Action service

The New Service form will open.

New service2

The New Service form contains the following fields:

-   **Vehicle:** Prefilled with the vehicle related to the defect
-   **Title:** Defaults to description of defect given during walkaround
-   **Garage:** Drop-down list of garages in database
-   **Service Type:** Drop-down list of service/maintenance types in database
-   **Alerts:** Drop-down list of contacts with your organisation to receive an email

To change the **Title** of the service, type directly in the box.

Select the required **Garage** from the drop-down list.

To make the selected garage the default, check the box next to ‘Save as default Garage’.

Select the required **Service Type** from the drop-down list.

To make the selected service type the default, check the box next to ‘Save as default Type’.

To add **contacts** who will receive an emailed alert about the service, click on the drop-down list and click on a name. If required, repeat to add more names.

**NOTE:** By default, any pictures uploaded about the defect will be attached – **uncheck the box** if this is not required.

Click on **Confirm**.

The alert has now been set up and the chosen recipients will receive an email when the alert is triggered.
