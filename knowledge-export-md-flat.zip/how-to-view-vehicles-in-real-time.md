# How to view vehicles in real time?

Back to home

1.  Knowledge Base 
3.  Live Map 

-   Logging-in to your Transpoco account
    -   Login to your Transpoco account
    -   Transpoco Smartphone Apps
    -   2 Factor Authentication
    -   System requirements
    -   Overview of Transpoco
    -   Implementation
-   How to organise your account to achieve the best results
    
-   How to use each feature - step by step guides
    -   Users and permissions
    -   Walkaround Checks module
    -   Fuel/Electric Vehicles Module
    -   Maintain Module
    -   Dashboard
    -   Messaging module
    -   Scheduled Reports
-   How to Order More Trackers
    
-   Live Map
    
-   Cameras
    -   FAQ
-   Webinar Videos
    
-   Walkaround Checklists
    -   Walkaround Checklists
    -   Driver App
    -   Alerts
-   Reports
    -   Reports
    -   Viewing data in reports
-   Fuel
    
-   Dashboard
    
-   Maintain Module
    
-   Driving Style
    
-   Locations
    
-   Cost Management (TCO) Report
    
-   The Notification Features
    
-   Hardware and Installation
    
-   Removal & Repair of Hardware
    -   Requesting a Repair or a Deinstallation
-   Cameras & GDPR Guidelines
    
-   Scheduled Reports
    
-   Safety Program
    
-   Fleet Manager App
    
-   Users & Permissions
    
-   Alerts
    
-   Policies & Documents
    
-   Privacy Policy and Terms & Conditions
    -   RoPA
-   API
    
-   Transpoco User Manuals
    
-   Settings
    -   Garage
-   Whats New?
    
-   Account Mangement Services
    
-   Driver ID process
    
-   Security
    
-   Transpoco Locate
    
-   Subscriptions & Invoices
    
-   Tutorial videos
    
-   Cancelling your account
    
-   VOR
    
-   Installation
    
-   BIKLY
    

# How to view vehicles in real time?

## Viewing vehicles on the map in real time

Map view shows all of the vehicles in their real-time location as well as their ignition state on the map (known as Last Location Report). It also shows the direction the vehicles are/where travelling in by the direction of the vehicle icon. The map updates in real time as the vehicles move (web page automatically refreshes every 15 seconds) so you can follow their route.

The default view upon logging into the system is all vehicles.

Home Page

You will notice that the vehicle icons are in different colours:

-   Green – vehicle has its engine on
-   Red – vehicle has its engine off
-   Yellow – vehicle is not sending data updates
-   Orange – vehicle is idling

The default icon is a pin, but you can change this to a suitable vehicle icon in the Vehicle Settings.

Home Page - vehicle colours

**Note:** If you notice a vehicle is yellow and tracking should be operating, contact us.
