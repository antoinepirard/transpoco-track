# Canbus reports available: Fuel Used and Plant Utilisation

Back to home

1.  Knowledge Base 
3.  Reports 

-   Logging-in to your Transpoco account
    -   Login to your Transpoco account
    -   Transpoco Smartphone Apps
    -   2 Factor Authentication
    -   System requirements
    -   Overview of Transpoco
    -   Implementation
-   How to organise your account to achieve the best results
    
-   How to use each feature - step by step guides
    -   Users and permissions
    -   Walkaround Checks module
    -   Fuel/Electric Vehicles Module
    -   Maintain Module
    -   Dashboard
    -   Messaging module
    -   Scheduled Reports
-   How to Order More Trackers
    
-   Live Map
    
-   Cameras
    -   FAQ
-   Webinar Videos
    
-   Walkaround Checklists
    -   Walkaround Checklists
    -   Driver App
    -   Alerts
-   Reports
    -   Reports
    -   Viewing data in reports
-   Fuel
    
-   Dashboard
    
-   Maintain Module
    
-   Driving Style
    
-   Locations
    
-   Cost Management (TCO) Report
    
-   The Notification Features
    
-   Hardware and Installation
    
-   Removal & Repair of Hardware
    -   Requesting a Repair or a Deinstallation
-   Cameras & GDPR Guidelines
    
-   Scheduled Reports
    
-   Safety Program
    
-   Fleet Manager App
    
-   Users & Permissions
    
-   Alerts
    
-   Policies & Documents
    
-   Privacy Policy and Terms & Conditions
    -   RoPA
-   API
    
-   Transpoco User Manuals
    
-   Settings
    -   Garage
-   Whats New?
    
-   Account Mangement Services
    
-   Driver ID process
    
-   Security
    
-   Transpoco Locate
    
-   Subscriptions & Invoices
    
-   Tutorial videos
    
-   Cancelling your account
    
-   VOR
    
-   Installation
    
-   BIKLY
    

# Canbus reports available: Fuel Used and Plant Utilisation

## Here you will find more details related to these 2 Canbus reports: Fuel Used and Plant Utilisation

#### **Index:**

-   Canbus Fuel Used
-   Canbus Plant Utilisation

Firstly, to access these reports, you can go to your top menu bar and click on Services, then click on the report you want to see under the "Fuel / Electric Vehicles" section as highlighted below:

#### **Canbus Fuel Used**

If you click on the "Canbus Fuel Used" option, you will be able to filter the report by a selected period (default period is a week), filter by a vehicle group and/or a specific vehicle. 

**Note:** This report uses the Canbus data collected directly from your vehicles. 

In this report, you will see:

-   The list of **vehicle**(s) selected in the filter;
-   The **start and end of the period** selected in the filter; 
-   What was the **fuel level** at the **start and end of the period** selected;
-   The **fuel used in the period** selected which is the difference between the fuel level at the end of the period and the fuel level at the start of the period -> (= fuel at the end - fuel at the start).

#### **Canbus Plant Utilisation**

If you click on the "Canbus Plant Utilisation" option, you will be able to filter the report by a selected period (default period is a week), filter by a vehicle group and/or a specific vehicle. 

**Note:** This report uses the Canbus data collected directly from your vehicles. 

In this report, you will see:

-   The list of **vehicle**(s) selected in the filter;
-   Each **date** of the period selected in the filter;
-   The **first start time** which is the first time the engine is ON during the day;
-   The **last stop time** which is the last time the engine is OFF during the day;
-   The **shift duration** which is the time difference between the first start time and the last stop time -> (= last stop time - first start time);
-   The **engine ON duration** which is the duration in hours and minutes that the vehicle was with the engine ON;
-   The **engine ON percentage** which is the percentage calculation of the engine ON duration related to the shift duration -> (= engine ON duration in minutes / shift duration in minutes);
-   The **working time** which is the duration in hours and minutes of the machinery operating. We use the beacon data and the engine ON as parameters for this. The beacon data will flag if the machinery is working or not;
-   The **idling time** which is the duration in hours and minutes of the machinery with the engine ON but no operation. We use the beacon data and the engine ON as parameters for this. The beacon data will flag if the machinery is working or not;
-   The **working time percentage** which is the percentage calculation of the working time related to the engine ON duration -> (= working time in minutes / engine ON duration in minutes);
-   The **idling time percentage** which is the percentage calculation of the idling time related to the engine ON duration -> (= idling time in minutes / engine ON duration in minutes);
