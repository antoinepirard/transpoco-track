# How to create a walkaround checklist

Back to home

1.  Knowledge Base 
3.  Tutorial videos 

-   Logging-in to your Transpoco account
    -   Login to your Transpoco account
    -   Transpoco Smartphone Apps
    -   2 Factor Authentication
    -   System requirements
    -   Overview of Transpoco
    -   Implementation
-   How to organise your account to achieve the best results
    
-   How to use each feature - step by step guides
    -   Users and permissions
    -   Walkaround Checks module
    -   Fuel/Electric Vehicles Module
    -   Maintain Module
    -   Dashboard
    -   Messaging module
    -   Scheduled Reports
-   How to Order More Trackers
    
-   Live Map
    
-   Cameras
    -   FAQ
-   Webinar Videos
    
-   Walkaround Checklists
    -   Walkaround Checklists
    -   Driver App
    -   Alerts
-   Reports
    -   Reports
    -   Viewing data in reports
-   Fuel
    
-   Dashboard
    
-   Maintain Module
    
-   Driving Style
    
-   Locations
    
-   Cost Management (TCO) Report
    
-   The Notification Features
    
-   Hardware and Installation
    
-   Removal & Repair of Hardware
    -   Requesting a Repair or a Deinstallation
-   Cameras & GDPR Guidelines
    
-   Scheduled Reports
    
-   Safety Program
    
-   Fleet Manager App
    
-   Users & Permissions
    
-   Alerts
    
-   Policies & Documents
    
-   Privacy Policy and Terms & Conditions
    -   RoPA
-   API
    
-   Transpoco User Manuals
    
-   Settings
    -   Garage
-   Whats New?
    
-   Account Mangement Services
    
-   Driver ID process
    
-   Security
    
-   Transpoco Locate
    
-   Subscriptions & Invoices
    
-   Tutorial videos
    
-   Cancelling your account
    
-   VOR
    
-   Installation
    
-   BIKLY
    

# How to create a walkaround checklist

You can create customised checklists using our checklist builder and you can create as many as you want. To start go the **Services menu > Walkarounds > Checklists**

We provide 2 default walkaround checklists to help you to get started:

-   HGV checklist
-   LCV checklist.

To build your checklist click the blue **'New checklist'** button above the **Actions** column.

Start by entering a name and save the title.

To create your first check click the blue **'edit question'** button. 

You will enter the text of the check and then select the type. For example the default is the 'okay or default' (Yes or No) response. You can can change the check to accommodate different outcomes like entering an odometer or entering a number.

You can set a warning time for each check, the minimum is 5 seconds. The user cannot move to the next check until the 5 seconds has elapsed but you can customise this delay.

Finally, if you want to divide your checklist into sub-checklists like inside or outside use more than 1 description in the **Area** field. For example, checks with Inside' in the 'Area' field will appear in a sub-checklist called 'Indoor'.

If you want the checks to appear in a single checklist use the same description in the 'Area' field (like 'Start Checklist').

**Repeat process for each check- click 'New question' to create a new check.**
