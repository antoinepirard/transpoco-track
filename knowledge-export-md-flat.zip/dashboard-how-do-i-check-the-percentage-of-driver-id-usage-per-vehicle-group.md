# Dashboard - How do I check the percentage of Driver ID usage per vehicle group?

Back to home

1.  Knowledge Base 
3.  Dashboard 

-   Logging-in to your Transpoco account
    -   Login to your Transpoco account
    -   Transpoco Smartphone Apps
    -   2 Factor Authentication
    -   System requirements
    -   Overview of Transpoco
    -   Implementation
-   How to organise your account to achieve the best results
    
-   How to use each feature - step by step guides
    -   Users and permissions
    -   Walkaround Checks module
    -   Fuel/Electric Vehicles Module
    -   Maintain Module
    -   Dashboard
    -   Messaging module
    -   Scheduled Reports
-   How to Order More Trackers
    
-   Live Map
    
-   Cameras
    -   FAQ
-   Webinar Videos
    
-   Walkaround Checklists
    -   Walkaround Checklists
    -   Driver App
    -   Alerts
-   Reports
    -   Reports
    -   Viewing data in reports
-   Fuel
    
-   Dashboard
    
-   Maintain Module
    
-   Driving Style
    
-   Locations
    
-   Cost Management (TCO) Report
    
-   The Notification Features
    
-   Hardware and Installation
    
-   Removal & Repair of Hardware
    -   Requesting a Repair or a Deinstallation
-   Cameras & GDPR Guidelines
    
-   Scheduled Reports
    
-   Safety Program
    
-   Fleet Manager App
    
-   Users & Permissions
    
-   Alerts
    
-   Policies & Documents
    
-   Privacy Policy and Terms & Conditions
    -   RoPA
-   API
    
-   Transpoco User Manuals
    
-   Settings
    -   Garage
-   Whats New?
    
-   Account Mangement Services
    
-   Driver ID process
    
-   Security
    
-   Transpoco Locate
    
-   Subscriptions & Invoices
    
-   Tutorial videos
    
-   Cancelling your account
    
-   VOR
    
-   Installation
    
-   BIKLY
    

# Dashboard - How do I check the percentage of Driver ID usage per vehicle group?

## In Synx Dashboard, you can add the metric called “Percentage of Journeys Driver ID Used” and split it per vehicle group.

1\. After clicking “Add New” in Synx Dashboard, add a title by typing a title in the text box related.

2\. Then, choose “ Percentage of Journeys Driver ID Used ” as the Metric type.

3\. Then, the “split per group” option will appear and you need to select it by ticking the box besides the text. 

4\. You can now choose the vehicle groups from the list.

5\. Once you are ready, click on the Save button.

.

6\.  Scroll down to the bottom of the dashboard page, then you will be able to see the Percentage of Journeys with Driver iD Used by vehicle group selected.

7\. You can always edit, refresh and delete this metric from the Dashboard on the top right of the widget.  

 .
