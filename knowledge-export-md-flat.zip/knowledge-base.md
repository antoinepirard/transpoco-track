# Knowledge Base



### How to use each feature - step by step guides

###### In this section you will find step by step guides to help you to start using features and settings in your Transpoco account.

-   How to provide access to your Transpoco account
-   How to use the Fuel/Electric Vehicles module - Fuel Reports
-   How to set-up walkaround checks
-   How to use the Maintain module

See all articles



### Cameras

-   How to request and view video from a camera
-   List of events automatically recorded by AI cameras
-   Cameras Help

See all articles

### Webinar Videos

-   Webinar - How To Implement An Effective Walkaround Check Policy
-   Webinar - Transpoco launches Safely: Our new fleet safety manager as a service to improve costs and reduce accidents
-   Electric Vehicles: How Transpoco can help your fleet transition to an EV fleet webinar
-   How to Improve the Health & Safety of your Fleet with Transpoco Webinar
-   Protecting your fleet with Transpoco's connected camera solutions webinar

See all articles



### Walkaround Checklists

-   Walkaround Checks: How can I be alerted about vehicle checks?
-   Walkaround Checks: How do I delete an alert?
-   Walkaround Module Video Demonstration

See all articles



### Fuel

-   How is Fuel Consumption Calculated?
-   Electric Vehicle (EV) Charging Report
-   EV Suitability Report
-   How can I check the details of my fuel transactions?

See all articles



### Maintain Module

-   Maintenance: Creating a service based on a set distance
-   Creating a service ticket in the Maintain module
-   How to close a service ticket in the Maintain module

See all articles
