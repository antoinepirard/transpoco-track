# How can I see a vehicle's journeys from the Live Map?

Back to home

1.  Knowledge Base 
3.  Fleet Manager App 

-   Logging-in to your Transpoco account
    -   Login to your Transpoco account
    -   Transpoco Smartphone Apps
    -   2 Factor Authentication
    -   System requirements
    -   Overview of Transpoco
    -   Implementation
-   How to organise your account to achieve the best results
    
-   How to use each feature - step by step guides
    -   Users and permissions
    -   Walkaround Checks module
    -   Fuel/Electric Vehicles Module
    -   Maintain Module
    -   Dashboard
    -   Messaging module
    -   Scheduled Reports
-   How to Order More Trackers
    
-   Live Map
    
-   Cameras
    -   FAQ
-   Webinar Videos
    
-   Walkaround Checklists
    -   Walkaround Checklists
    -   Driver App
    -   Alerts
-   Reports
    -   Reports
    -   Viewing data in reports
-   Fuel
    
-   Dashboard
    
-   Maintain Module
    
-   Driving Style
    
-   Locations
    
-   Cost Management (TCO) Report
    
-   The Notification Features
    
-   Hardware and Installation
    
-   Removal & Repair of Hardware
    -   Requesting a Repair or a Deinstallation
-   Cameras & GDPR Guidelines
    
-   Scheduled Reports
    
-   Safety Program
    
-   Fleet Manager App
    
-   Users & Permissions
    
-   Alerts
    
-   Policies & Documents
    
-   Privacy Policy and Terms & Conditions
    -   RoPA
-   API
    
-   Transpoco User Manuals
    
-   Settings
    -   Garage
-   Whats New?
    
-   Account Mangement Services
    
-   Driver ID process
    
-   Security
    
-   Transpoco Locate
    
-   Subscriptions & Invoices
    
-   Tutorial videos
    
-   Cancelling your account
    
-   VOR
    
-   Installation
    
-   BIKLY
    

# How can I see a vehicle's journeys from the Live Map?

## Viewing journeys and route replays for a vehicle selected from the live map in SynX Fleet Manager App

Touch the vehicle on the map.

Screenshot\_20191007\_235433\_com.synx.fleetmanager

Tap on the **Route playback** icon.

The default is to show the current day’s journey(s). If the vehicle has not been used on the current day, the date can be changed.

Tap on **Filters**.

Tap on the **date range**.

Screenshot\_20191009\_013305\_com.synx.fleetmanager   Screenshot\_20191009\_013518\_com.synx.fleetmanager

Tap on the required **date** in the calendar.

Screenshot\_20191009\_013527\_com.synx.fleetmanager

Tap on **Save**.

Details of all the journeys made by that vehicle on that day are shown in time order. Each listing shows the start and stop times and locations.

To view the journey as a route playback, tap on the **On Map** button. The blue pin denotes the start of the journey, and the blue flag denotes the end.

Screenshot\_20191009\_013212\_com.synx.fleetmanager   Screenshot\_20191009\_013153\_com.synx.fleetmanager

To replay the journey, tap the **arrow** under the map. The green pin will follow the route simultaneously with the timeline bar under the map and the time, speed and location changing to reflect the location on the route.

To return to the table view, tap the **back arrow** in the top left of the screen.
