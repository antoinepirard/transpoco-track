# What is the Dashboard?

Back to home

1.  Knowledge Base 
3.  Dashboard 

-   Logging-in to your Transpoco account
    -   Login to your Transpoco account
    -   Transpoco Smartphone Apps
    -   2 Factor Authentication
    -   System requirements
    -   Overview of Transpoco
    -   Implementation
-   How to organise your account to achieve the best results
    
-   How to use each feature - step by step guides
    -   Users and permissions
    -   Walkaround Checks module
    -   Fuel/Electric Vehicles Module
    -   Maintain Module
    -   Dashboard
    -   Messaging module
    -   Scheduled Reports
-   How to Order More Trackers
    
-   Live Map
    
-   Cameras
    -   FAQ
-   Webinar Videos
    
-   Walkaround Checklists
    -   Walkaround Checklists
    -   Driver App
    -   Alerts
-   Reports
    -   Reports
    -   Viewing data in reports
-   Fuel
    
-   Dashboard
    
-   Maintain Module
    
-   Driving Style
    
-   Locations
    
-   Cost Management (TCO) Report
    
-   The Notification Features
    
-   Hardware and Installation
    
-   Removal & Repair of Hardware
    -   Requesting a Repair or a Deinstallation
-   Cameras & GDPR Guidelines
    
-   Scheduled Reports
    
-   Safety Program
    
-   Fleet Manager App
    
-   Users & Permissions
    
-   Alerts
    
-   Policies & Documents
    
-   Privacy Policy and Terms & Conditions
    -   RoPA
-   API
    
-   Transpoco User Manuals
    
-   Settings
    -   Garage
-   Whats New?
    
-   Account Mangement Services
    
-   Driver ID process
    
-   Security
    
-   Transpoco Locate
    
-   Subscriptions & Invoices
    
-   Tutorial videos
    
-   Cancelling your account
    
-   VOR
    
-   Installation
    
-   BIKLY
    

# What is the Dashboard?

## Explains what the Dashboard Module is and how it is used for KPI management reporting.

The dashboard contains metrics that you can personalise for KPI management reporting. These show fleet activity at a glance.

On most metrics, you will be able to compare two periods (e.g. compare last week and this week).

You can resize and drag around the metrics, refresh the metrics individually, and when creating/editing a metric, you can search for the groups or metrics type and define how many vehicles to include (from 5 to 25).

The following metrics are available:

-   **Average Time Driving** in hours/minutes per day per vehicle for the top 10 vehicles in the fleet. The graph is sorted by vehicles with the most driving time descending.
-   **Total Driving Time** in hours/minutes per vehicle for the top 10 vehicles in the fleet. The graph is sorted by vehicles with the most driving time descending.
-   **Average Driving Distance** in km per day per vehicle for the top 10 vehicles in the fleet. The graph is sorted by vehicles with the most driving distance descending.
-   **Total Driving Distance** in km per vehicle for the top 10 vehicles in the fleet. The graph is sorted by vehicles with the most driving distance descending.
-   **Total Driving Days** for the top 10 vehicles in the fleet. The graph is sorted by vehicles with the most days driving descending.
-   **Total Days Not Driving** for the top 10 vehicles in the fleet. The graph is sorted by vehicles with the most days not driving descending.
-   **Average Driving Time** in hours/minutes per day per vehicle for the top 10 vehicles in the fleet. The graph is sorted by vehicles with the most driving time descending.
-   **Average Idling Time** in hours/minutes per day per vehicle for the top 10 vehicles in the fleet. The graph is sorted by vehicles with the most idling time descending.
-   **Fuel Consumption** per vehicle and its related fuel target consumption. The graph shows the 10 ten worst economic fuel vehicles.
-   **Percentage of Checks with Defect** of all vehicles checked in the fleet.
-   **Percentage of Vehicles Driven Without Defect** of all vehicles checked in the fleet.
-   **Speed Summary** shows drivers’ speed over different limits, e.g. when driver’s speed is in the range of 1-10% over road speed limit. The graph shows the top 10 drivers with more driving over limit.
-   **Utilisation** shows the average percentage of days the vehicle / vehicle group / fleet was active. A vehicle is considered active if it drives on a particular day.
