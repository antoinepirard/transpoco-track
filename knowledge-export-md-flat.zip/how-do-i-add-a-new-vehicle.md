# How do I add a new vehicle?

Back to home

1.  Knowledge Base 
3.  Transpoco Locate 

-   Logging-in to your Transpoco account
    -   Login to your Transpoco account
    -   Transpoco Smartphone Apps
    -   2 Factor Authentication
    -   System requirements
    -   Overview of Transpoco
    -   Implementation
-   How to organise your account to achieve the best results
    
-   How to use each feature - step by step guides
    -   Users and permissions
    -   Walkaround Checks module
    -   Fuel/Electric Vehicles Module
    -   Maintain Module
    -   Dashboard
    -   Messaging module
    -   Scheduled Reports
-   How to Order More Trackers
    
-   Live Map
    
-   Cameras
    -   FAQ
-   Webinar Videos
    
-   Walkaround Checklists
    -   Walkaround Checklists
    -   Driver App
    -   Alerts
-   Reports
    -   Reports
    -   Viewing data in reports
-   Fuel
    
-   Dashboard
    
-   Maintain Module
    
-   Driving Style
    
-   Locations
    
-   Cost Management (TCO) Report
    
-   The Notification Features
    
-   Hardware and Installation
    
-   Removal & Repair of Hardware
    -   Requesting a Repair or a Deinstallation
-   Cameras & GDPR Guidelines
    
-   Scheduled Reports
    
-   Safety Program
    
-   Fleet Manager App
    
-   Users & Permissions
    
-   Alerts
    
-   Policies & Documents
    
-   Privacy Policy and Terms & Conditions
    -   RoPA
-   API
    
-   Transpoco User Manuals
    
-   Settings
    -   Garage
-   Whats New?
    
-   Account Mangement Services
    
-   Driver ID process
    
-   Security
    
-   Transpoco Locate
    
-   Subscriptions & Invoices
    
-   Tutorial videos
    
-   Cancelling your account
    
-   VOR
    
-   Installation
    
-   BIKLY
    

# How do I add a new vehicle?

## How to request the addition of new vehicles to your Transpoco account.

You have 2 ways of adding new vehicles either tracked or not tracked.

1\. Click on the 'Settings' option right next to your **name** in the top right of the screen and select ‘Add New Vehicles’ from the drop-down menu.

The Self Service webpage will open.

You can now select to add non tracked vehicles to use the Walkaround App on the right side (green button) or select to track a new vehicle in your fleet (blue button).

By clicking on the blue button, the system will bring a form for you to fill in. Once you are ready, please submit the form with all information required.

Whereas when you click on the green button for adding non tracked vehicles to access the Walkaround App, the system will start a workflow with a few questions.

Click on **Submit Order**.

\-------------

2\. The second way you can add vehicles is by clicking on the **Vehicles** option in the drop-down menu from the 'Settings'.

Then, click on the 'Add New Vehicles' button on the top right of the screen.

The same Self Service webpage will open. You just need to follow the same steps mentioned previously.
