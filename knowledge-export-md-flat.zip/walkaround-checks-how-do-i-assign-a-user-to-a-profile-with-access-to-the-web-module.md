# Walkaround Checks: How do I assign a user to a profile with access to the web module?

Back to home

1.  Knowledge Base 
3.  Walkaround Checklists 
5.  Walkaround Checklists 

-   Logging-in to your Transpoco account
    -   Login to your Transpoco account
    -   Transpoco Smartphone Apps
    -   2 Factor Authentication
    -   System requirements
    -   Overview of Transpoco
    -   Implementation
-   How to organise your account to achieve the best results
    
-   How to use each feature - step by step guides
    -   Users and permissions
    -   Walkaround Checks module
    -   Fuel/Electric Vehicles Module
    -   Maintain Module
    -   Dashboard
    -   Messaging module
    -   Scheduled Reports
-   How to Order More Trackers
    
-   Live Map
    
-   Cameras
    -   FAQ
-   Webinar Videos
    
-   Walkaround Checklists
    -   Walkaround Checklists
    -   Driver App
    -   Alerts
-   Reports
    -   Reports
    -   Viewing data in reports
-   Fuel
    
-   Dashboard
    
-   Maintain Module
    
-   Driving Style
    
-   Locations
    
-   Cost Management (TCO) Report
    
-   The Notification Features
    
-   Hardware and Installation
    
-   Removal & Repair of Hardware
    -   Requesting a Repair or a Deinstallation
-   Cameras & GDPR Guidelines
    
-   Scheduled Reports
    
-   Safety Program
    
-   Fleet Manager App
    
-   Users & Permissions
    
-   Alerts
    
-   Policies & Documents
    
-   Privacy Policy and Terms & Conditions
    -   RoPA
-   API
    
-   Transpoco User Manuals
    
-   Settings
    -   Garage
-   Whats New?
    
-   Account Mangement Services
    
-   Driver ID process
    
-   Security
    
-   Transpoco Locate
    
-   Subscriptions & Invoices
    
-   Tutorial videos
    
-   Cancelling your account
    
-   VOR
    
-   Installation
    
-   BIKLY
    

# Walkaround Checks: How do I assign a user to a profile with access to the web module?

## How system administrators can add a user to a user profile that has access to the Walkaround web module so the user can then access the module.

In the desktop version of Transpoco, click on your name in the top right corner and select **Settings** from the drop-down menu.

Settings menu

Click on ‘Profiles’ within the **Users & Permissions** group.

Settings Menu - Users & Permissions - Profiles

Select a profile that suits the users who will using the Walkaround module (relevant to maintenance), such as Maintenance Manager or Account Executive and click on the **Edit** button.

**Note:** Alternatively you can create a new profile.

User Profiles

On the **Modules** tab, scroll down to the ‘Walkaround’ Module Name.

Check the **Access box** if not already checked.

Edit profile

Scroll down and click on the **Update Profile**

The Walkaround module is now added to the profile.

Next, users are added to the profile.

Select the **Profile Access** tab.

Profile access

Click on the required **Available Users** on the left and they will transfer to ‘Selected Users’ on the right.

**Note:** To remove Selected Users, click on their name and they will transfer back to the Available Users list.

Click on the **Update Profile** button.

The users who need to access the Walkaround module have now been added to a profile with the module activated. Users will now see the Walkaround feature when they access SynX.
