# [Maintenance] How to create a service based on the Time travelled

Back to home

1.  Knowledge Base 
3.  Maintain Module 

-   Logging-in to your Transpoco account
    -   Login to your Transpoco account
    -   Transpoco Smartphone Apps
    -   2 Factor Authentication
    -   System requirements
    -   Overview of Transpoco
    -   Implementation
-   How to organise your account to achieve the best results
    
-   How to use each feature - step by step guides
    -   Users and permissions
    -   Walkaround Checks module
    -   Fuel/Electric Vehicles Module
    -   Maintain Module
    -   Dashboard
    -   Messaging module
    -   Scheduled Reports
-   How to Order More Trackers
    
-   Live Map
    
-   Cameras
    -   FAQ
-   Webinar Videos
    
-   Walkaround Checklists
    -   Walkaround Checklists
    -   Driver App
    -   Alerts
-   Reports
    -   Reports
    -   Viewing data in reports
-   Fuel
    
-   Dashboard
    
-   Maintain Module
    
-   Driving Style
    
-   Locations
    
-   Cost Management (TCO) Report
    
-   The Notification Features
    
-   Hardware and Installation
    
-   Removal & Repair of Hardware
    -   Requesting a Repair or a Deinstallation
-   Cameras & GDPR Guidelines
    
-   Scheduled Reports
    
-   Safety Program
    
-   Fleet Manager App
    
-   Users & Permissions
    
-   Alerts
    
-   Policies & Documents
    
-   Privacy Policy and Terms & Conditions
    -   RoPA
-   API
    
-   Transpoco User Manuals
    
-   Settings
    -   Garage
-   Whats New?
    
-   Account Mangement Services
    
-   Driver ID process
    
-   Security
    
-   Transpoco Locate
    
-   Subscriptions & Invoices
    
-   Tutorial videos
    
-   Cancelling your account
    
-   VOR
    
-   Installation
    
-   BIKLY
    

# \[Maintenance\] How to create a service based on the Time travelled

## When creating a new service you will be able to see the current driven time of the vehicle selected and the time left for the next service.

1.  Log on to your Transpoco account.
2.  Click on the Services > Maintain.  
    
3.  Then click on “+ Service”.  
    
4.  Then you need to choose a vehicle.  
    
5.  Then add a title to this service  
    
6.  Then you could select the service type based on the alert  
      
      
    
7.  You could also add notes to non complete services.  
    
8.  Then choose “Travel Time” as the Schedule option.  
    
9.  You will see the current vehicle hours driven. You will then add the number of hours until next service.  
    

Note:  If needed you can manually update the Engine Hours from the vehicles' list by editing a vehicle and adding the number of Engine Hours as below

10.  Then you are able to set an alert based on the operating hours.

Note:  Once the time reaches the percentage of the value you have set in the alert, it will be triggered. 

11.   Once you are ready, click on the save button. .
