# Vehicles Off Road (VOR) Report

Back to home

1.  Knowledge Base 
3.  VOR 

-   Logging-in to your Transpoco account
    -   Login to your Transpoco account
    -   Transpoco Smartphone Apps
    -   2 Factor Authentication
    -   System requirements
    -   Overview of Transpoco
    -   Implementation
-   How to organise your account to achieve the best results
    
-   How to use each feature - step by step guides
    -   Users and permissions
    -   Walkaround Checks module
    -   Fuel/Electric Vehicles Module
    -   Maintain Module
    -   Dashboard
    -   Messaging module
    -   Scheduled Reports
-   How to Order More Trackers
    
-   Live Map
    
-   Cameras
    -   FAQ
-   Webinar Videos
    
-   Walkaround Checklists
    -   Walkaround Checklists
    -   Driver App
    -   Alerts
-   Reports
    -   Reports
    -   Viewing data in reports
-   Fuel
    
-   Dashboard
    
-   Maintain Module
    
-   Driving Style
    
-   Locations
    
-   Cost Management (TCO) Report
    
-   The Notification Features
    
-   Hardware and Installation
    
-   Removal & Repair of Hardware
    -   Requesting a Repair or a Deinstallation
-   Cameras & GDPR Guidelines
    
-   Scheduled Reports
    
-   Safety Program
    
-   Fleet Manager App
    
-   Users & Permissions
    
-   Alerts
    
-   Policies & Documents
    
-   Privacy Policy and Terms & Conditions
    -   RoPA
-   API
    
-   Transpoco User Manuals
    
-   Settings
    -   Garage
-   Whats New?
    
-   Account Mangement Services
    
-   Driver ID process
    
-   Security
    
-   Transpoco Locate
    
-   Subscriptions & Invoices
    
-   Tutorial videos
    
-   Cancelling your account
    
-   VOR
    
-   Installation
    
-   BIKLY
    

# Vehicles Off Road (VOR) Report

## The objetive of the Vehicles Off Road (VOR) report is to map the time vehicles are speding in garages / off road.

The main objective of this report is to show how long vehicles are staying in the garages / off road. The "Duration" column with the "Status" column will provide users with this information. 

Note: If the **Status** is "At Location", it means the vehicle is still there for the duration mentioned. If the **Status** is "Exited", it means the vehicles exited the location already, but spent a number of hours or days at the informed location. 

You will also be able to check the time since vehicle exited the location / garage which will help you to quickly see the last time it was off road.

The report is also designed to be sorted by each column, filtered by the data you want, to have columns added and excluded, to have the data grouped by the column you wish, to be exported, etc.

To run this report, you can select the period of your choice, the vehicle group / individual vehicle and the group of garages of your choice.

### How do I set the garages / group of garages I want?

You need to go to the "Locations" section and geofence the garages there.

Note: To add Locations, please check the instructions here.

Warning: The most important thing when creating / editing these garages is to add the "Group" property to it as these groups must be selected on the VOR report.
