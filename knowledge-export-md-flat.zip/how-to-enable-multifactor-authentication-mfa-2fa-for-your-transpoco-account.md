# How to enable Multifactor Authentication (MFA/2FA) for your Transpoco account?

Back to home

1.  Knowledge Base 
3.  Logging-in to your Transpoco account 
5.  2 Factor Authentication 

-   Logging-in to your Transpoco account
    -   Login to your Transpoco account
    -   Transpoco Smartphone Apps
    -   2 Factor Authentication
    -   System requirements
    -   Overview of Transpoco
    -   Implementation
-   How to organise your account to achieve the best results
    
-   How to use each feature - step by step guides
    -   Users and permissions
    -   Walkaround Checks module
    -   Fuel/Electric Vehicles Module
    -   Maintain Module
    -   Dashboard
    -   Messaging module
    -   Scheduled Reports
-   How to Order More Trackers
    
-   Live Map
    
-   Cameras
    -   FAQ
-   Webinar Videos
    
-   Walkaround Checklists
    -   Walkaround Checklists
    -   Driver App
    -   Alerts
-   Reports
    -   Reports
    -   Viewing data in reports
-   Fuel
    
-   Dashboard
    
-   Maintain Module
    
-   Driving Style
    
-   Locations
    
-   Cost Management (TCO) Report
    
-   The Notification Features
    
-   Hardware and Installation
    
-   Removal & Repair of Hardware
    -   Requesting a Repair or a Deinstallation
-   Cameras & GDPR Guidelines
    
-   Scheduled Reports
    
-   Safety Program
    
-   Fleet Manager App
    
-   Users & Permissions
    
-   Alerts
    
-   Policies & Documents
    
-   Privacy Policy and Terms & Conditions
    -   RoPA
-   API
    
-   Transpoco User Manuals
    
-   Settings
    -   Garage
-   Whats New?
    
-   Account Mangement Services
    
-   Driver ID process
    
-   Security
    
-   Transpoco Locate
    
-   Subscriptions & Invoices
    
-   Tutorial videos
    
-   Cancelling your account
    
-   VOR
    
-   Installation
    
-   BIKLY
    

# How to enable Multifactor Authentication (MFA/2FA) for your Transpoco account?

## In this article you will find the step by step to enable and use the multi-factor authentication.

Once you are logged at your Transpoco account and you are set with the "Administrator" privilege in your profile, you will be able to see the security setting options where you can turn the Multi-factor Authentication ON. 

Note: Once you turn the Multi-factor Authentication ON, all your users, except user logins to the Driver App, will be required to use an Authenticator App. We highly recommend you to notify your Transpoco users to download an Authenticator App to their mobile before enabling MFA.

Examples of Authenticator apps are:

Google Authenticator 

Microsoft Authenticator

Twilio Authy Authenticator

Now it's time to enable the Multi-factor Authentication.

Please go to Settings -> Security Settings -> Move the multi-factor Authentication option to ON by clicking on it -> Click on the "Update Policy" button.

Setting

Company Security

Once you update the policy, the multi-factor authentication will be required for all logins including logins to the Driver app and Fleet Manager app.

Note: You will still be able to use the system until you logout of it or expire your token which happens in every 30 days.

Token: Once you log in the system, you have a token which identifies you for the system. You won't be able to see it but the authentication scheme uses it for your login.

Logging in with Multi-factor Authentication. Please enter your username and password. Then, click on the "Login" button.

Login

You will be redirected to the page below. 

Note: You will need an authenticator app to scan the QR code from the page. Please download it via App Store / Google Play to your mobile.

Examples of Authenticator apps are:

Google Authenticator 

Microsoft Authenticator

Twilio Authy

QR          Enter Code

**Via Google Authenticator in your mobile.**

Click on the "Plus" button at the bottom. Choose the option to scan the QR code in your screen or to enter a setup key. To get this key you need to click on the "Trouble Scanning?" option.

One Two

**Scanning the QR Code option**

Once you scan the QR Code, you will be provided a 6 digit code which should be added to the empty field from your screen and clicked on the "Continue" button to proceed.

CodeEnter Code here

Once you have the right code, you are logged at your Transpoco account.

Map

**Clicking on the "Trouble Scanning?" option**

You need to copy the code in your screen by clicking on "Copy code" and enter it in the empty box. Then, click on the "Continue" button.

Secure Your Account

Once you have the right code, you are logged at your Transpoco account.

Map Section

**Via Microsoft Authenticator in your mobile**

Please find a step-by-step in a video here or in this PDF.
