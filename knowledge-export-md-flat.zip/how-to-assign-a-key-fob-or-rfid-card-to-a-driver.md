# How to assign a key fob or RFID card to a driver

Back to home

1.  Knowledge Base 
3.  Driver ID process 

-   Logging-in to your Transpoco account
    -   Login to your Transpoco account
    -   Transpoco Smartphone Apps
    -   2 Factor Authentication
    -   System requirements
    -   Overview of Transpoco
    -   Implementation
-   How to organise your account to achieve the best results
    
-   How to use each feature - step by step guides
    -   Users and permissions
    -   Walkaround Checks module
    -   Fuel/Electric Vehicles Module
    -   Maintain Module
    -   Dashboard
    -   Messaging module
    -   Scheduled Reports
-   How to Order More Trackers
    
-   Live Map
    
-   Cameras
    -   FAQ
-   Webinar Videos
    
-   Walkaround Checklists
    -   Walkaround Checklists
    -   Driver App
    -   Alerts
-   Reports
    -   Reports
    -   Viewing data in reports
-   Fuel
    
-   Dashboard
    
-   Maintain Module
    
-   Driving Style
    
-   Locations
    
-   Cost Management (TCO) Report
    
-   The Notification Features
    
-   Hardware and Installation
    
-   Removal & Repair of Hardware
    -   Requesting a Repair or a Deinstallation
-   Cameras & GDPR Guidelines
    
-   Scheduled Reports
    
-   Safety Program
    
-   Fleet Manager App
    
-   Users & Permissions
    
-   Alerts
    
-   Policies & Documents
    
-   Privacy Policy and Terms & Conditions
    -   RoPA
-   API
    
-   Transpoco User Manuals
    
-   Settings
    -   Garage
-   Whats New?
    
-   Account Mangement Services
    
-   Driver ID process
    
-   Security
    
-   Transpoco Locate
    
-   Subscriptions & Invoices
    
-   Tutorial videos
    
-   Cancelling your account
    
-   VOR
    
-   Installation
    
-   BIKLY
    

# How to assign a key fob or RFID card to a driver

In the video below we explain the steps to assign a key fob or RFID card to a driver in your Transpoco account.

In order to assign a driver ID or key fob go to **Settings menu > Garage > Drivers**

If the profile of the driver exists select **'Edit**' under the **'Edit' column.**

If the driver is new start by clicking **+Add New Driver** to create a profile for the driver.

In the profile of the driver go down to the Vehicle section and look for **'Vehicle Assignment'.**

To assign a key fob select **Via iButton** from the menu and enter the 16 characters printed on the base of the key fob in the field below.

If your drivers use RFID cards Select **via RFID** and enter the serial number of the card. 

After you enter the serial number go down to the bottom and click **'Update profile'** to save the change

If you are creating a new profile and you have the serial number follow the same instructions above.

In the video I mention that the unique serial number is printed on the key fob.

This image below shows the order of the 16 characters of the serial number, you have to enter the serial number in this order.

unnamed-Apr-05-2024-07-57-42-5320-AM
