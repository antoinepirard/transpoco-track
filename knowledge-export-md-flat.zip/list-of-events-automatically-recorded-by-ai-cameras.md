# List of events automatically recorded by AI cameras

Back to home

1.  Knowledge Base 
3.  Cameras 

-   Logging-in to your Transpoco account
    -   Login to your Transpoco account
    -   Transpoco Smartphone Apps
    -   2 Factor Authentication
    -   System requirements
    -   Overview of Transpoco
    -   Implementation
-   How to organise your account to achieve the best results
    
-   How to use each feature - step by step guides
    -   Users and permissions
    -   Walkaround Checks module
    -   Fuel/Electric Vehicles Module
    -   Maintain Module
    -   Dashboard
    -   Messaging module
    -   Scheduled Reports
-   How to Order More Trackers
    
-   Live Map
    
-   Cameras
    -   FAQ
-   Webinar Videos
    
-   Walkaround Checklists
    -   Walkaround Checklists
    -   Driver App
    -   Alerts
-   Reports
    -   Reports
    -   Viewing data in reports
-   Fuel
    
-   Dashboard
    
-   Maintain Module
    
-   Driving Style
    
-   Locations
    
-   Cost Management (TCO) Report
    
-   The Notification Features
    
-   Hardware and Installation
    
-   Removal & Repair of Hardware
    -   Requesting a Repair or a Deinstallation
-   Cameras & GDPR Guidelines
    
-   Scheduled Reports
    
-   Safety Program
    
-   Fleet Manager App
    
-   Users & Permissions
    
-   Alerts
    
-   Policies & Documents
    
-   Privacy Policy and Terms & Conditions
    -   RoPA
-   API
    
-   Transpoco User Manuals
    
-   Settings
    -   Garage
-   Whats New?
    
-   Account Mangement Services
    
-   Driver ID process
    
-   Security
    
-   Transpoco Locate
    
-   Subscriptions & Invoices
    
-   Tutorial videos
    
-   Cancelling your account
    
-   VOR
    
-   Installation
    
-   BIKLY
    

# List of events automatically recorded by AI cameras

## In this article we will list the events which will be identified and automatically recorded by the AI cameras. You can also find a video explaining the new Camera layout.

This article will explain the events which will be identified and recorded by the driver facing AI camera and the forward facing AI camera. 

**Note:** These events are not available for non-AI cameras

**Warning:** We don't provide a Live View from the Cameras.

###          **Note:** To understand better the new Camera's page layout, please watch this video.

###  **Driving Facing AI Camera events:**

-   -   -   Driver Yawns.
        -   Driver Distraction.
        -   Driver Call.
        -   Driver smoking
        -   Driver fatigue
        
        ### **Forward Facing (ADAS) Camera events:**
        
        -   Forward Collision.
        -   Too close distance.

###            **Other events:**

-   -   -   **Video Loss**
        -   **No Driver**
        -   Illegal Shutdown

### **Driver Facing Camera events:**

-   **Driver Yawns:**  
      
    Driver Yawns

  

-   **Driver Distraction:**

Driver Distraction

-   **Driver Call**

Driver Call

-   **Driver smoking**

**Driver smoking**

-   **Driver fatigue:**

**Driver fatigue**

-   **Video Loss:**

When one of the channels cannot be seen in that specific video.

**Video Loss**

-   **No Driver:**

When the camera can't detect the driver. This alert is usually triggered when the camera is intentionally covered or if an object is unintentionally blocking the camera. 

**No Driver**

No Driver - 2

  

-   **Illegal Shutdown:**

The camera installed in your vehicle is wired to the 12v or 24v supply. If this power supply is interrupted an 'Illegal Shutdown' alert is triggered. The interruption of voltage can be caused by the camera being disconnected, low battery voltage or in some newer models, reduction in line voltage as a power saving feature. If the camera continues to function after the illegal shutdown, then the issue was due to transient voltage, if not the camera may be disabled. In this case please contact support@transpoco.com for assistance.

### **Forward Facing Camera events:**

-   **Forward Collision Warning (FCW)**  
    
    **How does FCW work?**
    
    FCW generates an audible alarm up to 2.7 seconds before a possible collision with the vehicle in front.
    
      
    
    **When is FCW active?**
    
    By default, FCW is active when the vehicle speed exceeds 40km/h (19mph).
    
    NOTICE: However, if the user defines the starting speed threshold of FCW, then FCW will only be active when the vehicle speed exceeds the minimum speed in the L1 alarm speed range defined by the user, and will not be active in other cases.
    
      
    FCW

   

-   **Too close distance (Headway Monitoring Warning )**  
    
    **How does headway monitoring warning (HMW) work?**
    
    HMW displays the headway (in seconds) from the vehicle ahead (calculated based on the relative distance with the vehicle ahead and the speed of your vehicle). If the time is very short and danger will be caused, the system will give an alarm.
    
      
    
    **When is HMW active?**
    
    A vehicle icon is displayed whenever a vehicle is detected ahead. But by default, the numerical headway is only shown when your vehicle speed is higher than 30 km/h (19 mph), and an audible alarm is given when there is a risk of a too close distance with the vehicle ahead.
    
      
    
    HMW
