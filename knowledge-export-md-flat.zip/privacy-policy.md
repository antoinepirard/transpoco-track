# Privacy Policy

Back to home

1.  Knowledge Base 
3.  Fleet Manager App 

-   Logging-in to your Transpoco account
    -   Login to your Transpoco account
    -   Transpoco Smartphone Apps
    -   2 Factor Authentication
    -   System requirements
    -   Overview of Transpoco
    -   Implementation
-   How to organise your account to achieve the best results
    
-   How to use each feature - step by step guides
    -   Users and permissions
    -   Walkaround Checks module
    -   Fuel/Electric Vehicles Module
    -   Maintain Module
    -   Dashboard
    -   Messaging module
    -   Scheduled Reports
-   How to Order More Trackers
    
-   Live Map
    
-   Cameras
    -   FAQ
-   Webinar Videos
    
-   Walkaround Checklists
    -   Walkaround Checklists
    -   Driver App
    -   Alerts
-   Reports
    -   Reports
    -   Viewing data in reports
-   Fuel
    
-   Dashboard
    
-   Maintain Module
    
-   Driving Style
    
-   Locations
    
-   Cost Management (TCO) Report
    
-   The Notification Features
    
-   Hardware and Installation
    
-   Removal & Repair of Hardware
    -   Requesting a Repair or a Deinstallation
-   Cameras & GDPR Guidelines
    
-   Scheduled Reports
    
-   Safety Program
    
-   Fleet Manager App
    
-   Users & Permissions
    
-   Alerts
    
-   Policies & Documents
    
-   Privacy Policy and Terms & Conditions
    -   RoPA
-   API
    
-   Transpoco User Manuals
    
-   Settings
    -   Garage
-   Whats New?
    
-   Account Mangement Services
    
-   Driver ID process
    
-   Security
    
-   Transpoco Locate
    
-   Subscriptions & Invoices
    
-   Tutorial videos
    
-   Cancelling your account
    
-   VOR
    
-   Installation
    
-   BIKLY
    

# Privacy Policy

## Transpoco Driver APP Last modified: 08 March, 2023 - This Privacy Policy is effective as of the “last modified” date.

#### **Introduction:**

This Privacy Policy states our commitment to your privacy, when using the Driver App.

Our Privacy Policy will help you understand what information we collect, why we collect it and how you can manage and delete the information you trusted us with.

#### **Why we collect personal data:**

The app speeds up the daily vehicle walkaround checks process - quick, easy and paperless. Logging of vehicle checks via an app saves time and minimises errors.

We collect personal data to provide and perform better our services and the best experience for our customers.

#### **Types of data we collect and how we collect them:**

For the purpose of providing our services through Transpoco Driver App, we collect and process:

-   Contact information: name, email address and password to create your login account inside the app;
-   Other personal information might be collected if the account administrator requests additional information through the form within the application;
-   Location access : The driver can log the specific place that he is doing the checklist. Or in case of an accident, it's possible to log the place where it happens - If the user chooses to share the geolocation data, this data will be sent to an API that will reverse geocode to an address.
-   Device logs: We do not keep permanent device logs in relation to your account but we will register the last access details to eventually check any issues you might come across.
    

#### **Information sharing and disclosure:**

We will not share or disclose any of your Personal Information or Content with third parties. We do not sell your Personal Information or Content. 

We don't allow unauthorised publishing or disclosure of people's non-public contacts.

#### **Our Commitment to Data Security:**

Transpoco Driver App hosts data with an ISO27001 compliant hosting company based in the EU region. The servers on which Personal Information is stored are kept in a controlled environment. While we take reasonable efforts to guard your Personal Information, no security system is impenetrable and due to the inherent nature of the Internet as an open global communications vehicle, we cannot guarantee that information, during transmission through the Internet or while stored on our systems or otherwise in our care, will be absolutely safe from intrusion by others, such as hackers. 

In addition, we cannot guarantee that any incidentally-collected Personal Information you choose to store in our Products are maintained at levels of protection to meet specific needs or obligations you may have relating to that information.

Transpoco Driver App implements security procedures to help protect your data from security attacks. 

However, you understand that use of the Hosted Services necessarily involves transmission of your data over networks that are not owned, operated, or controlled by us, and we are not responsible for any of your data lost, altered, intercepted, or stored across such networks. We cannot guarantee that our security procedures will be error-free, that transmissions of your data will always be secure or that unauthorised third parties will never be able to defeat our security measures or those of our third-party service providers.

Where data is transferred over the Internet as part of our Products, the data is encrypted using industry standard SSL (HTTPS). We are taking all steps reasonably necessary to ensure that your data is treated securely and in accordance with Data Protection Legislation.

#### **Accessing and updating your information**

You may often correct, update, amend, or remove your Personal Information in your account settings or by directing your query to your account administrator. You may also contact us and we will initially respond to your request for access within 1 week. 

The request can be made in writing (email or support ticket). If made orally, Transpoco will record the time and details of the request verbally made and follow it up with individuals in writing (email or support ticket) to confirm that they have correctly understood the request.

You can contact us to request removal of Personal Information from Transpoco services.

Data might not have to be erased if any of the following applies:

-   The "right of freedom of expression";
-   For supporting legal claims.

#### **Our policy towards children:**

Transpoco Driver App services are not directed to individuals under 18. We do not knowingly collect Personal Information from children under 18. If we become aware that a child under 18 has provided us with Personal Information, we will take steps to delete such information. If you become aware that a child has provided us with Personal Information, please contact us.

#### **How to contact us:**

**Transpoco** - E-pire limited, trading as Transpoco, Dublin City University Alpha Innovation Campus, Old Finglas Road, Glasnevin, Dublin 11, Ireland. 

If you wish to complain about how we have handled your personal information, please provide our Data Protection Officer with full details of your complaint and any supporting documentation by sending an email to:

Barry Cronin, contact: support@transpoco.com

#### March, 2023
