# Terms & Conditions

Back to home

1.  Knowledge Base 
3.  Privacy Policy and Terms & Conditions 

-   Logging-in to your Transpoco account
    -   Login to your Transpoco account
    -   Transpoco Smartphone Apps
    -   2 Factor Authentication
    -   System requirements
    -   Overview of Transpoco
    -   Implementation
-   How to organise your account to achieve the best results
    
-   How to use each feature - step by step guides
    -   Users and permissions
    -   Walkaround Checks module
    -   Fuel/Electric Vehicles Module
    -   Maintain Module
    -   Dashboard
    -   Messaging module
    -   Scheduled Reports
-   How to Order More Trackers
    
-   Live Map
    
-   Cameras
    -   FAQ
-   Webinar Videos
    
-   Walkaround Checklists
    -   Walkaround Checklists
    -   Driver App
    -   Alerts
-   Reports
    -   Reports
    -   Viewing data in reports
-   Fuel
    
-   Dashboard
    
-   Maintain Module
    
-   Driving Style
    
-   Locations
    
-   Cost Management (TCO) Report
    
-   The Notification Features
    
-   Hardware and Installation
    
-   Removal & Repair of Hardware
    -   Requesting a Repair or a Deinstallation
-   Cameras & GDPR Guidelines
    
-   Scheduled Reports
    
-   Safety Program
    
-   Fleet Manager App
    
-   Users & Permissions
    
-   Alerts
    
-   Policies & Documents
    
-   Privacy Policy and Terms & Conditions
    -   RoPA
-   API
    
-   Transpoco User Manuals
    
-   Settings
    -   Garage
-   Whats New?
    
-   Account Mangement Services
    
-   Driver ID process
    
-   Security
    
-   Transpoco Locate
    
-   Subscriptions & Invoices
    
-   Tutorial videos
    
-   Cancelling your account
    
-   VOR
    
-   Installation
    
-   BIKLY
    

# Terms & Conditions

## You can find all detailed information regarding your rights, obligations and restrictions when using Transpoco products as well as all the use of your data within this article.

### **Terms & Conditions**

These terms and conditions apply to the purchase or rent and subsequent use of Transpoco’s products and services and contain the Customer’s rights, obligations, and restrictions when using them. 

**Acceptance of the Agreement.** By signing the digital signature on the initial Order and clicking the “I Accept” button, the Customer accepts this Agreement. All subsequent purchases shall be also subject to this Agreement.  “Agreement” as used herein includes these terms and conditions, any Order, and any other referenced policies and attachments.

#### **DEFINITIONS**

-   **Camera** means a device, as referred to on the Order, purchased or rented by the Customer that can be used for obtaining location data and Footage via satellite tracking and for sending and receiving such data and other messages via mobile communications(either automatically according to set procedure or by manual information retrieval)
-   **Customer** is the organisation or entity accepting this Agreement.
-   **Fees** means the sum(s) set out in the Order payable by the Customer for the Software, Services, and System.
-   **Footage** means video footage or still images taken by the Camera
-   **Hardware** means the hardware unit chosen by the Customer as described in the  Order. 
-   **Initial Term** means the initial term of this Agreement selected by the Customer in an Order
-   **Insolvency Event** means any of the following in relation to a Party:  
    (a) becomes the subject of a bankruptcy order;  
    (b) becomes insolvent;  
    (c) makes any arrangement or composition with or assignment for the benefit of its creditors;  
    (d) goes into liquidation, either voluntary (otherwise than for reconstruction or amalgamation) or compulsory;  
    (e) ceases to trade or operate;  
    (f) owns any assets that are material to the operations of all or substantially all of its business that are the subject of any form of seizure or have a receiver or administrator appointed over them; or  
    (g) a notice is given, a petition issued, a resolution passed, or any other step is taken to commence any of the procedures listed above in the jurisdiction of that other Party.
-   **Installation Date** means the date(s) on which the Supplier shall install the Hardware.

-   **Order(s)** means a description of the goods and services provided by the Supplier.
-   **Order Date** means the date on which an Order was signed by the Customer.
-   **Renewal Term** means any additional term of the Agreement after the Initial Term.
-   **Services** means the services provided by the Supplier and described in your Orders. 
-   **Shipping Date** means the date on which Hardware is sent to the Customer
-   **Software** means the programmes accessed through our web portal or API services and any reports that may be automatically sent, or downloaded by the Customer and any replacement or modification or addition there to and licensed under this Agreement.
-   **System** means the Hardware, Software, and web interfaces together with any other documents, manuals, discs, or any other items prepared by the Supplier and delivered to the Customer.
-   **Supplier** is E-pire Limited, trading as Transpoco.
-   **Term** means the Initial Term and the Renewal Term of this Agreement (if any).

#### **NOW IT IS AGREED, as follows:**

1.  Upon the execution of this Agreement, the Supplier shall sell or rent Hardware and/or the Camera as specified in the Order. The Customer shall purchase or rent Hardware and/or the Camera as specified in the Order, and, subject to payment of the Fees by the Customer,  the Supplier hereby grants the Customer a non-transferable, non-exclusive licence to use the Software on the System and shall provide the Services for the Term subject to the terms and conditions herein provided. 
2.  The Term is as set out in the Order. If the Supplier is completing the installation, the Term commences on the Installation Date. Where the Customer chooses to install the Hardware, the Term commences on the Shipping Date of the Hardware and/or Camera.
3.  Invoices will be issued upon acceptance of this Agreement. Fees will be paid in advance from the Installation Date. Invoices will be paid as specified in the Order. Where requested by Customer, additional Hardware and Services may be supplied and invoiced pursuant to this Agreement Customer agrees that this Agreement applies to any such additional Hardware and Services.
4.  The Supplier, where Supplier is installing the Hardware, shall deliver and install the Hardware to the Customer in accordance with the estimated Installation Date stated in the Order. If the Supplier is unable to deliver or install the Hardware or System by the Installation Date due to the fault of the Customer (for example where vehicles are not on the premises or not available for installation of the Hardware),  the Customer shall not be entitled to rescind this Agreement nor shall it be entitled to seek damages provided the installation is completed within a reasonable time of the Installation Date.  If no Installation Date is stated in the Order, the parties shall agree a schedule for Installation. 
5.  In the event that a Customer cancels a scheduled installation within 24 hours of an agreed Installation Date, the Customer will pay a cancellation fee that can be consulted on the table of services in paragraph 23.
6.  The Supplier undertakes that, provided that the System is operated in accordance with the Supplier's instructions and the System shall perform in accordance with the Supplier's specification existing at the Order Date in all material respects. If the Customer installs the Hardware, the Supplier shall have no responsibility or liability in respect of such installation. The Supplier does not warrant that the operation of the System will be uninterrupted or error-free or that the System will meet the Customer's requirements or will operate in the combinations chosen by the Customer. **Other than as set out herein, the System and all Services (if any), are provided “as is” without a warranty of any kind, either expressed, implied, statutory or otherwise, including without limitation, any implied warranties of merchantability, fitness for a particular purpose, or non-infringement.** In the event that the operation of the System is interrupted or errors appear as a result of any act or omission by the Supplier, its servants, or agents, then the Supplier shall with all reasonable promptness correct any such errors and restore operation of the System. Customer can log onto support @transpoco.com to report errors. Support of the System is included in the ongoing fee and there is no charge for on-site visits within the first 12 months of this Agreement. If an on-site support visit is necessary after the first 12 months of this Agreement then the charge that will apply per vehicle can be consulted on the **table** of services in paragraph 23.  If maintenance to the System is required due to some act or default by or of the Customer (or for some reason other than a defect in the System, or general maintenance) then a further sum shall be payable by the Customer to the Supplier, which can be consulted on the table of services in paragraph 23. The cost of replacement Hardware and/or Camera fees or other necessary expenses required to rectify damage will be charged to the Customer in addition to labour rates quoted above.
7.  The Intellectual Property in the System and Services is owned by and will remain the property of  Supplier. The Customer agrees not to remove or alter any copyright notice or restricted rights legend from the Software or Hardware. The Customer shall follow all reasonable instructions given by the Supplier from time to time with regard to the use of the trademarks and copyright and other intellectual property rights owned by the Supplier in connection with the System.
8.  The Supplier shall not be liable for special, consequential, indirect or similar damages or loss (including without limitation loss of time, loss of data, loss of profits or revenue or loss of use of the System) to the Customer even if the Supplier has been advised of the possibility of such damages. The Supplier shall in no way be responsible or liable for damages or costs incurred during installation or as a result of installation. Furthermore the Supplier shall not be responsible or liable for costs incurred by the Customer in connection with obtaining a substitute system or claims for inconvenience or any other costs or loss. The Customer shall indemnify and keep indemnified the Supplier against injury (including death) to any person or loss of or damage to any property which may rise out of the act, default, or negligence of the Customer, its employees, or agents in consequence of the Customers obligations under this agreement and against all claims demands proceedings damages costs charges and expenses whatsoever in respect thereof or relation thereto except that the Customer shall not be liable for nor be required to indemnify the Supplier against any compensation or damages for or concerning injuries or damage to persons or property to the extent that such injuries or damage result from any act default or negligence on the part of the Supplier its employees contractors or agents.
9.  The cameras capture and transmit data for various purposes, such as monitoring vehicle surroundings or driver behavior. Each camera unit is allocated a data allowance of 1 gigabyte per month for data transmission purposes. Any usage beyond this allocation will be subject to additional charges, as outlined in the table of services, in paragraph 23. By using our camera systems, customers agree with the data usage outlined in these terms and conditions.
10.  For installations made by Transpoco, we offer a comprehensive warranty for 12 months from the date of installation. This warranty does not cover damages resulting from misuse, accidents, unauthorized modifications, or natural disasters. To avail of warranty services, the customers must contact our support team. We reserve the right to refuse warranty claims that do not meet these criteria or if the warranty period has expired.
11.  Where the Customer chooses the self-install units, the billing commences within 30 days of the Hardware Shipping Date.
12.  Any notice, request or other communication required or permitted to be given hereunder shall be given in writing and shall be deemed to have been duly given if delivered by hand against receipt of the addressee or if transmitted by email or sent by prepaid registered post addressed to the party to whom such notice is to be given at the address set out in the Order for such party herein (or such other address as such party may from time to time designate in writing to the other party hereto). Any such notice shall be deemed to have been duly given if delivered at the time of delivery, if by email at the time of transmission and if sent by prepaid registered post as aforesaid forty-eight hours after the same shall have been posted.
13.  If any of the terms conditions or provisions contained in this Agreement shall be determined to be invalid unlawful or unenforceable to any extent such term condition or provision shall be severed from the remaining terms conditions and provisions which shall continue to be valid to the fullest extent permitted by law.
14.  Following the Initial Term, this Agreement will automatically renew (subject to the Supplier’s then current prices for the Services provided) for a successive term renewal term(s) of the same duration as the Initial Term, unless at least 30 days prior to the end of the Initial Term (or Renewal Term) one party provides written notice to the other party of its intent not to renew.
15.  Staff of the Supplier may, in accordance with its privacy and internal security policies, access the account and data of the Customer  in order to carry out ongoing maintenance or assist in resolving support queries of the Customer.
16.  At the end of a rental period, the rental fees will automatically renew unless the Hardware has been returned to the Supplier. If required, the Supplier can provide a de-installation service. For de-installation fees, can be consulted on the table of services in paragraph 23. If the Hardware cannot be recovered or is returned to the Supplier in an inoperable state, a further sum (a Hardware Replacement Fee) shall be payable by the Customer, the Hardware Replacement Fee can be consulted in paragraph 23.
17.  Either Party may immediately terminate this Agreement in whole or in part or the  Service by giving notice to terminate to the other Party if the other Party:  
     (i) commits a material breach that is capable of remedy and fails to remedy the breach within 30 days from the date of the Notice of the breach;  
     (ii) commits a material breach that cannot be remedied; or  
     (iii) is affected by an Insolvency Event,  
     and the Customer will pay the Supplier any outstanding amounts and interest that are properly due and payable under this Agreement.
18.  Either Party may terminate this Agreement where a Force Majeure Event has caused a total loss of that Service for a continuous period of more than 30 days by giving notice to the other Party. This right will expire and the notice will have no effect if the Force Majeure Event has ceased prior to the notice being received. The Customer will pay the Supplier any outstanding amounts and interest that are properly due and payable under this Agreement.
19.  The Supplier reserves the right to suspend access to the Services :  
     (a) to conduct Maintenance; or  
     (b) for any default of any payment in accordance with these terms and conditions;  
     If the Service is suspended for non-payment, the Supplier may charge a re-activation fee to reinstate the Service. Upon reinstatement of the account, the Service will continue as before without a reduction in payment due to the suspension period served.
20.  In the event that any personal data of the Supplier (as defined in the Data Protection Legislation) is or is likely to be processed by the Customer, the Customer shall at all times comply with the provisions and obligations imposed by applicable data protection law including the Data Protection Acts 1988 to 2018  and, the General Data Protection Regulation (EU) 2016/679 and any legislation implementing Regulation (EU) 2016/679 (“Data Protection Legislation”). In such circumstances, the Customer shall:  
       
     (a)only collect and process personal data solely in accordance with Data Protection Legislation as strictly necessary;  
     not disclose or permit the disclosure of such Personal Data, other than as required by relevant EU Member State law;  
     (b)implement and maintain appropriate technical and organisational security measures to protect against any accidental or unlawful loss, destruction, alteration, unauthorised disclosure of, or access to Personal Data ("Data Security Breach") which shall include, where appropriate: pseudonymisation and encrypting personal data; ensuring the confidentiality, integrity, availability, and resilience of its systems and services; the ability to restore the availability of and access to personal data in a timely manner after an incident; and regularly testing. assessing and evaluating the effectiveness of the technical and organisational measures adopted by the Customer;   
     (c) maintain proper records in relation to the Personal Data;  
     (d) cooperate as requested by the Supplier to enable the Supplier to comply with its legal obligations including any exercise of rights by a data subject under Data Protection Legislation;  
     (e) ensure that its employees and other personnel are obliged to keep personal data confidential;  
     (f) assist the Supplier in a timely manner where the Supplier conducts a data protection impact assessment;  
     (g)on request of a data subject return all Personal Data to such data subject or certify in writing to such data subject that all Personal Data has been destroyed.  
     The Customer shall immediately notify the Supplier of any breach of its obligations under this section which may affect the Supplier and shall indemnify the Supplier and keep the Supplier fully and effectively indemnified and hold the Supplier harmless (in each case on an after-tax basis) from and against all awards, costs, damages, claims, demands, interest, expenses, losses and liabilities of whatsoever nature (including all reasonable legal fees) arising out of or in connection with or consequent upon its failure to comply with the provisions and obligations imposed on the Customer by Data Protection Legislation.
21.  According to the Supplier’s commitment to the environment and disposal of Electrical and Electronic Equipment (WEEE), the Supplier offers environmentally sound management of Waste Electrical and Electronic Equipment by providing takeback of WEEE from our Customers free of charge. Take-back is on a one-for-one basis and the Hardware being returned must be of a similar type or have performed the same function as the item purchased.
22.  Any dispute or difference which may arise between the Customer and the Supplier in connection with or arising out of this agreement may by agreement of both parties be resolved by arbitration in which event such dispute of difference shall be referred to a single arbitrator to be agreed between the parties hereto or in the absence of such agreement by on Arbitrator to be appointed by the President for the time being of the Incorporated Law Society of Ireland. In the event of a dispute or difference being referred to arbitration according to this section, the Supplier and Customer agree that this decision of the Arbitrator shall be binding on both parties any arbitration proceedings commenced and proceeded with according to this agreement shall be governed by the provisions of the Arbitration Act 1954.
23.  **Table of services:**

**Telematics device**

**Pricing € (Ex VAT)**

Installation (3 wire)

70

Installation (Canbus)

120

Deinstallation

50

Decommission - Remote

50

Deinstall / Reinstall (3 wire - Vehicles in the same location at the same time)

80

Deinstall / Reinstall (Canbus - Vehicles in the same location at the same time)

140

Hardware replacement

Depends on device type

 

 

**Camera device - Forward Facing**

 

Installation

70

Deinstallation

60

Decommission

80

Deinstall / Reinstall (Vehicles in the same location at the same time)

100

Extra usage of 1 gigabyte per month 

5

 

 

**Asset Tracker**

120

 

 

 

 

**Professional Services**

 

Daily Rate

800

 

 

**API Integration (development work)**

 

Daily Rate

800

 

 

**Onsite Training**

 

Daily Rate

500

Hourly Session

100

Last updated:  July, 2024
