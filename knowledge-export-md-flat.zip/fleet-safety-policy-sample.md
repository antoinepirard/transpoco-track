# Fleet safety Policy Sample

Back to home

1.  Knowledge Base 
3.  Logging-in to your Transpoco account 
5.  Implementation 

-   Logging-in to your Transpoco account
    -   Login to your Transpoco account
    -   Transpoco Smartphone Apps
    -   2 Factor Authentication
    -   System requirements
    -   Overview of Transpoco
    -   Implementation
-   How to organise your account to achieve the best results
    
-   How to use each feature - step by step guides
    -   Users and permissions
    -   Walkaround Checks module
    -   Fuel/Electric Vehicles Module
    -   Maintain Module
    -   Dashboard
    -   Messaging module
    -   Scheduled Reports
-   How to Order More Trackers
    
-   Live Map
    
-   Cameras
    -   FAQ
-   Webinar Videos
    
-   Walkaround Checklists
    -   Walkaround Checklists
    -   Driver App
    -   Alerts
-   Reports
    -   Reports
    -   Viewing data in reports
-   Fuel
    
-   Dashboard
    
-   Maintain Module
    
-   Driving Style
    
-   Locations
    
-   Cost Management (TCO) Report
    
-   The Notification Features
    
-   Hardware and Installation
    
-   Removal & Repair of Hardware
    -   Requesting a Repair or a Deinstallation
-   Cameras & GDPR Guidelines
    
-   Scheduled Reports
    
-   Safety Program
    
-   Fleet Manager App
    
-   Users & Permissions
    
-   Alerts
    
-   Policies & Documents
    
-   Privacy Policy and Terms & Conditions
    -   RoPA
-   API
    
-   Transpoco User Manuals
    
-   Settings
    -   Garage
-   Whats New?
    
-   Account Mangement Services
    
-   Driver ID process
    
-   Security
    
-   Transpoco Locate
    
-   Subscriptions & Invoices
    
-   Tutorial videos
    
-   Cancelling your account
    
-   VOR
    
-   Installation
    
-   BIKLY
    

# Fleet safety Policy Sample

**Connected Cameras Policy**

**INTRODUCTION**

This Connected Cameras Policy explains the GDPR rules related to the Cameras regarding data stored and obligations. It also explains the choices available to you regarding our use of your personal information and how you can access and update this information.

#### **DEFINITIONS**

-   Content: any information or data that you upload, submit, post, create, transmit, store or display in Transpoco Services.
-   Data Protection Legislation: the Data Protection Acts 1988 and 2003 and, with effect from 25 May 2018, the General Data Protection Regulation (EU) 2016/679 and any legislation implementing Regulation (EU) 2016/679.
-   Transpoco Services: Transpoco’s products and / or services provided.
-   Personal Information: information that may be used to readily identify or contact you as an individual person, such as: name, address, email address, or phone number. Personal Information does not include information that has been anonymized such that it does not allow for the ready identification of specific individuals.
-   Controller: the natural or legal person, public authority, agency or any other body which alone or jointly with others determines the purposes and means of the processing of personal data as meant in the Data Protection Law.

#### **SCOPE OF CAMERAS POLICY**

This Privacy Policy applies to the information that we obtain through your use of "Transpoco Services" via a "Device" or when you otherwise interact with Transpoco. We will not collect any personal data about you without your permission or other than in accordance with the Data Protection Legislation.

A "Device" is any computer used to access the Transpoco Services, including without limitation a desktop, laptop, mobile phone or tablet.

By registering for or using Transpoco Services you consent to the collection, transfer, processing, storage, disclosure and other uses described in this Privacy Policy.

**Reasons for recording the data**

The reason for recording the data is to work together with the drivers to avoid accidents and provide the inputs needed for continuous drivers coaching. It can also be used for awarding purposes and to clarify incidents that may happen.

**How the data will be used**

**{Please add text here}**

**What data we collect**

**{Please add text here}**

**How long the data will be stored** 

-   Transpoco’s forward facing camera has a 64GB storage capacity as standard (storage capacity varies for other models)
-   Incidents triggered on the camera are automatically stored in snap shot form (an image a second for 10 second period) and these images are stored for 07 years as default by Transpoco. If you require a different storage period or deletion sooner than this you need to advise. 
-   Video needs remotely downloaded from the camera, this is done through the web interface where appropriate. Once downloaded the video is stored for 07 years in line with our default data storage policy related to video
-   As the camera has limited capacity, video footage will overwrite itself on the camera. A standard forward facing camera has 64GB capacity and this records roughly 55 hours of video. If this video is not downloaded it will be overwritten and not available for future access
-   In the event where data has been overwritten and a member of the public requests to view video recording they believe may have been captured on the camera, in this event the a response to the request should detail reference your policy to provide the data but also the information that the video is no longer stored and thus not available.

**Process for Data Requests**

You may direct your query to your account administrator or contact Transpoco’s Support Team who will initially respond to your request for access within one month. The request must be made in writing (email or support ticket). If made orally, though no legal requirement on Transpoco to respond.

In some cases, you may need to contact your account administrator to request they remove the content. You can contact us to request removal of Personal Information from Transpoco services.

Data might not have to be erased if any of the following applies:

-   The "right of freedom of expression";
-   For supporting legal claims.

The data provided can only be related to the Subject making the request, for example other members of the public should be redacted from the video. Transpoco can assist with the process of redacting if required.

**Drivers obligations**

-   It is best practice to have a sticker clearly visible on the vehicle stating that video is being recorded. A member of the public is entitled to know they have been recorded and can make a data request. 
-   In the event of an accident, the driver is advisable to verbally inform the other parties involved in the accident that the incident has been recorded.
