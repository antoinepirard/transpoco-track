# How do I view journeys in the App?

Back to home

1.  Knowledge Base 
3.  Fleet Manager App 

-   Logging-in to your Transpoco account
    -   Login to your Transpoco account
    -   Transpoco Smartphone Apps
    -   2 Factor Authentication
    -   System requirements
    -   Overview of Transpoco
    -   Implementation
-   How to organise your account to achieve the best results
    
-   How to use each feature - step by step guides
    -   Users and permissions
    -   Walkaround Checks module
    -   Fuel/Electric Vehicles Module
    -   Maintain Module
    -   Dashboard
    -   Messaging module
    -   Scheduled Reports
-   How to Order More Trackers
    
-   Live Map
    
-   Cameras
    -   FAQ
-   Webinar Videos
    
-   Walkaround Checklists
    -   Walkaround Checklists
    -   Driver App
    -   Alerts
-   Reports
    -   Reports
    -   Viewing data in reports
-   Fuel
    
-   Dashboard
    
-   Maintain Module
    
-   Driving Style
    
-   Locations
    
-   Cost Management (TCO) Report
    
-   The Notification Features
    
-   Hardware and Installation
    
-   Removal & Repair of Hardware
    -   Requesting a Repair or a Deinstallation
-   Cameras & GDPR Guidelines
    
-   Scheduled Reports
    
-   Safety Program
    
-   Fleet Manager App
    
-   Users & Permissions
    
-   Alerts
    
-   Policies & Documents
    
-   Privacy Policy and Terms & Conditions
    -   RoPA
-   API
    
-   Transpoco User Manuals
    
-   Settings
    -   Garage
-   Whats New?
    
-   Account Mangement Services
    
-   Driver ID process
    
-   Security
    
-   Transpoco Locate
    
-   Subscriptions & Invoices
    
-   Tutorial videos
    
-   Cancelling your account
    
-   VOR
    
-   Installation
    
-   BIKLY
    

# How do I view journeys in the App?

## How to view the Journeys Report in the SynX Fleet Manager App and view journeys on a map

1.  Tap on the three horizontal lines at the top left of the screen to access the drop-down menu.
2.  Select **Journeys Report** to view the report. The default is for the current date and all vehicles (scroll down to view all the entries).

Screenshot\_20190502\_192050\_com.synx.fleetmanager       Screenshot\_20190502\_193610\_com.synx.fleetmanager

To view an individual journey on the map, tap on **On Map**. The blue pin denotes the start of the journey, and the blue flag denotes the end.

To replay the journey, tap the arrow under the map. The green pin will follow the route simultaneously with the timeline bar under the map and the time, speed and location changing to reflect the location on the route.

Screenshot\_20190502\_193527\_com.synx.fleetmanager

To return to the table view, tap the back arrow in the top left of the screen.

From the table view, tap on **Filters** to select a vehicle group and/or vehicle or to change the date.

Screenshot\_20190520\_022029\_com.synx.fleetmanager

If required, tap on **All Groups** and select a vehicle group from the list, and/or tap on **All Vehicles** and select just one vehicle from the list.

Screenshot\_20190519\_132718\_com.synx.fleetmanager     Screenshot\_20190523\_235420\_com.synx.fleetmanager

**Note:** In the list of vehicles, red vehicles currently have their engine off and green have their engine on.

If required, change from the current date to a previous date by tapping on **Date** and selecting the required date from the calendar. **Note:** the current date is green and the selected date is grey.

Screenshot\_20190520\_022059\_com.synx.fleetmanager

Tap on **Save**.
