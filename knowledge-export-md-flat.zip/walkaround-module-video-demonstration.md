# Walkaround Module Video Demonstration

Back to home

1.  Knowledge Base 
3.  Walkaround Checklists 
5.  Walkaround Checklists 

-   Logging-in to your Transpoco account
    -   Login to your Transpoco account
    -   Transpoco Smartphone Apps
    -   2 Factor Authentication
    -   System requirements
    -   Overview of Transpoco
    -   Implementation
-   How to organise your account to achieve the best results
    
-   How to use each feature - step by step guides
    -   Users and permissions
    -   Walkaround Checks module
    -   Fuel/Electric Vehicles Module
    -   Maintain Module
    -   Dashboard
    -   Messaging module
    -   Scheduled Reports
-   How to Order More Trackers
    
-   Live Map
    
-   Cameras
    -   FAQ
-   Webinar Videos
    
-   Walkaround Checklists
    -   Walkaround Checklists
    -   Driver App
    -   Alerts
-   Reports
    -   Reports
    -   Viewing data in reports
-   Fuel
    
-   Dashboard
    
-   Maintain Module
    
-   Driving Style
    
-   Locations
    
-   Cost Management (TCO) Report
    
-   The Notification Features
    
-   Hardware and Installation
    
-   Removal & Repair of Hardware
    -   Requesting a Repair or a Deinstallation
-   Cameras & GDPR Guidelines
    
-   Scheduled Reports
    
-   Safety Program
    
-   Fleet Manager App
    
-   Users & Permissions
    
-   Alerts
    
-   Policies & Documents
    
-   Privacy Policy and Terms & Conditions
    -   RoPA
-   API
    
-   Transpoco User Manuals
    
-   Settings
    -   Garage
-   Whats New?
    
-   Account Mangement Services
    
-   Driver ID process
    
-   Security
    
-   Transpoco Locate
    
-   Subscriptions & Invoices
    
-   Tutorial videos
    
-   Cancelling your account
    
-   VOR
    
-   Installation
    
-   BIKLY
    

# Walkaround Module Video Demonstration

#### Video demonstration of the Walkaround Module 

#### In Transpoco > Services menu > Walkaround: 

  

-   You can view the Walkaround checks report by weekly views or by list of checks.
-   You can filter the report by vehicle groups or specific vehicles.
-   You can view previous weekly reports.
-   You can view the report only with defects or without defects.
-   You can view the report through custom search by typing in the search box.
    -   e.g.: search for all answers to a specific question
-   You can download custom reports in CSV/Excel format or via emails. 
-   You can add, edit and delete alerts regarding the Walkaround checks. 
    -   Alerts can be triggered when a defect is reported and/or when the vehicle was driven without checking submission.
-   You can create a service into the Maintenance module from a defect reported.
-   You can see photos that were attached to a defect reported.
-   You can find the Manual link with more details on each functionality.

**Note:** You can also ask to our Support Team on support@transpoco.com to customise your checklists with the questions and answers you need.
