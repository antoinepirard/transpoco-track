# Walkaround Checks: How do I perform a site inspection using the Transpoco Driver app?

Back to home

1.  Knowledge Base 
3.  Walkaround Checklists 
5.  Driver App 

-   Logging-in to your Transpoco account
    -   Login to your Transpoco account
    -   Transpoco Smartphone Apps
    -   2 Factor Authentication
    -   System requirements
    -   Overview of Transpoco
    -   Implementation
-   How to organise your account to achieve the best results
    
-   How to use each feature - step by step guides
    -   Users and permissions
    -   Walkaround Checks module
    -   Fuel/Electric Vehicles Module
    -   Maintain Module
    -   Dashboard
    -   Messaging module
    -   Scheduled Reports
-   How to Order More Trackers
    
-   Live Map
    
-   Cameras
    -   FAQ
-   Webinar Videos
    
-   Walkaround Checklists
    -   Walkaround Checklists
    -   Driver App
    -   Alerts
-   Reports
    -   Reports
    -   Viewing data in reports
-   Fuel
    
-   Dashboard
    
-   Maintain Module
    
-   Driving Style
    
-   Locations
    
-   Cost Management (TCO) Report
    
-   The Notification Features
    
-   Hardware and Installation
    
-   Removal & Repair of Hardware
    -   Requesting a Repair or a Deinstallation
-   Cameras & GDPR Guidelines
    
-   Scheduled Reports
    
-   Safety Program
    
-   Fleet Manager App
    
-   Users & Permissions
    
-   Alerts
    
-   Policies & Documents
    
-   Privacy Policy and Terms & Conditions
    -   RoPA
-   API
    
-   Transpoco User Manuals
    
-   Settings
    -   Garage
-   Whats New?
    
-   Account Mangement Services
    
-   Driver ID process
    
-   Security
    
-   Transpoco Locate
    
-   Subscriptions & Invoices
    
-   Tutorial videos
    
-   Cancelling your account
    
-   VOR
    
-   Installation
    
-   BIKLY
    

# Walkaround Checks: How do I perform a site inspection using the Transpoco Driver app?

## How to use the Drivers app to record a site inspection.

From the Walkaround Home Page, tap on **Site Inspection**.

Either scroll down the full list of vehicles or search for a vehicle by typing in part or all of a registration number or vehicle/driver name in the search box.

Tap on the required vehicle.

Screenshot\_20190727\_145518\_com.synx.driver

Select **Site Inspection** from the list of available Checklists and **Surveillance** on the next screen.

Screenshot\_20190725\_131323\_com.synx.driver    Screenshot\_20190731\_182302\_com.synx.driver

Enter the site address in the **text box** OR click on the **GPS locate icon** and the app will enter your location.

Tap on the green **tick**.

Screenshot\_20190731\_182316\_com.synx.driver

To record details and add photos of the site, tap on the **red cross** or **swipe left**.

Screenshot\_20190731\_182343\_com.synx.driver      Screenshot\_20190731\_182352\_com.synx.driver

Add a photo of the site by tapping on **Photo**.

Select a photo from your phone or take a photo with your phone's camera.

**NOTE:** For instructions on how to add a photo from your camera's library or by taking a photo, see Walkaround Checks: How do I add a photo to the SynX Driver app?

If required, repeat steps to add more photos.

In the text box, type in any information about the site.

Screenshot\_20190731\_182924\_com.synx.driver

Tap on the green **Save** button.

The site inspection is now complete.

Screenshot\_20190731\_182931\_com.synx.driver

Type any comments or provide further details in the text box if desired.

To submit the Site Inspection Checklist without reviewing, tap on **Submit Checklist**.

To review the Site Inspection Checklist before submitting, tap on **Review Checklist**.

Scroll down to review each declaration. Click on **Edit** for any item that requires amending or additional information.

Screenshot\_20190731\_183225\_com.synx.driver     Screenshot\_20190731\_183229\_com.synx.driver

Scroll to the end of the checklist and tap on **Submit Checklist**.

Screenshot\_20190731\_183239\_com.synx.driver
