# How to create a Fuel Transactions Schedule Report

Back to home

1.  Knowledge Base 
3.  Scheduled Reports 

-   Logging-in to your Transpoco account
    -   Login to your Transpoco account
    -   Transpoco Smartphone Apps
    -   2 Factor Authentication
    -   System requirements
    -   Overview of Transpoco
    -   Implementation
-   How to organise your account to achieve the best results
    
-   How to use each feature - step by step guides
    -   Users and permissions
    -   Walkaround Checks module
    -   Fuel/Electric Vehicles Module
    -   Maintain Module
    -   Dashboard
    -   Messaging module
    -   Scheduled Reports
-   How to Order More Trackers
    
-   Live Map
    
-   Cameras
    -   FAQ
-   Webinar Videos
    
-   Walkaround Checklists
    -   Walkaround Checklists
    -   Driver App
    -   Alerts
-   Reports
    -   Reports
    -   Viewing data in reports
-   Fuel
    
-   Dashboard
    
-   Maintain Module
    
-   Driving Style
    
-   Locations
    
-   Cost Management (TCO) Report
    
-   The Notification Features
    
-   Hardware and Installation
    
-   Removal & Repair of Hardware
    -   Requesting a Repair or a Deinstallation
-   Cameras & GDPR Guidelines
    
-   Scheduled Reports
    
-   Safety Program
    
-   Fleet Manager App
    
-   Users & Permissions
    
-   Alerts
    
-   Policies & Documents
    
-   Privacy Policy and Terms & Conditions
    -   RoPA
-   API
    
-   Transpoco User Manuals
    
-   Settings
    -   Garage
-   Whats New?
    
-   Account Mangement Services
    
-   Driver ID process
    
-   Security
    
-   Transpoco Locate
    
-   Subscriptions & Invoices
    
-   Tutorial videos
    
-   Cancelling your account
    
-   VOR
    
-   Installation
    
-   BIKLY
    

# How to create a Fuel Transactions Schedule Report

## Here you will find the step by step to create your Fuel Transactions Scheduled Report.

To create a Fuel Transaction scheduled report, navigate to Services > Scheduled Reports

Then click on “+ New Scheduled Report” 

Choose a name, describe the report and select the vehicle or vehicle group(s) you’d like to report on. Then, choose the Fuel Transactions report option:

Select how frequently you’d like to receive the report (daily, weekly or monthly), time of the day, file format (PDF or CSV), language, time zone, distance unit (KM or MI), GPS Status, Registration Status and Fuel Type Match.

-   **GPS Status** 

**GPS Ok** - We have the declared vehicle at the station at the time of purchase  
**GPS Unknown** - We are unable to match the tracked vehicle whithin the station at the purchase time

-   **Registration Status**

**Reg Ok** - The registration declared is part of the fleet

**Reg OK (Manual)** - The purchase was manually assigned to the vehicle  
**Reg Unknown** - The registration declared is unknown

-   **Fuel Type Match**
-    **All:** This option will show all the transactions 
-   **Yes:** This Option will show the transactions which have their fuel type matched. It means that if the vehicle fuel type is petrol and the purchase product is petrol as well, then we have a match.
-   **No:** This option will filter if the vehicle fuel type is different from the purchase product. e.g.: If the vehicle fuel type is petrol and the purchase product is diesel, this report will display these unmatches.

  
Once you’ve selected all of your desired settings, click on Next to move on to Alert and Permission’s Tab. On this Tab you are able to select who will receive this report and set the permission to manage it.

Once you’ve selected all of your desired settings, simply click on “Confirm” and your report will be all set.
