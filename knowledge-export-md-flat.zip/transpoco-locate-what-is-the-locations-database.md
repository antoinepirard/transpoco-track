# Transpoco Locate: What is the Locations Database?

Back to home

1.  Knowledge Base 
3.  Locations 

-   Logging-in to your Transpoco account
    -   Login to your Transpoco account
    -   Transpoco Smartphone Apps
    -   2 Factor Authentication
    -   System requirements
    -   Overview of Transpoco
    -   Implementation
-   How to organise your account to achieve the best results
    
-   How to use each feature - step by step guides
    -   Users and permissions
    -   Walkaround Checks module
    -   Fuel/Electric Vehicles Module
    -   Maintain Module
    -   Dashboard
    -   Messaging module
    -   Scheduled Reports
-   How to Order More Trackers
    
-   Live Map
    
-   Cameras
    -   FAQ
-   Webinar Videos
    
-   Walkaround Checklists
    -   Walkaround Checklists
    -   Driver App
    -   Alerts
-   Reports
    -   Reports
    -   Viewing data in reports
-   Fuel
    
-   Dashboard
    
-   Maintain Module
    
-   Driving Style
    
-   Locations
    
-   Cost Management (TCO) Report
    
-   The Notification Features
    
-   Hardware and Installation
    
-   Removal & Repair of Hardware
    -   Requesting a Repair or a Deinstallation
-   Cameras & GDPR Guidelines
    
-   Scheduled Reports
    
-   Safety Program
    
-   Fleet Manager App
    
-   Users & Permissions
    
-   Alerts
    
-   Policies & Documents
    
-   Privacy Policy and Terms & Conditions
    -   RoPA
-   API
    
-   Transpoco User Manuals
    
-   Settings
    -   Garage
-   Whats New?
    
-   Account Mangement Services
    
-   Driver ID process
    
-   Security
    
-   Transpoco Locate
    
-   Subscriptions & Invoices
    
-   Tutorial videos
    
-   Cancelling your account
    
-   VOR
    
-   Installation
    
-   BIKLY
    

# Transpoco Locate: What is the Locations Database?

## An overview of the database of locations and geofences in Locate and how to view previous saved locations.

The Locations Database can hold an unlimited number of your locations and geofences. SynX Locate refers to geofences as locations, as the location is saved and the virtual perimeter is set around it as desired. These virtual perimeters can be any shape and can cover any area on the map, including:

-   a building and grounds
-   rail station or airport
-   city or county boundaries
-   a specific road or route

Analysis of any given location or geofence, such as the amount of mileage done inside or outside a geofence, the locations visited within the geofence, and the time spent, is shown in the Locations Report.

### View the locations in the database

Click on Locations in the tabbed menu. The list of the stored locations is shown on the left and the map of the locations on the right.

**Note:** When there are a lot of locations, the system will cluster them on the map when viewing the area small scale. See Vehicle clustering for more information.

Use the Google Map functions to progressively zoom into the map to ungroup the locations and eventually show them separately in large scale.

To filter the locations, type in the required criteria in the **Filter Location** text box. For example, ‘Airport’ will bring up all the airports in the database, and a town or city name will bring up all locations with that name.

#### View an individual location or geofence

Click on **Locations** in the tabbed menu.

There are two ways to view a location/geofence:

-   Either, click on the **location name** in the list on the left;

or

-   Click on the **location** **icon** on the map. **Note:** This can also be done from the live map with the locations map overlay.

Whichever method is used, a pop-up appears including the following information and options:

-   Address: Address of the location if available
-   Group: Types of locations/geofences can be assigned to a group
-   GPS Coordinates: Latitude and longitude map coordinates of the location
-   Edit Custom Location: Link to make changes to the location/geofence
-   Street View: View the location in Google Street View
-   Location Report: View the activity for the location in a Locations Report
-   Nearest Vehicles: See the three nearest vehicles in real-time

To edit a location see **Edit a location**.

To add a location see **Add a custom location/geofence**.
