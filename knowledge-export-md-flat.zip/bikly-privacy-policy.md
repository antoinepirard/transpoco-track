# Bikly Privacy Policy

Back to home

1.  Knowledge Base 
3.  BIKLY 

-   Logging-in to your Transpoco account
    -   Login to your Transpoco account
    -   Transpoco Smartphone Apps
    -   2 Factor Authentication
    -   System requirements
    -   Overview of Transpoco
    -   Implementation
-   How to organise your account to achieve the best results
    
-   How to use each feature - step by step guides
    -   Users and permissions
    -   Walkaround Checks module
    -   Fuel/Electric Vehicles Module
    -   Maintain Module
    -   Dashboard
    -   Messaging module
    -   Scheduled Reports
-   How to Order More Trackers
    
-   Live Map
    
-   Cameras
    -   FAQ
-   Webinar Videos
    
-   Walkaround Checklists
    -   Walkaround Checklists
    -   Driver App
    -   Alerts
-   Reports
    -   Reports
    -   Viewing data in reports
-   Fuel
    
-   Dashboard
    
-   Maintain Module
    
-   Driving Style
    
-   Locations
    
-   Cost Management (TCO) Report
    
-   The Notification Features
    
-   Hardware and Installation
    
-   Removal & Repair of Hardware
    -   Requesting a Repair or a Deinstallation
-   Cameras & GDPR Guidelines
    
-   Scheduled Reports
    
-   Safety Program
    
-   Fleet Manager App
    
-   Users & Permissions
    
-   Alerts
    
-   Policies & Documents
    
-   Privacy Policy and Terms & Conditions
    -   RoPA
-   API
    
-   Transpoco User Manuals
    
-   Settings
    -   Garage
-   Whats New?
    
-   Account Mangement Services
    
-   Driver ID process
    
-   Security
    
-   Transpoco Locate
    
-   Subscriptions & Invoices
    
-   Tutorial videos
    
-   Cancelling your account
    
-   VOR
    
-   Installation
    
-   BIKLY
    

# Bikly Privacy Policy

## Privacy Policy for BIKLY

### **Bikly Privacy Policy**

**Bikly App - Last modified: 11th August 2025**This Privacy Policy is effective as of the 11th August 2025 date.

#### **Introduction:**

Bikly is committed to protecting your privacy when using our app. This Privacy Policy explains the types of information we collect, how we use it, and how you can manage and delete the information you share with us.

#### **Why We Collect Personal Data:**

Bikly collects personal data to enable drivers to designate their journeys as business or private for Benefit-in-Kind (BIK) reporting. By providing these services, we aim to offer a streamlined, user-friendly experience for tracking mileage and ensuring tax compliance.

#### **Types of Data We Collect and How We Collect Them:**

To provide our services through the Bikly app, we collect and process the following data:

-   **Contact Information:** Name, email address, and password to create your login account within the app.  
      
    
-   **Journey Data:** Details about your trips, including whether the journey is classified as business or private.  
      
    
-   **Location Access:** Geolocation data to track where each journey takes place. If you choose to share your geolocation, this data may be used to log your journey’s start and end points.  
      
    
-   **Device Information:** We may collect information about the device you use to access Bikly, such as the device model, operating system, and app usage data. We do not store permanent device logs but may keep access records for troubleshooting purposes.  
      
    

#### **Information Sharing and Disclosure:**

We do not share or disclose your Personal Information to third parties, except as necessary to provide our services (e.g., third-party storage providers). We do not sell your Personal Information.

We also do not permit the unauthorized publication or disclosure of personal information stored in the app.

#### **Our Commitment to Data Security:**

Bikly stores your data with an ISO27001-compliant hosting provider. While we take reasonable efforts to protect your Personal Information, we cannot guarantee complete security due to the nature of the internet. Your data may be transmitted over networks that are not owned or controlled by us, and we cannot be held responsible for any loss, alteration, or interception during such transmissions.

Data transferred over the internet, including through our app, is encrypted using industry-standard SSL (HTTPS) protocols to safeguard your information.

#### **Accessing and Updating Your Information:**

You can review and update your Personal Information through your account settings in the Bikly app. If you need assistance, you can contact us via email, and we will respond to your request within 1 week.

If you wish to delete your Personal Information, please contact us directly. Note that data may not be erased if it is required for legal or regulatory reasons.

#### **Our Policy Towards Children:**

Bikly’s services are not intended for children under 18. We do not knowingly collect Personal Information from children. If we become aware that a child under 18 has provided us with Personal Information, we will take steps to delete it. If you believe a child has shared such information, please contact us immediately.

#### **How to Contact Us:**

**Transpoco** - E-pire limited, trading as Transpoco, Dublin City University Alpha Innovation Campus, Old Finglas Road, Glasnevin, Dublin 11, Ireland. 

If you have any concerns or questions regarding the handling of your personal data, please contact our Data Protection Officer at:

Barry Cronin, contact: support@transpoco.com
