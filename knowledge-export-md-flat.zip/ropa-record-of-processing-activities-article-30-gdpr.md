# ROPA (Record of Processing Activities - Article 30 GDPR)

Back to home

1.  Knowledge Base 
3.  Privacy Policy and Terms & Conditions 
5.  RoPA 

-   Logging-in to your Transpoco account
    -   Login to your Transpoco account
    -   Transpoco Smartphone Apps
    -   2 Factor Authentication
    -   System requirements
    -   Overview of Transpoco
    -   Implementation
-   How to organise your account to achieve the best results
    
-   How to use each feature - step by step guides
    -   Users and permissions
    -   Walkaround Checks module
    -   Fuel/Electric Vehicles Module
    -   Maintain Module
    -   Dashboard
    -   Messaging module
    -   Scheduled Reports
-   How to Order More Trackers
    
-   Live Map
    
-   Cameras
    -   FAQ
-   Webinar Videos
    
-   Walkaround Checklists
    -   Walkaround Checklists
    -   Driver App
    -   Alerts
-   Reports
    -   Reports
    -   Viewing data in reports
-   Fuel
    
-   Dashboard
    
-   Maintain Module
    
-   Driving Style
    
-   Locations
    
-   Cost Management (TCO) Report
    
-   The Notification Features
    
-   Hardware and Installation
    
-   Removal & Repair of Hardware
    -   Requesting a Repair or a Deinstallation
-   Cameras & GDPR Guidelines
    
-   Scheduled Reports
    
-   Safety Program
    
-   Fleet Manager App
    
-   Users & Permissions
    
-   Alerts
    
-   Policies & Documents
    
-   Privacy Policy and Terms & Conditions
    -   RoPA
-   API
    
-   Transpoco User Manuals
    
-   Settings
    -   Garage
-   Whats New?
    
-   Account Mangement Services
    
-   Driver ID process
    
-   Security
    
-   Transpoco Locate
    
-   Subscriptions & Invoices
    
-   Tutorial videos
    
-   Cancelling your account
    
-   VOR
    
-   Installation
    
-   BIKLY
    

# ROPA (Record of Processing Activities - Article 30 GDPR)

## You can find all detailed information of processing activities regarding personal data.

**Processing activity name**

**User Register**

**Data subjects categories**

Users

**Data categories**

Full name, email (mandatory) and encrypted  password

Phone and mobile numbers (optional)

**Lawful basis**

Contract

**Purpose**

Be able to log in the product.

**Data retention period**

During contract/ pilot programme and 1 month after cancelling contract / finishing pilot programme

**Data controller**

Customer

**Processing activity details**

Users enter their name and email to the system. The system sends a welcome email (via Postmark) asking them to set their own password. We send both data to Auth0 which generates the token for authentication. We verify this token in our database to give permission to access the system. These users are automatically created in Hubspot (our CRM) and Intercom as well in order to help with the communication. In Intercom, it happens at the first time the user logs in the platform.

**Data processor**

Transpoco (Servers in Amazon Web Services - AWS) and Auth0.

**Data receiver and Country**

AWS (user details) in Ireland

Auth0 (name and email only) in Europe

**Security measures**

Access control, Encryption. 

Note: When transfers to the US are needed, Standard Contractual Clauses (SCCs) are applied.

**External systems**

Postmark in US (name and email only) for the welcome email messaging

Hubspot (user details) in US

Intercom (user details) in US

**Owner name and contact details**

Barry, CTO, barry.cronin@transpoco.com

  
  

**Processing activity name**

**Driver Register**

**Data subjects categories**

Drivers

**Data categories**

Full name (mandatory)

Email (mandatory only for drivers with access to the Driver App)

Mobile number, Supervisor, Driver staff number, Licence number, Emergency Contact, Home Address, Contractor Name (optional)

**Lawful basis**

Contract

**Purpose**

Driver journeys, driving style reports (with speeding, harsh braking, harsh cornering and rapid acceleration) and walkaround reports (driver’s name).

If registered with email, to be able to log in the Driver App.

Email and Mobile number can be used for driver messaging.

All the other optional data has no report related to it.

**Data retention period**

During contract/ pilot programme and 1 month after cancelling contract / finishing pilot programme

**Data controller**

Customer

**Processing activity details**

Admin users enter drivers' data into the system. If no email has been entered, there is no email sent. If an email has been entered, the system sends a welcome email to the drivers asking them to set their own password and download the Driver App. We send name and email to Auth0 which generates the token for authentication. We verify this token in our database to give permission to access the Driver App only. At their first login to the app, these drivers are automatically created in Intercom in order to help with the in-app communication.

**Data processor**

Transpoco (Servers in Amazon Web Services - AWS) and Auth0

**Data receiver and Country**

AWS (user details) in Ireland

Auth0 (name and email only) in Europe

**Security measures**

Access control, Encryption. 

Note: If some transfer to the US is needed from the Auth0 side, Standard Contractual Clauses (SCCs) are applied.

**External systems**

Postmark in US (name and email only) for the welcome email messaging

Intercom (name, email and telephone number) in US

**Owner name and contact details**

Barry, CTO, barry.cronin@transpoco.com

**Processing activity name**

**Users / Drivers Messaging**

**Data subjects categories**

Users and Drivers

**Data categories**

Full name, email and telephone number (optional)

**Lawful basis**

Contract

**Purpose**

Send email / SMS message to the user / driver

**Data retention period**

During contract/ pilot programme and 1 month after cancelling contract / finishing pilot programme

**Data controller**

Customer

Note: Transpoco might trigger these messages to drivers but only on behalf of the customer who is the Data Controller.

**Processing activity details**

Users enter the user/driver contact details into the system. Some possible scenarios listed below: 

1.  Users can create SMS/email messages to other users and/or drivers. 2. Transpoco can create SMS/email/in-app messages to other users and/or drivers upon customer request 
    
2.  Transpoco can create SMS/email/in-app messages to users about the product, services provided, surveys and notifications 
    
3.  User/driver registration into the system (welcome email)
    

**Data processor**

Postmark (Email)

Clickatell (SMS)

Intercom (In-app messaging)

**Data receiver and Country**

Postmark  (name and email only) in US

Clickatell  (name and mobile number only) in Ireland

Intercom (name and email only) in US

**Security measures**

Access control, Encryption

Note: When transfers to the US are needed, Standard Contractual Clauses (SCCs) are applied.

**External systems**

\-

**Owner name and contact details**

Barry, CTO, barry.cronin@transpoco.com

  
  

**Processing activity name**

**Newsletter**

**Data subjects categories**

Marketing contacts, Customers (no Drivers)

**Data categories**

Name and email

**Lawful basis**

Consent

**Purpose**

Notify customers and potential customers about product updates and services

**Data retention period**

During contract/ pilot programme and 1 month after cancelling contract / finishing pilot programme

**Data controller**

Transpoco

**Processing activity details**

Records of processing activities for Marketing activities to existing and potential customers

**Data processor**

Hubspot

**Data receiver and Country**

Hubspot in US

**Security measures**

Access control, Encryption, Swiss-U.S. Privacy Shield Frameworks and Standard Contractual Clauses (SCCs)

**External systems**

\-

**Owner name and contact details**

John, CMO, john.harrington@transpoco.com

  
  

**Processing activity name**

**Safety Programme**

**Data subjects categories**

Drivers

**Data categories**

Full Name, Email, Fob ID, Telephone Number 

Business Journeys, Vehicle Data (Speeding, Harsh Braking, Rapid Acceleration, Harsh Cornering), Camera events with 11 seconds footage including 

-   Forward Collision Warning, Headway Warning, Lane departure warning
-   When the driver receives or makes a call using a hand-held phone while driving 
-   When the driver smokes while driving 
-   When the driver is fatigued and/or Yawning, closing eyes for more than 2 seconds 
-   When the driver is distracted looking left/right/down for a long period

**Lawful basis**

Contract

**Purpose**

Our customers want to have their drivers safer during work. To prevent accidents.

**Data retention period**

During contract/ pilot programme and 1 month after cancelling contract / finishing pilot programme

**Data controller**

Customers on behalf of their drivers

**Processing activity details**

We brief our customers and give them all the explanations needed about the product and process involved. We have a kickoff meeting with the customer. We provide the installation services. We help with the settings in the system. Customers enter driver details into the system. Tracker unit and camera start to collect the data. This information is used to process reports.

Note: We can message the drivers upon customer request if they are in the pilot project. 

**Data processor**

Transpoco (Servers in Amazon Web Services - AWS)

**Data receiver and Country**

AWS (user details) in Ireland

**Security measures**

Access control, Encryption

**External systems**

Auth0 (User to log in SynX and Driver to log in the Driver App)

**Owner name and contact details**

Barry, CTO, barry.cronin@transpoco.com

  
  

**Processing activity name**

**Behaviour Analysis and Product Management**

**Data subjects categories**

Users and Drivers

**Data categories**

User activity in the system - video records.

System screenshots

Company name, user’s and/or driver’s name and email.

**Lawful basis**

Contract

**Purpose**

User behaviour analysis and Product Management.

**Data retention period**

During contract/ pilot programme and 1 month after cancelling contract / finishing pilot programme

**Data controller**

Customer and Transpoco

**Processing activity details**

Inspectlet records user activity through the system. We use the product management tools to manage new features, bugs, improvements, customer requests, customer success and project tasks. Sentry logs system errors.

**Data processor**

Transpoco, Inspectlet, Trello, Asana, Jira, Sentry and Google GSuite

**Data receiver and Country**

Inspectlet (user activity in the system) in US

Trello and Asana (product management) in US

Jira and Google GSuite (product management) in Europe

**Security measures**

Access control, Encryption. 

Note: When transfers to the US are needed, Standard Contractual Clauses (SCCs) are applied.

**External systems**

Sentry (system logs) in US

**Owner name and contact details**

Barry, CTO, barry.cronin@transpoco.com

  
  

**Processing activity name**

**Contract acceptance**

**Data subjects categories**

Customer Contract Owner

**Data categories**

Name, email, telephone number, signature

**Lawful basis**

Contract

**Purpose**

Contract acceptance and payments processing.

**Data retention period**

During the contract and 1 month after cancelling the contract.

**Data controller**

Customer and Transpoco

**Processing activity details**

Our internal system processes the order which is sent to the customer contract owner for acceptance and signature of the contract with Transpoco. After the contract is signed, payments are processed accordingly. All contract owners are automatically created in Hubspot (our CRM) in order to help with communication. When contract owners are also users of the system, they are automatically created in Intercom at their first login to the platform in order to help with the communication. 

**Data processor**

Transpoco (Servers in Amazon Web Services - AWS), HelloSign, Stripe, Nuapay, Xero and Chargebee. 

**Data receiver and Country**

AWS (user details) in Ireland

HelloSign (signature) in US and other locations

Stripe and Nuapay (credit and debit) in Europe

Xero (invoices) in New Zealand, US and Australia

Chargebee (subscriptions) in US

**Security measures**

Access control, Encryption. 

Note: When transfers to the US are needed, Standard Contractual Clauses (SCCs) are applied.

**External systems**

Hubspot (name, email and telephone number) in US

Intercom (name, email and telephone number) in US

**Owner name and contact details**

Barry, CTO, barry.cronin@transpoco.com

  
  

**Processing activity name**

**Staff Control**

**Data subjects categories**

Transpoco’s Employees 

Transpoco’s Contractors

**Data categories**

Name, personal email, telephone number, emergency contact name, emergency contact telephone number, address, CV, certificates, bank details, signature

**Lawful basis**

Contract

**Purpose**

Recruitment process, contract acceptance, payments processing and contacting purpose.

**Data retention period**

During the contract and 8 years for ex employees

**Data controller**

Employee and Transpoco

**Processing activity details**

Each employee fills a sheet with their name, telephone number, emergency contact name, emergency contact telephone number and address.

Their personal email is kept in Gmail as per their first contact with Transpoco. 

CVs and certificaticates can be requested as part of the recruitment process and kept in Google Drive and Gmail.

Bank details are saved as payess into the bank platforms.

Signature is collected in their contracts with Transpoco.

**Data processor**

Transpoco

**Data receiver and Country**

Google Drive and Gmail (name, personal email, telephone number, emergency contact name, emergency contact telephone number and address, CVs and certificates) in Europe

BOI and currencyfair (Bank Details) in Ireland

HelloSign (signature) in US and other locations

**Security measures**

Access control, Encryption. 

Note: When transfers to the US are needed, Standard Contractual Clauses (SCCs) are applied.

**External systems**

NA

**Owner name and contact details**

Barry, CTO, barry.cronin@transpoco.com

Last updated: January 2022
