# EV Suitability Report

Back to home

1.  Knowledge Base 
3.  Fuel 

-   Logging-in to your Transpoco account
    -   Login to your Transpoco account
    -   Transpoco Smartphone Apps
    -   2 Factor Authentication
    -   System requirements
    -   Overview of Transpoco
    -   Implementation
-   How to organise your account to achieve the best results
    
-   How to use each feature - step by step guides
    -   Users and permissions
    -   Walkaround Checks module
    -   Fuel/Electric Vehicles Module
    -   Maintain Module
    -   Dashboard
    -   Messaging module
    -   Scheduled Reports
-   How to Order More Trackers
    
-   Live Map
    
-   Cameras
    -   FAQ
-   Webinar Videos
    
-   Walkaround Checklists
    -   Walkaround Checklists
    -   Driver App
    -   Alerts
-   Reports
    -   Reports
    -   Viewing data in reports
-   Fuel
    
-   Dashboard
    
-   Maintain Module
    
-   Driving Style
    
-   Locations
    
-   Cost Management (TCO) Report
    
-   The Notification Features
    
-   Hardware and Installation
    
-   Removal & Repair of Hardware
    -   Requesting a Repair or a Deinstallation
-   Cameras & GDPR Guidelines
    
-   Scheduled Reports
    
-   Safety Program
    
-   Fleet Manager App
    
-   Users & Permissions
    
-   Alerts
    
-   Policies & Documents
    
-   Privacy Policy and Terms & Conditions
    -   RoPA
-   API
    
-   Transpoco User Manuals
    
-   Settings
    -   Garage
-   Whats New?
    
-   Account Mangement Services
    
-   Driver ID process
    
-   Security
    
-   Transpoco Locate
    
-   Subscriptions & Invoices
    
-   Tutorial videos
    
-   Cancelling your account
    
-   VOR
    
-   Installation
    
-   BIKLY
    

# EV Suitability Report

## The objective of the EV Suitability Report is to help you to identify which vehicles can be replaced by electric vehicles.

The EV Suitability report will show you how many days each vehicle from your fleet was driven in different distance ranges. 

To access this report you should click on **Services > Fuel/Electric Vehicles > EV Suitability.**

Transpoco (5)-1

You will also be able to see the % days that the vehicle was driven above and below 150km for example. 

Note: This 150km is customisable. To change this distance value please go to the Settings option where you can define not only this limit but also the ranges you might want to change as well.

There are the total days from the period selected and the total days that vehicle was driven in the period.

The maximum distance travelled for that vehicle in a day and the average distance per day are displayed as well. These will help you to think about the charging points X distance driven. You will also find the sum of the travel distance driven in the period selected.

As mentioned above, you can customise the range brackets for the EV Suitability Report in **Settings -** see the example below. Any change you make will only change the EV Suitability Report in your profile, not for other users. 

image-20-

Note: You can also attribute different colours to the ranges in order to help you with the data analysis at a glance.
