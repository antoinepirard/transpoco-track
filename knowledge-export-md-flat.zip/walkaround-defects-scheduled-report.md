# Walkaround Defects - Scheduled Report

Back to home

1.  Knowledge Base 
3.  How to use each feature - step by step guides 
5.  Scheduled Reports 

-   Logging-in to your Transpoco account
    -   Login to your Transpoco account
    -   Transpoco Smartphone Apps
    -   2 Factor Authentication
    -   System requirements
    -   Overview of Transpoco
    -   Implementation
-   How to organise your account to achieve the best results
    
-   How to use each feature - step by step guides
    -   Users and permissions
    -   Walkaround Checks module
    -   Fuel/Electric Vehicles Module
    -   Maintain Module
    -   Dashboard
    -   Messaging module
    -   Scheduled Reports
-   How to Order More Trackers
    
-   Live Map
    
-   Cameras
    -   FAQ
-   Webinar Videos
    
-   Walkaround Checklists
    -   Walkaround Checklists
    -   Driver App
    -   Alerts
-   Reports
    -   Reports
    -   Viewing data in reports
-   Fuel
    
-   Dashboard
    
-   Maintain Module
    
-   Driving Style
    
-   Locations
    
-   Cost Management (TCO) Report
    
-   The Notification Features
    
-   Hardware and Installation
    
-   Removal & Repair of Hardware
    -   Requesting a Repair or a Deinstallation
-   Cameras & GDPR Guidelines
    
-   Scheduled Reports
    
-   Safety Program
    
-   Fleet Manager App
    
-   Users & Permissions
    
-   Alerts
    
-   Policies & Documents
    
-   Privacy Policy and Terms & Conditions
    -   RoPA
-   API
    
-   Transpoco User Manuals
    
-   Settings
    -   Garage
-   Whats New?
    
-   Account Mangement Services
    
-   Driver ID process
    
-   Security
    
-   Transpoco Locate
    
-   Subscriptions & Invoices
    
-   Tutorial videos
    
-   Cancelling your account
    
-   VOR
    
-   Installation
    
-   BIKLY
    

# Walkaround Defects - Scheduled Report

## You can generate a schedule report for the Walkaround defects of your fleet in your Transpoco account. Please view the instructions below:

1.  Log in to your account. 
2.  Click Services  > Schedule Reports

image-09-23-2024\_01\_00\_PM

  3.   Then click “+ New Schedule Report ".

  4.   Then type in a subject and a description for this report.

  5.   Then choose either filter by the vehicle groups / vehicles or filter by the driver groups / drivers.

  6.   Then select the “Walkaround Check Questions”  types for the Report Types.

  7.   Click “Next”.

  8.   Then choose the schedule period, schedule time, file format, report language, time zone and distance unit in the Configuration section.

**Note:** There is a “Questions” drop down menu for this specific report, where you can select the “Defects” option to bring only the defects reported by your drivers. 

  9.   Click “Next”.

  10.   Then choose the person who will receive this schedule report and who can manage this schedule report. 

**Note:** You can also add more users later when editing this Scheduled Report. 

  11.   Then click “Confirm”

  12.   For editing / viewing of all reports already generated / deleting the Scheduled Report created, please click on the respective button.
