# How to set-up walkaround checks

Back to home

1.  Knowledge Base 
3.  How to use each feature - step by step guides 
5.  Walkaround Checks module 

-   Logging-in to your Transpoco account
    -   Login to your Transpoco account
    -   Transpoco Smartphone Apps
    -   2 Factor Authentication
    -   System requirements
    -   Overview of Transpoco
    -   Implementation
-   How to organise your account to achieve the best results
    
-   How to use each feature - step by step guides
    -   Users and permissions
    -   Walkaround Checks module
    -   Fuel/Electric Vehicles Module
    -   Maintain Module
    -   Dashboard
    -   Messaging module
    -   Scheduled Reports
-   How to Order More Trackers
    
-   Live Map
    
-   Cameras
    -   FAQ
-   Webinar Videos
    
-   Walkaround Checklists
    -   Walkaround Checklists
    -   Driver App
    -   Alerts
-   Reports
    -   Reports
    -   Viewing data in reports
-   Fuel
    
-   Dashboard
    
-   Maintain Module
    
-   Driving Style
    
-   Locations
    
-   Cost Management (TCO) Report
    
-   The Notification Features
    
-   Hardware and Installation
    
-   Removal & Repair of Hardware
    -   Requesting a Repair or a Deinstallation
-   Cameras & GDPR Guidelines
    
-   Scheduled Reports
    
-   Safety Program
    
-   Fleet Manager App
    
-   Users & Permissions
    
-   Alerts
    
-   Policies & Documents
    
-   Privacy Policy and Terms & Conditions
    -   RoPA
-   API
    
-   Transpoco User Manuals
    
-   Settings
    -   Garage
-   Whats New?
    
-   Account Mangement Services
    
-   Driver ID process
    
-   Security
    
-   Transpoco Locate
    
-   Subscriptions & Invoices
    
-   Tutorial videos
    
-   Cancelling your account
    
-   VOR
    
-   Installation
    
-   BIKLY
    

# How to set-up walkaround checks

## In this article we will provide you with a step by step guide to help you to introduce walkaround checks within your organisation.

**Step 1 - Create your walkaround checklists**

We provide 2 default walkaround checklists to help you to get started:

-   HGV checklist
-   LCV checklist.

You can create customised checklists using our checklist builder.  We have created this video to demonstrate the process. You can create as many checklists as you want.

**Step 2-  Providing a driver with access to the Transpoco Driver app**

**Step 3 - Provide Walkaround checks explainer video to Drivers**

We created the video below to demonstrate the Transpoco Driver app to your drivers. We suggest you share the link with your drivers. The video is available on this **page** which you can send to your drivers.

Next, we suggest you ask your drivers to download the **Transpoco Driver App** before you provide them with user access. 

Click here for the link to download the Transpoco Driver App from iTunes (Apple iPhones)

Click here for the link to download the Transpoco Driver app from Google Play Store (Android Phones).

Please share the links with your drivers to allow them to download the app. Alternatively, request your drivers to search for **'Trabspoco Driver App'**  in the iTunes and the Play Store.

**Step 4 - Create an alert for defects reported reported in checklists**

**Step 5- Create an alert for driving without submitting a checklist**

**Step 6 - How to action a defect reported in a walkaround checklist**

We have created a separate step by step article for the Maintain module, click **here** to view it. In the article we demonstrate how you can add garages and services types. 

**Step 7 - How to automate the creation of services for defects**

If you have any questions or problems following the steps in this process you can contact the team in Transpoco for help. You can email us at support@transpoco.com
