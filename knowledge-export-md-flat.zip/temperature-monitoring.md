# Temperature Monitoring

Back to home

1.  Knowledge Base 
3.  Reports 
5.  Reports 

-   Logging-in to your Transpoco account
    -   Login to your Transpoco account
    -   Transpoco Smartphone Apps
    -   2 Factor Authentication
    -   System requirements
    -   Overview of Transpoco
    -   Implementation
-   How to organise your account to achieve the best results
    
-   How to use each feature - step by step guides
    -   Users and permissions
    -   Walkaround Checks module
    -   Fuel/Electric Vehicles Module
    -   Maintain Module
    -   Dashboard
    -   Messaging module
    -   Scheduled Reports
-   How to Order More Trackers
    
-   Live Map
    
-   Cameras
    -   FAQ
-   Webinar Videos
    
-   Walkaround Checklists
    -   Walkaround Checklists
    -   Driver App
    -   Alerts
-   Reports
    -   Reports
    -   Viewing data in reports
-   Fuel
    
-   Dashboard
    
-   Maintain Module
    
-   Driving Style
    
-   Locations
    
-   Cost Management (TCO) Report
    
-   The Notification Features
    
-   Hardware and Installation
    
-   Removal & Repair of Hardware
    -   Requesting a Repair or a Deinstallation
-   Cameras & GDPR Guidelines
    
-   Scheduled Reports
    
-   Safety Program
    
-   Fleet Manager App
    
-   Users & Permissions
    
-   Alerts
    
-   Policies & Documents
    
-   Privacy Policy and Terms & Conditions
    -   RoPA
-   API
    
-   Transpoco User Manuals
    
-   Settings
    -   Garage
-   Whats New?
    
-   Account Mangement Services
    
-   Driver ID process
    
-   Security
    
-   Transpoco Locate
    
-   Subscriptions & Invoices
    
-   Tutorial videos
    
-   Cancelling your account
    
-   VOR
    
-   Installation
    
-   BIKLY
    

# Temperature Monitoring

## Temperature Monitoring

This feature is only available to Temp Probe installed vehicles, contact support@transpoco.com for more details.

Real-time cargo temperature monitoring is available on your Synx platform to provide full visibility of your critical loads helping to make sound decisions or respond to customer queries promptly and efficiently.

Ruptela-temperature-sensor-accessory

With the addition of a temperature probe into your GPS telematics hardware you can monitor temperature in real time and historically.

Reports can be found in the Services/Analytics  section

Annotation 2020-06-16 114522

Annotation 2020-06-16 115407

Annotation 2020-06-16 105213

**Temperature Alerts**

Real-time Alerts notifying key stakeholders of any critical temperature changes within pre set thresholds can be configured. Visual of location, can also be utilised to to report when vehicles enter a customer location it will send a report of the temperature.

Annotation 2020-06-16 105102

To set up alerts enter the Alerts module, give the alert a name, select relevant vehicles and add your parameters. Suggested parameters include:

\-Temperature greater than x\* 

\-Engine = On

\-Duration > 10 minutes (this allows time for the cooling unit reduce the temperature to a desired value)
