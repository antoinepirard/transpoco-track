# How to use the Maintain module

Back to home

1.  Knowledge Base 
3.  How to use each feature - step by step guides 
5.  Maintain Module 

-   Logging-in to your Transpoco account
    -   Login to your Transpoco account
    -   Transpoco Smartphone Apps
    -   2 Factor Authentication
    -   System requirements
    -   Overview of Transpoco
    -   Implementation
-   How to organise your account to achieve the best results
    
-   How to use each feature - step by step guides
    -   Users and permissions
    -   Walkaround Checks module
    -   Fuel/Electric Vehicles Module
    -   Maintain Module
    -   Dashboard
    -   Messaging module
    -   Scheduled Reports
-   How to Order More Trackers
    
-   Live Map
    
-   Cameras
    -   FAQ
-   Webinar Videos
    
-   Walkaround Checklists
    -   Walkaround Checklists
    -   Driver App
    -   Alerts
-   Reports
    -   Reports
    -   Viewing data in reports
-   Fuel
    
-   Dashboard
    
-   Maintain Module
    
-   Driving Style
    
-   Locations
    
-   Cost Management (TCO) Report
    
-   The Notification Features
    
-   Hardware and Installation
    
-   Removal & Repair of Hardware
    -   Requesting a Repair or a Deinstallation
-   Cameras & GDPR Guidelines
    
-   Scheduled Reports
    
-   Safety Program
    
-   Fleet Manager App
    
-   Users & Permissions
    
-   Alerts
    
-   Policies & Documents
    
-   Privacy Policy and Terms & Conditions
    -   RoPA
-   API
    
-   Transpoco User Manuals
    
-   Settings
    -   Garage
-   Whats New?
    
-   Account Mangement Services
    
-   Driver ID process
    
-   Security
    
-   Transpoco Locate
    
-   Subscriptions & Invoices
    
-   Tutorial videos
    
-   Cancelling your account
    
-   VOR
    
-   Installation
    
-   BIKLY
    

# How to use the Maintain module

In this article we will explain everything you need to know to use Maintain module to maintain your vehicle fleet. 

### **1\. Adding Service Types & Garages in the Maintain module**

Before you can create a service ticket you need to enter the types of services you require to manage your fleet and the names of the garages who will do the work.

In this article we will demonstrate how you can add service types and garages in your Maintain module.

### **2\. Creating a service ticket in the Maintain module**

In this video we will demonstrate how you can create a service ticket for the different types of services you will require.

### 3\. How to create a service ticket for a defect reported in a walkaround checklist

In this video we will demonstrate how you can enable a process which will automatically create a service ticket for each defect reported in the walkaround checklist. 

### **4\. How to close a service ticket in the Maintain module**

After you have completed the service type you will close the service ticket. During the process of closing the ticket you can and add some details like the cost of the work and notes describing the work. You can also attach files to the service which are related to the service.

In this video I will demonstrate how to close a service ticket.

### **5\. Useful tips to fully utilise the Maintain module**

In this video we will demonstrate some useful tips which will help you to use the full potential of the Maintain module.
