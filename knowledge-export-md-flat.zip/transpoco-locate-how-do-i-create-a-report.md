# Transpoco Locate: How do I create a report?

Back to home

1.  Knowledge Base 
3.  Transpoco Locate 

-   Logging-in to your Transpoco account
    -   Login to your Transpoco account
    -   Transpoco Smartphone Apps
    -   2 Factor Authentication
    -   System requirements
    -   Overview of Transpoco
    -   Implementation
-   How to organise your account to achieve the best results
    
-   How to use each feature - step by step guides
    -   Users and permissions
    -   Walkaround Checks module
    -   Fuel/Electric Vehicles Module
    -   Maintain Module
    -   Dashboard
    -   Messaging module
    -   Scheduled Reports
-   How to Order More Trackers
    
-   Live Map
    
-   Cameras
    -   FAQ
-   Webinar Videos
    
-   Walkaround Checklists
    -   Walkaround Checklists
    -   Driver App
    -   Alerts
-   Reports
    -   Reports
    -   Viewing data in reports
-   Fuel
    
-   Dashboard
    
-   Maintain Module
    
-   Driving Style
    
-   Locations
    
-   Cost Management (TCO) Report
    
-   The Notification Features
    
-   Hardware and Installation
    
-   Removal & Repair of Hardware
    -   Requesting a Repair or a Deinstallation
-   Cameras & GDPR Guidelines
    
-   Scheduled Reports
    
-   Safety Program
    
-   Fleet Manager App
    
-   Users & Permissions
    
-   Alerts
    
-   Policies & Documents
    
-   Privacy Policy and Terms & Conditions
    -   RoPA
-   API
    
-   Transpoco User Manuals
    
-   Settings
    -   Garage
-   Whats New?
    
-   Account Mangement Services
    
-   Driver ID process
    
-   Security
    
-   Transpoco Locate
    
-   Subscriptions & Invoices
    
-   Tutorial videos
    
-   Cancelling your account
    
-   VOR
    
-   Installation
    
-   BIKLY
    

# Transpoco Locate: How do I create a report?

## How to run instant online reports in Locate using the Report Generator

Reports are created using the Report Generator on the left-hand side of the screen.

Report Generator

  
The drop-down menus in the Report Generator make it easy for you to select the criteria required for the report. You can choose:

-   Vehicles (one or all)
-   Type of report
-   Beginning and ending dates
-   Name of location or geofence (only for the Locations Report)

In addition, some reports allow for further narrowing of the results with the addition of the Duration calculator. You can run the reports for only those events over or under a specified time, for example **Stops** or **Idling** greater than the specified time.

### Creating a report

Unless otherwise stated for a report, they are all created in the following way:

Select the **Vehicle(s)** – leave as ‘All Vehicles’ or select one from the drop-down menu.

Report Generator - select vehicle

  
Next, select the type of **Report** you wish to run from the drop-down list.

Report Generator - select report

  
Click on the **Begin** and **End** **Calendars** to select the date range for the report.

Report Generator - select dates

  
Click on the **View Report** button. The report will populate.

Report Generator - sample report

### Other statistical formats

Some of the reports, where appropriate, include a chart view as well as the table view. This is a useful way to compare data, such as between vehicles, dates, time of day, etc.

Where appropriate, some reports include a map, such as showing where stops or idling have occurred. If not appropriate for the report, the chart or map view will be greyed out.

Click on the **Chart** tab or **Map** tab, if available, at the top of the report.

Map tabs

###   
Report types

The standard reports that can be run in Locate are:

-   Last Location Report
-   Fleet Summary Report
-   Summary Report
-   Journeys Report
-   Idling Report
-   Stops Report
-   Stops/Idling Report
-   Locations Report
