# Average fuel consumption metric in the Dashboard

Back to home

1.  Knowledge Base 
3.  Dashboard 

-   Logging-in to your Transpoco account
    -   Login to your Transpoco account
    -   Transpoco Smartphone Apps
    -   2 Factor Authentication
    -   System requirements
    -   Overview of Transpoco
    -   Implementation
-   How to organise your account to achieve the best results
    
-   How to use each feature - step by step guides
    -   Users and permissions
    -   Walkaround Checks module
    -   Fuel/Electric Vehicles Module
    -   Maintain Module
    -   Dashboard
    -   Messaging module
    -   Scheduled Reports
-   How to Order More Trackers
    
-   Live Map
    
-   Cameras
    -   FAQ
-   Webinar Videos
    
-   Walkaround Checklists
    -   Walkaround Checklists
    -   Driver App
    -   Alerts
-   Reports
    -   Reports
    -   Viewing data in reports
-   Fuel
    
-   Dashboard
    
-   Maintain Module
    
-   Driving Style
    
-   Locations
    
-   Cost Management (TCO) Report
    
-   The Notification Features
    
-   Hardware and Installation
    
-   Removal & Repair of Hardware
    -   Requesting a Repair or a Deinstallation
-   Cameras & GDPR Guidelines
    
-   Scheduled Reports
    
-   Safety Program
    
-   Fleet Manager App
    
-   Users & Permissions
    
-   Alerts
    
-   Policies & Documents
    
-   Privacy Policy and Terms & Conditions
    -   RoPA
-   API
    
-   Transpoco User Manuals
    
-   Settings
    -   Garage
-   Whats New?
    
-   Account Mangement Services
    
-   Driver ID process
    
-   Security
    
-   Transpoco Locate
    
-   Subscriptions & Invoices
    
-   Tutorial videos
    
-   Cancelling your account
    
-   VOR
    
-   Installation
    
-   BIKLY
    

# Average fuel consumption metric in the Dashboard

## If you want to know what is your fleet average fuel consumption or even for a particular vehicle group, please check how to do it below:

1.  Log on to your transpoco account. 
    
2.  Click on Services > Dashboard.
    
3.  Click on “Add New” .
    
4.  First of all, add a title by typing the title in the text box.   
    v
5.  Then, choose “Average Fuel Consumption” as the Metric type.  
    
6.  Then,  you can choose or not a vehicle group.  
    
7.  You could also select for what period you want to get the average fuel consumption.   
    
8.  You could also choose either you want to show the “comparison period” or not by ticking the little box. .  
      
    
9.  Then you can choose to be considered in the calculation only “Weekdays”, or “Weekends” or both options.  
    

 Note: For the number of rows, you can ignore it, because the average fuel consumption is only a number on the dashboard.

10.   Once you are ready, click on the Save button. .  
11.   Scroll down to the bottom of the dashboard page, then you will be able to see the “Average Fuel Consumption” value.

Note: In the screenshot below, it is showing the average from October to November as displayed in the period field.

  

12.   You could always edit, refresh and delete this metric from the Dashboard on the top right of the widget. .
