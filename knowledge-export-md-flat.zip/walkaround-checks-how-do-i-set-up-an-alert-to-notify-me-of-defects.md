# Walkaround Checks: How do I set up an alert to notify me of defects?

Back to home

1.  Knowledge Base 
3.  Walkaround Checklists 
5.  Alerts 

-   Logging-in to your Transpoco account
    -   Login to your Transpoco account
    -   Transpoco Smartphone Apps
    -   2 Factor Authentication
    -   System requirements
    -   Overview of Transpoco
    -   Implementation
-   How to organise your account to achieve the best results
    
-   How to use each feature - step by step guides
    -   Users and permissions
    -   Walkaround Checks module
    -   Fuel/Electric Vehicles Module
    -   Maintain Module
    -   Dashboard
    -   Messaging module
    -   Scheduled Reports
-   How to Order More Trackers
    
-   Live Map
    
-   Cameras
    -   FAQ
-   Webinar Videos
    
-   Walkaround Checklists
    -   Walkaround Checklists
    -   Driver App
    -   Alerts
-   Reports
    -   Reports
    -   Viewing data in reports
-   Fuel
    
-   Dashboard
    
-   Maintain Module
    
-   Driving Style
    
-   Locations
    
-   Cost Management (TCO) Report
    
-   The Notification Features
    
-   Hardware and Installation
    
-   Removal & Repair of Hardware
    -   Requesting a Repair or a Deinstallation
-   Cameras & GDPR Guidelines
    
-   Scheduled Reports
    
-   Safety Program
    
-   Fleet Manager App
    
-   Users & Permissions
    
-   Alerts
    
-   Policies & Documents
    
-   Privacy Policy and Terms & Conditions
    -   RoPA
-   API
    
-   Transpoco User Manuals
    
-   Settings
    -   Garage
-   Whats New?
    
-   Account Mangement Services
    
-   Driver ID process
    
-   Security
    
-   Transpoco Locate
    
-   Subscriptions & Invoices
    
-   Tutorial videos
    
-   Cancelling your account
    
-   VOR
    
-   Installation
    
-   BIKLY
    

# Walkaround Checks: How do I set up an alert to notify me of defects?

## This alert will notify selected recipients when any defects have been reported during a walkaround check.

As an example, the following shows how to set up an alert for when any defects are found during HGV walkaround checks.

Go to **Services Menu** \>  **Walkaround > Alerts**  >

On the Alerts page click the **+New Alert** button.

Alerts - new button

New alert blank

Type in a **name** for the new alert.

Select ‘Walkaround’ from the drop-down list of **Alert Types**.

New alert 1

Next, click on the drop-down box to select which **checklist** the alert is for. In our example, this is ‘HGV’.

Then select ‘All Defects’ from the **defects** drop-down list.

New alert 2

Finally, select a recipient of the alert from the drop-down list of users.

If required, click on more names to add further recipients; to remove them if added in error, click on the **x** next to their name.

Click on **Create Alert**.

New alert 3

When the alert has been successfully created, the system will show a green confirmation message in the bottom left corner of the screen.

New alert message

The message will fade after a few seconds, or click the **x** to close it immediately.

When the alert has been triggered, an email will be sent to the selected recipients.

Email notification2
