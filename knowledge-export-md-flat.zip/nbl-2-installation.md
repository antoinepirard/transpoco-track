# NBL-2 Installation

Back to home

1.  Knowledge Base 
3.  Installation 

-   Logging-in to your Transpoco account
    -   Login to your Transpoco account
    -   Transpoco Smartphone Apps
    -   2 Factor Authentication
    -   System requirements
    -   Overview of Transpoco
    -   Implementation
-   How to organise your account to achieve the best results
    
-   How to use each feature - step by step guides
    -   Users and permissions
    -   Walkaround Checks module
    -   Fuel/Electric Vehicles Module
    -   Maintain Module
    -   Dashboard
    -   Messaging module
    -   Scheduled Reports
-   How to Order More Trackers
    
-   Live Map
    
-   Cameras
    -   FAQ
-   Webinar Videos
    
-   Walkaround Checklists
    -   Walkaround Checklists
    -   Driver App
    -   Alerts
-   Reports
    -   Reports
    -   Viewing data in reports
-   Fuel
    
-   Dashboard
    
-   Maintain Module
    
-   Driving Style
    
-   Locations
    
-   Cost Management (TCO) Report
    
-   The Notification Features
    
-   Hardware and Installation
    
-   Removal & Repair of Hardware
    -   Requesting a Repair or a Deinstallation
-   Cameras & GDPR Guidelines
    
-   Scheduled Reports
    
-   Safety Program
    
-   Fleet Manager App
    
-   Users & Permissions
    
-   Alerts
    
-   Policies & Documents
    
-   Privacy Policy and Terms & Conditions
    -   RoPA
-   API
    
-   Transpoco User Manuals
    
-   Settings
    -   Garage
-   Whats New?
    
-   Account Mangement Services
    
-   Driver ID process
    
-   Security
    
-   Transpoco Locate
    
-   Subscriptions & Invoices
    
-   Tutorial videos
    
-   Cancelling your account
    
-   VOR
    
-   Installation
    
-   BIKLY
    

# NBL-2 Installation

## Installation instructions for NBL-2 Bluetooth RFID reader

When you receive your NBL-2 device it will be paired with the FMB003 device.

The device is powered by two AAA batteries for use up to two years.  
It beeps every 60 seconds if no RFID is presented to remind the driver to do so.

After the FMB003 device is connected to your OBD port, pressing the red button for 5 seconds switches on the device, it will pair immediately with your GPS device. Upon presenting an RFID reader the device will beep and the green light flash, this transmits the drivers details to the GPS device and in turn to the Transpoco Platform.

Specification  
Supported standards MIFARE® Classic, DESFire, NFC  
(UID and card DATA available)  
Operating frequency 13,56MHz  
Read range up to 5cm, depends on transponder  
Interface Bluetooth LE  
(configure via BL link, firmware update via Bluetooth)  
Buttons two  
Sensors accelerometer, low battery  
LED two (red and green)  
Buzzer yes  
Operating temperature -20°C to +70°C  
Battery life up to 2 years  
Supply two AAA R3

  
•  
Used batteries and damaged/used electronic equipment should NOT go in household garbage or recycling bins. This MUST taken to household hazardous waste collection points.  
•  
Make sure children can't access old batteries / equipment that you need to dispose of.  
•  
Used batteries / equipment can still pose health risks and cause serious or fatal injuries.
