# What are Locations?

Back to home

1.  Knowledge Base 
3.  Locations 

-   Logging-in to your Transpoco account
    -   Login to your Transpoco account
    -   Transpoco Smartphone Apps
    -   2 Factor Authentication
    -   System requirements
    -   Overview of Transpoco
    -   Implementation
-   How to organise your account to achieve the best results
    
-   How to use each feature - step by step guides
    -   Users and permissions
    -   Walkaround Checks module
    -   Fuel/Electric Vehicles Module
    -   Maintain Module
    -   Dashboard
    -   Messaging module
    -   Scheduled Reports
-   How to Order More Trackers
    
-   Live Map
    
-   Cameras
    -   FAQ
-   Webinar Videos
    
-   Walkaround Checklists
    -   Walkaround Checklists
    -   Driver App
    -   Alerts
-   Reports
    -   Reports
    -   Viewing data in reports
-   Fuel
    
-   Dashboard
    
-   Maintain Module
    
-   Driving Style
    
-   Locations
    
-   Cost Management (TCO) Report
    
-   The Notification Features
    
-   Hardware and Installation
    
-   Removal & Repair of Hardware
    -   Requesting a Repair or a Deinstallation
-   Cameras & GDPR Guidelines
    
-   Scheduled Reports
    
-   Safety Program
    
-   Fleet Manager App
    
-   Users & Permissions
    
-   Alerts
    
-   Policies & Documents
    
-   Privacy Policy and Terms & Conditions
    -   RoPA
-   API
    
-   Transpoco User Manuals
    
-   Settings
    -   Garage
-   Whats New?
    
-   Account Mangement Services
    
-   Driver ID process
    
-   Security
    
-   Transpoco Locate
    
-   Subscriptions & Invoices
    
-   Tutorial videos
    
-   Cancelling your account
    
-   VOR
    
-   Installation
    
-   BIKLY
    

# What are Locations?

## In this article we will explain how Locations can help you to solve issues.

Are you experiencing any of these issues?

-   Customers complaining vehicles are not onsite long enough?
-   Providing evidence that your vehicles were onsite for billing?
-   Late starts / early finishing?
-   Speeding infringements?
-   Vehicles leaving Locations?

Did you know you can solve all these issues with our Locations feature?​

With the right click on the map, you can easily create a new geofence location.​

EN

When locations are created in the system, you can easily setup *alerts* to notify you when vehicles enter/exit locations.

​You can also check the *Locations Report* to view a history of all activities inside a selected location.

In addition, the locations will be tagged in your *Journeys Report* when a driver crosses a saved location.

If you have any questions about it please let us know. 

You can also check more details on these articles from our Knowledge Base: 

*How do I add a location or geofence?*

*How do I create a Locations report?*

*What is the Locations database?*

*How do I edit a location?*

Hope you enjoy it!
