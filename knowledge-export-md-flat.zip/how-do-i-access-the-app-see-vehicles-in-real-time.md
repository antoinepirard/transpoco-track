# How do I access the App & see vehicles in real time?

Back to home

1.  Knowledge Base 
3.  Fleet Manager App 

-   Logging-in to your Transpoco account
    -   Login to your Transpoco account
    -   Transpoco Smartphone Apps
    -   2 Factor Authentication
    -   System requirements
    -   Overview of Transpoco
    -   Implementation
-   How to organise your account to achieve the best results
    
-   How to use each feature - step by step guides
    -   Users and permissions
    -   Walkaround Checks module
    -   Fuel/Electric Vehicles Module
    -   Maintain Module
    -   Dashboard
    -   Messaging module
    -   Scheduled Reports
-   How to Order More Trackers
    
-   Live Map
    
-   Cameras
    -   FAQ
-   Webinar Videos
    
-   Walkaround Checklists
    -   Walkaround Checklists
    -   Driver App
    -   Alerts
-   Reports
    -   Reports
    -   Viewing data in reports
-   Fuel
    
-   Dashboard
    
-   Maintain Module
    
-   Driving Style
    
-   Locations
    
-   Cost Management (TCO) Report
    
-   The Notification Features
    
-   Hardware and Installation
    
-   Removal & Repair of Hardware
    -   Requesting a Repair or a Deinstallation
-   Cameras & GDPR Guidelines
    
-   Scheduled Reports
    
-   Safety Program
    
-   Fleet Manager App
    
-   Users & Permissions
    
-   Alerts
    
-   Policies & Documents
    
-   Privacy Policy and Terms & Conditions
    -   RoPA
-   API
    
-   Transpoco User Manuals
    
-   Settings
    -   Garage
-   Whats New?
    
-   Account Mangement Services
    
-   Driver ID process
    
-   Security
    
-   Transpoco Locate
    
-   Subscriptions & Invoices
    
-   Tutorial videos
    
-   Cancelling your account
    
-   VOR
    
-   Installation
    
-   BIKLY
    

# How do I access the App & see vehicles in real time?

## Where to download the SynX Fleet Manager app, how to login, and how to view vehicles in real time

The SynX Fleet Manager app includes some of the features of the main system – real-time position of fleet on map, live vehicle details, Daily Summary Report and Journeys Report.

### Accessing the app

Download and install the SynX Fleet Manager app from Google Play or the App Store.

For this user guide, the Android version has been used.

-   Open the app to the login page.
-   Enter assigned username and password, which are the same as those assigned for the main SynX system, and tap on **LOGIN**.

**Note:** To reset your password, see Reset password.

Screenshot\_20190502\_192014\_com.synx.fleetmanager

You can check 'Remember me for 30 days' so you do not need to login again for 30 days.

**Note:** For security reasons, your phone should be protected with password/pin/biometric security if you choose this option.

### Home page / live map

The app opens to the home page which shows the map and fleet in real time (default is to show all vehicles).

Screenshot\_20190502\_192034\_com.synx.fleetmanager

**Note:** Numbers in circles denote the number of vehicles in that area; they are clustered on the map when too close together.

Use spread/pinch on the screen to zoom in and out of the map.

From the home page, tap on **All Groups** to select a vehicle group from the list.

To return to the main screen without making a selection, tap the arrow at the top of the screen.

Screenshot\_20190519\_132718\_com.synx.fleetmanager

From the home page, tap on **All Vehicles** to select one vehicle from the list.

Screenshot\_20190523\_235420\_com.synx.fleetmanager      Screenshot\_20190519\_152052\_com.synx.fleetmanager

**Note:** Vehicles listed in red have their engine off; vehicles in green have their engine on.

To return to the main screen without making a selection, tap the arrow at the top of the screen.

If required, tap on **Satellite** to change the map view.

Screenshot\_20190519\_152055\_com.synx.fleetmanager
