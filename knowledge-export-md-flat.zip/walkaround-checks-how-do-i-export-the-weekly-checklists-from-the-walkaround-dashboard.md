# Walkaround Checks: How do I export the weekly checklists from the Walkaround dashboard?

Back to home

1.  Knowledge Base 
3.  Walkaround Checklists 
5.  Walkaround Checklists 

-   Logging-in to your Transpoco account
    -   Login to your Transpoco account
    -   Transpoco Smartphone Apps
    -   2 Factor Authentication
    -   System requirements
    -   Overview of Transpoco
    -   Implementation
-   How to organise your account to achieve the best results
    
-   How to use each feature - step by step guides
    -   Users and permissions
    -   Walkaround Checks module
    -   Fuel/Electric Vehicles Module
    -   Maintain Module
    -   Dashboard
    -   Messaging module
    -   Scheduled Reports
-   How to Order More Trackers
    
-   Live Map
    
-   Cameras
    -   FAQ
-   Webinar Videos
    
-   Walkaround Checklists
    -   Walkaround Checklists
    -   Driver App
    -   Alerts
-   Reports
    -   Reports
    -   Viewing data in reports
-   Fuel
    
-   Dashboard
    
-   Maintain Module
    
-   Driving Style
    
-   Locations
    
-   Cost Management (TCO) Report
    
-   The Notification Features
    
-   Hardware and Installation
    
-   Removal & Repair of Hardware
    -   Requesting a Repair or a Deinstallation
-   Cameras & GDPR Guidelines
    
-   Scheduled Reports
    
-   Safety Program
    
-   Fleet Manager App
    
-   Users & Permissions
    
-   Alerts
    
-   Policies & Documents
    
-   Privacy Policy and Terms & Conditions
    -   RoPA
-   API
    
-   Transpoco User Manuals
    
-   Settings
    -   Garage
-   Whats New?
    
-   Account Mangement Services
    
-   Driver ID process
    
-   Security
    
-   Transpoco Locate
    
-   Subscriptions & Invoices
    
-   Tutorial videos
    
-   Cancelling your account
    
-   VOR
    
-   Installation
    
-   BIKLY
    

# Walkaround Checks: How do I export the weekly checklists from the Walkaround dashboard?

## The checks in Weekly View can be exported to spreadsheet programs, either emailed to recipients or downloaded locally.

To export the data as .csv or .xls format, click on the blue **Export** icon above the far right column in the reports.

Select the **File Format** from the drop-down list – either CSV or EXCEL.

#### Download file

To download the file onto your system, select ‘Download File’ in the **Expert Option**

Click the blue **Download** button.

Export weekly view - download

#### Email file

To email the file to recipients, select ‘Send file by email’ in the **Expert Option**

Click in the **Send the export to box** (or on **down arrow**) and select a recipient from the list. Repeat to add more recipients.

Export weekly view - email

Press the blue **Send Email** button.

After SynX has sent the file, a pop up confirmation appears in the bottom left of the screen.

Email file sent

Open the email.

Screenshot\_20190918\_001817\_com.android.email

Click on the black **Download** link in the email.

Save the file in the required location.
