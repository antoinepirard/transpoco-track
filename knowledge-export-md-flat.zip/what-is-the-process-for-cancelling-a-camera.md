# What is the process for cancelling a camera?

Back to home

1.  Knowledge Base 
3.  Cameras 
5.  FAQ 

-   Logging-in to your Transpoco account
    -   Login to your Transpoco account
    -   Transpoco Smartphone Apps
    -   2 Factor Authentication
    -   System requirements
    -   Overview of Transpoco
    -   Implementation
-   How to organise your account to achieve the best results
    
-   How to use each feature - step by step guides
    -   Users and permissions
    -   Walkaround Checks module
    -   Fuel/Electric Vehicles Module
    -   Maintain Module
    -   Dashboard
    -   Messaging module
    -   Scheduled Reports
-   How to Order More Trackers
    
-   Live Map
    
-   Cameras
    -   FAQ
-   Webinar Videos
    
-   Walkaround Checklists
    -   Walkaround Checklists
    -   Driver App
    -   Alerts
-   Reports
    -   Reports
    -   Viewing data in reports
-   Fuel
    
-   Dashboard
    
-   Maintain Module
    
-   Driving Style
    
-   Locations
    
-   Cost Management (TCO) Report
    
-   The Notification Features
    
-   Hardware and Installation
    
-   Removal & Repair of Hardware
    -   Requesting a Repair or a Deinstallation
-   Cameras & GDPR Guidelines
    
-   Scheduled Reports
    
-   Safety Program
    
-   Fleet Manager App
    
-   Users & Permissions
    
-   Alerts
    
-   Policies & Documents
    
-   Privacy Policy and Terms & Conditions
    -   RoPA
-   API
    
-   Transpoco User Manuals
    
-   Settings
    -   Garage
-   Whats New?
    
-   Account Mangement Services
    
-   Driver ID process
    
-   Security
    
-   Transpoco Locate
    
-   Subscriptions & Invoices
    
-   Tutorial videos
    
-   Cancelling your account
    
-   VOR
    
-   Installation
    
-   BIKLY
    

# What is the process for cancelling a camera?

## How to cancel a camera contract.

**Cancellation Process**

**1\. Notification to cancel**

Please provide us with 30 days notice of cancellation. For our records we will require you to express your intention to cancel in writing. Please email support@transpoco.com with your intention to cancel.

We will respond to the email acknowledging the cancellation and that no further subscription payments for the dash camera(s) will be charged.

**2\. Status of hardware**

As you have purchased the dash camera(s) there will be no need to return of the dash camera(s).

However, we will cancel the SIM card in the dash camera(s) and the dash camera will no longer be accessible in your Transpoco account.

To continue to use the dash camera(s) with another provider your dash camera will require a new SIM card and reformatting by any new provider.

**3\. Refund**

We will stop future subscription payments the dash camera(s). We will not offer any partial refund from your previous payment.

**4\. Third party financing**

If you have financed the purchase of your camera through third party financing and intend to cancel please contact your finance provider.

You can contact Transpoco to stop your subscription charges- email us at support@transpoco.com
