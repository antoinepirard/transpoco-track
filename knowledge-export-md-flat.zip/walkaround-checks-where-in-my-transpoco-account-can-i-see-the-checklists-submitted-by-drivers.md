# Walkaround Checks: Where in my Transpoco account can I see the checklists submitted by drivers?

Back to home

1.  Knowledge Base 
3.  Walkaround Checklists 
5.  Walkaround Checklists 

-   Logging-in to your Transpoco account
    -   Login to your Transpoco account
    -   Transpoco Smartphone Apps
    -   2 Factor Authentication
    -   System requirements
    -   Overview of Transpoco
    -   Implementation
-   How to organise your account to achieve the best results
    
-   How to use each feature - step by step guides
    -   Users and permissions
    -   Walkaround Checks module
    -   Fuel/Electric Vehicles Module
    -   Maintain Module
    -   Dashboard
    -   Messaging module
    -   Scheduled Reports
-   How to Order More Trackers
    
-   Live Map
    
-   Cameras
    -   FAQ
-   Webinar Videos
    
-   Walkaround Checklists
    -   Walkaround Checklists
    -   Driver App
    -   Alerts
-   Reports
    -   Reports
    -   Viewing data in reports
-   Fuel
    
-   Dashboard
    
-   Maintain Module
    
-   Driving Style
    
-   Locations
    
-   Cost Management (TCO) Report
    
-   The Notification Features
    
-   Hardware and Installation
    
-   Removal & Repair of Hardware
    -   Requesting a Repair or a Deinstallation
-   Cameras & GDPR Guidelines
    
-   Scheduled Reports
    
-   Safety Program
    
-   Fleet Manager App
    
-   Users & Permissions
    
-   Alerts
    
-   Policies & Documents
    
-   Privacy Policy and Terms & Conditions
    -   RoPA
-   API
    
-   Transpoco User Manuals
    
-   Settings
    -   Garage
-   Whats New?
    
-   Account Mangement Services
    
-   Driver ID process
    
-   Security
    
-   Transpoco Locate
    
-   Subscriptions & Invoices
    
-   Tutorial videos
    
-   Cancelling your account
    
-   VOR
    
-   Installation
    
-   BIKLY
    

# Walkaround Checks: Where in my Transpoco account can I see the checklists submitted by drivers?

## By default, the module opens to the Weekly View page of the walkaround checks, showing the current week. This shows the overall result of checks performed on each vehicle on each day of the week.

Click on **Walkaround** in the header navigation menu in SynX.

To change the week, click on the **blue arrows** situated either side of the date range.

**Note:** A week runs from Monday to Sunday..

The icons are as follows:

Orange icon

No checks have been carried out

Green icon

All checks carried out have had no problems to report

Red icon

Of all the checks carried out, at least one had a problem to report

Black icon

No checks have been carried out but the vehicle has been driven on X date, travelling X km in X hours

Click on a green or red icon in the Weekly View to view the list of walkaround checklists carried out on that vehicle during that week.

**Note:** Clicking on a green icon will show all the walkaround checklists that returned a *‘Yes’ for every question* on the list; clicking on a red icon will include the list of checks that have a *vehicle with at least one problem* (see following image).

Green & Red icons

The information contained in this report covers the following summary information about the checklists undertaken by the selected driver on the selected day:

-   **Defect:** Green denotes all checks OK; red denotes at least one check has a problem
-   **Time:** When the check was completed and submitted to the web
-   **Additional Comments:** Added during walkaround check
-   **Inspector:** Who carried out the walkaround check
-   **Type:** Type of checklist

Click on **Previous** and **Next** at the bottom to scroll through the pages of checklists.

The weekly view checklists can be:

-   sorted by vehicle
-   filtered or searched
-   drilled down to view checks and defects
-   exported

In addition, servicing/repairs required from the issues found in the checklist can be actioned directly from the Weekly View.
