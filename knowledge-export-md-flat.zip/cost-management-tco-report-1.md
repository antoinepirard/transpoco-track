# Cost Management (TCO) Report

Back to home

1.  Knowledge Base 
3.  Cost Management (TCO) Report 

-   Logging-in to your Transpoco account
    -   Login to your Transpoco account
    -   Transpoco Smartphone Apps
    -   2 Factor Authentication
    -   System requirements
    -   Overview of Transpoco
    -   Implementation
-   How to organise your account to achieve the best results
    
-   How to use each feature - step by step guides
    -   Users and permissions
    -   Walkaround Checks module
    -   Fuel/Electric Vehicles Module
    -   Maintain Module
    -   Dashboard
    -   Messaging module
    -   Scheduled Reports
-   How to Order More Trackers
    
-   Live Map
    
-   Cameras
    -   FAQ
-   Webinar Videos
    
-   Walkaround Checklists
    -   Walkaround Checklists
    -   Driver App
    -   Alerts
-   Reports
    -   Reports
    -   Viewing data in reports
-   Fuel
    
-   Dashboard
    
-   Maintain Module
    
-   Driving Style
    
-   Locations
    
-   Cost Management (TCO) Report
    
-   The Notification Features
    
-   Hardware and Installation
    
-   Removal & Repair of Hardware
    -   Requesting a Repair or a Deinstallation
-   Cameras & GDPR Guidelines
    
-   Scheduled Reports
    
-   Safety Program
    
-   Fleet Manager App
    
-   Users & Permissions
    
-   Alerts
    
-   Policies & Documents
    
-   Privacy Policy and Terms & Conditions
    -   RoPA
-   API
    
-   Transpoco User Manuals
    
-   Settings
    -   Garage
-   Whats New?
    
-   Account Mangement Services
    
-   Driver ID process
    
-   Security
    
-   Transpoco Locate
    
-   Subscriptions & Invoices
    
-   Tutorial videos
    
-   Cancelling your account
    
-   VOR
    
-   Installation
    
-   BIKLY
    

# Cost Management (TCO) Report

## The Cost Management (TCO) Report will allow you to view the running cost for each vehicle in your fleet. In this article we will explain everything you need to know to help you to use this report.

### **What is a Cost Management report?**

We created the Cost Management to help you to identify the total cost of ownership of a vehicle. Our report will gather together all of the costs associated with owning a vehicle as well as providing you with key metrics like cost per KM. Some of the costs will be sourced from your Transpoco account if you are using our Fuel and Maintain.

### Where can you find the Cost Management (TCO) Report?

You can find the link to the Cost Management (TCO) Report on the **Services** menu in your account.

image (39)-3

### **Example of a Cost Management Report**

unnamed-1-

### **Report Filters**

**image-39-**

**Date Period** - Select a time period

**Comparison Period** - Select a comparison time period - see the **'Running a comparison report'** section below to view an example of a comparison report.

**Vehicle Group-** You can improve your search by selecting a vehicle group.

**Vehicle**\- Select a registration from the selected vehicle group or all vehicles if no vehicle group was selected.

### **What is the source of in the data in the report?**

In this section we will explain the source of the different data points. 

**Current Value:** You can enter a value in the **Vehicle Settings** section in the report - see the Vehicles Settings section below.

**Latest odometer:** The is the odometer being tracked in your Transpoco account.

**Cost of acquisition:** The cost of acquisition can be entered in the **Vehicles** section in Settings. Go to the **Settings menu**, select **Vehicles**, click **Edit** on the last column and then enter a value in **Purchase Cost.**

**Fuel Type:** The default fuel type for a vehicle is Diesel but you can change the type by going to the **Settings menu**, select **Vehicles,** click **Edit** on the last column and then edit the **Fuel Type.**

**Vehicle Groups:** If the selected vehicle has been assigned to 1 or more vehicle groups we will display the names of the groups here.

**Distance:** The distance tracked by Transpoco during the selected time period.

**Taxes & Charges:** You can enter the total cost of taxes and charges in the **Vehicle Settings** section in the report - see the Vehicles Settings section below.

**Total Insurance:**  You can enter the total cost of insurance in the **Vehicle Settings** section in the report - see the Vehicles Settings section below.

**Total Maintenance:** This cost comes from the **Maintain** section in your Transpoco account, the cost is the total cost of service tickets for the selected vehicle during the selected time period.

**Total Fuel:** This cost comes from the **Fuel** section in your Transpoco account, the cost is the total cost of fuel transactions assigned to the selected vehicle during the selected time period.

### **Vehicle Settings**

To allow you to input costs which are not available in your Transpoco account we created a Settings section. You can enter a cost for **Tax and Charges**, **Insurance** and **Vehicle Value** for each year.

We allow you to select a currency, **Euro** or **GBP.**

**Cost (1)**

To help you to assign costs to your vehicles we have created a shortcut which will allow you to assign the same cost to all vehicles for the selected time period- see the example below. In this example we selected 'All Vehicles' instead of selecting 1 vehicle registration. We assigned the same costs to all vehicles.

**Cost (1)-2**

### **Running a comparison report**

To run a comparison report select a comparison time period in the Filters of the report at the top of the report. Here is an example of a comparison report.

Cost-1- (1)

### Drivers

The Cost Management (TCO) Report will also display the names of each driver who drove the vehicle during the selected time period. The drivers will be identified by their driver ID fob. 

Cost (1)-3
