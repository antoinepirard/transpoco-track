# Fuel Service - How to assign vehicles in the fuel process to attribute all vehicle purchases to a specific card (even for tracked vehicles)?

Back to home

1.  Knowledge Base 
3.  Fuel 

-   Logging-in to your Transpoco account
    -   Login to your Transpoco account
    -   Transpoco Smartphone Apps
    -   2 Factor Authentication
    -   System requirements
    -   Overview of Transpoco
    -   Implementation
-   How to organise your account to achieve the best results
    
-   How to use each feature - step by step guides
    -   Users and permissions
    -   Walkaround Checks module
    -   Fuel/Electric Vehicles Module
    -   Maintain Module
    -   Dashboard
    -   Messaging module
    -   Scheduled Reports
-   How to Order More Trackers
    
-   Live Map
    
-   Cameras
    -   FAQ
-   Webinar Videos
    
-   Walkaround Checklists
    -   Walkaround Checklists
    -   Driver App
    -   Alerts
-   Reports
    -   Reports
    -   Viewing data in reports
-   Fuel
    
-   Dashboard
    
-   Maintain Module
    
-   Driving Style
    
-   Locations
    
-   Cost Management (TCO) Report
    
-   The Notification Features
    
-   Hardware and Installation
    
-   Removal & Repair of Hardware
    -   Requesting a Repair or a Deinstallation
-   Cameras & GDPR Guidelines
    
-   Scheduled Reports
    
-   Safety Program
    
-   Fleet Manager App
    
-   Users & Permissions
    
-   Alerts
    
-   Policies & Documents
    
-   Privacy Policy and Terms & Conditions
    -   RoPA
-   API
    
-   Transpoco User Manuals
    
-   Settings
    -   Garage
-   Whats New?
    
-   Account Mangement Services
    
-   Driver ID process
    
-   Security
    
-   Transpoco Locate
    
-   Subscriptions & Invoices
    
-   Tutorial videos
    
-   Cancelling your account
    
-   VOR
    
-   Installation
    
-   BIKLY
    

# Fuel Service - How to assign vehicles in the fuel process to attribute all vehicle purchases to a specific card (even for tracked vehicles)?

## If you have non-tracked vehicles and/or want to desconsider GPS checking for your purchases, you can assign a vehicle to a fuel card and/or add a registration to a card description to match with the vehicle declared at the till by the driver.

#### Please follow the steps below:

1.  Log In to your Transpoco Synx account.
2.  Then click Services > Fuel > Fuel Cards.

3\. Then you can add a vehicle registration to the card description and/or assign a vehicle to the card directly. 

**Note 1**: The difference between them is that if you add the registration to the card description only, the system will still look for the vehicle declared by the driver at the till  to match it with the card description.

If you assign a vehicle to a card, all the card's purchases will be directly assigned to this vehicle assigned to it.

If you do both methods, **the second option overwrittes the first option.**

**Note 2** :The vehicle declared is the registration which the driver is supposed to give at the till when they buy fuel. 

 4.  If you assign a vehicle to a card, the system will automatically assign all card's purchases to this vehicle. If not, it will look for a registration in the card's description and try to match it with the reg provided by the driver at the till.

If none of the above options are done, the system will run the regular GPS checkings.

 5.  To see all the transactions and assignments , please go to Fuel Transactions menu option:
