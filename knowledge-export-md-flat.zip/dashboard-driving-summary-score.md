# Dashboard - Driving Summary Score

Back to home

1.  Knowledge Base 
3.  Dashboard 

-   Logging-in to your Transpoco account
    -   Login to your Transpoco account
    -   Transpoco Smartphone Apps
    -   2 Factor Authentication
    -   System requirements
    -   Overview of Transpoco
    -   Implementation
-   How to organise your account to achieve the best results
    
-   How to use each feature - step by step guides
    -   Users and permissions
    -   Walkaround Checks module
    -   Fuel/Electric Vehicles Module
    -   Maintain Module
    -   Dashboard
    -   Messaging module
    -   Scheduled Reports
-   How to Order More Trackers
    
-   Live Map
    
-   Cameras
    -   FAQ
-   Webinar Videos
    
-   Walkaround Checklists
    -   Walkaround Checklists
    -   Driver App
    -   Alerts
-   Reports
    -   Reports
    -   Viewing data in reports
-   Fuel
    
-   Dashboard
    
-   Maintain Module
    
-   Driving Style
    
-   Locations
    
-   Cost Management (TCO) Report
    
-   The Notification Features
    
-   Hardware and Installation
    
-   Removal & Repair of Hardware
    -   Requesting a Repair or a Deinstallation
-   Cameras & GDPR Guidelines
    
-   Scheduled Reports
    
-   Safety Program
    
-   Fleet Manager App
    
-   Users & Permissions
    
-   Alerts
    
-   Policies & Documents
    
-   Privacy Policy and Terms & Conditions
    -   RoPA
-   API
    
-   Transpoco User Manuals
    
-   Settings
    -   Garage
-   Whats New?
    
-   Account Mangement Services
    
-   Driver ID process
    
-   Security
    
-   Transpoco Locate
    
-   Subscriptions & Invoices
    
-   Tutorial videos
    
-   Cancelling your account
    
-   VOR
    
-   Installation
    
-   BIKLY
    

# Dashboard - Driving Summary Score

## You can add the Driving Summary Score to the Dashboard. It indicates the overall driving summary score of selected vehicles/vehicle groups during any specific period. Please check the instructions below:

Note: This score takes into consideration the same settings from the Driving Style module. Possible driver performance parameters are:

-   Rapid Acceleration
-   Harsh Braking
-   Harsh Cornering
-   Speeding 

1.  Log in to your Transpoco account.
2.  Click Services > Dashboard.  
    
3.  Then click the “add new” button on the right top of the page. .
4.  Firstly, type in a title for this metric.  
    
5.  Then, make sure you select the “Driving Summary Score” for the Metric type.  
    
6.  Then you can choose all vehicle groups or any specific vehicle groups as you wish.  
    
7.  You can also compare the vehicle groups, and it will show a different chart by ticking the box besides “Split per group”.  
    
8.  Then you can choose a date period for the metric either by choosing a default period such as “Last week”  or by selecting your own custom period.  
    
9.  You can also compare two different periods by ticking the box beside “Comparison Period”.  
    

**Note:** You can choose the comparison period for the metric either by choosing a default period such as “Last week”  or by selecting your own custom period as well.

10.  You can change the “number of rows”. 

11.  After setting up everything for the metric, click “Save”.

12.  Then you will see the metric - Driving Summary Score appears in the dashboard.

This one is the driving summary score **per group** (split per group) (**with** comparison period): 

  
  

This one is the driving summary score **without** split per group (**with** comparison period):

  
  

This one is the driving summary score **without** the comparison period **with** split per group:

This one is the driving summary score **without** the comparison period and **without** split per group:

Note: All drivers start with 100% and this score will keep reducing based on the falties percentage. E.g.: Speeding over limit, harsh braking, rapid acceleration, harsh cornering.
