# Templates for customised walkaround checklists.

Back to home

1.  Knowledge Base 
3.  Walkaround Checklists 
5.  Walkaround Checklists 

-   Logging-in to your Transpoco account
    -   Login to your Transpoco account
    -   Transpoco Smartphone Apps
    -   2 Factor Authentication
    -   System requirements
    -   Overview of Transpoco
    -   Implementation
-   How to organise your account to achieve the best results
    
-   How to use each feature - step by step guides
    -   Users and permissions
    -   Walkaround Checks module
    -   Fuel/Electric Vehicles Module
    -   Maintain Module
    -   Dashboard
    -   Messaging module
    -   Scheduled Reports
-   How to Order More Trackers
    
-   Live Map
    
-   Cameras
    -   FAQ
-   Webinar Videos
    
-   Walkaround Checklists
    -   Walkaround Checklists
    -   Driver App
    -   Alerts
-   Reports
    -   Reports
    -   Viewing data in reports
-   Fuel
    
-   Dashboard
    
-   Maintain Module
    
-   Driving Style
    
-   Locations
    
-   Cost Management (TCO) Report
    
-   The Notification Features
    
-   Hardware and Installation
    
-   Removal & Repair of Hardware
    -   Requesting a Repair or a Deinstallation
-   Cameras & GDPR Guidelines
    
-   Scheduled Reports
    
-   Safety Program
    
-   Fleet Manager App
    
-   Users & Permissions
    
-   Alerts
    
-   Policies & Documents
    
-   Privacy Policy and Terms & Conditions
    -   RoPA
-   API
    
-   Transpoco User Manuals
    
-   Settings
    -   Garage
-   Whats New?
    
-   Account Mangement Services
    
-   Driver ID process
    
-   Security
    
-   Transpoco Locate
    
-   Subscriptions & Invoices
    
-   Tutorial videos
    
-   Cancelling your account
    
-   VOR
    
-   Installation
    
-   BIKLY
    

# Templates for customised walkaround checklists.

In the Driver app we provide you with 2 checklists; an LCV checklist and an HGV checklist. You can add your own checklists. If you do not have checklists we have included a few suggested checklists below.

Click here to learn how you can create a customised checklist in your Transpoco account.

### Content: 

1.  HGV(Default)
2.  LCV(Default)
3.  COVID (long)
4.  COVID (short)
5.  Driver Performance Score
6.  JSSP
7.  Rigid Truck
8.  Job Safety Site Plan
9.  Accident Form
10.  Driver Declaration
11.  Site Inspection
12.  CarVanJeep

  

Note: You could view each file by clicking this icon besides each title below.

#### **1.  HGV (default)**  

***QUESTION***

***PLACE***

***ANSWER TYPE***

Driving controls, seat and driver safety belt adjusted correctly.

inside

Answer yes/no

Good visibility for drivers through all cab windows and mirrors. All required mirrors fitted and adjusted correctly.

inside

Answer yes/no

Windscreen washer, wipers, demister and horn operating correctly.

inside

Answer yes/no

All instruments, gauges and other warning devices operating correctly.

inside

Answer yes/no

Cab clean with no obstructions or loose material.

inside

Answer yes/no

Vehicle sitting square and not leaning to one side.

outside

Answer yes/no

Tax, insurance and transport (if applicable) discs present and valid. Number plates clearly visible.

outside

Answer yes/no

Wheels in good condition and secure. Tyres undamaged with correct inflation and tread depth.

outside

Answer yes/no

All lights and reflectors fitted, clean and in good condition.

outside

Answer yes/no

ABS/EBS warning lights off.

inside

Answer yes/no

Exhaust secure with no excess noise or smoke.

outside

Answer yes/no

No air leaks or pressure drops.

inside

Answer yes/no

Vehicle access, doors, steps and bodywork in good condition.

outside

Answer yes/no

Air & electrical suzies and connectors fitted (inc. ABS / EBS cable).

outside

Answer yes/no

Fuel cap seal in place and not leaking.

outside

Answer yes/no

Fifth wheel located and locked correctly, landing legs and handle in correct position.

outside

Answer yes/no

Engine oil, water, windscreen washer reservoir and fuel levels checked and no leaks.

outside

Answer yes/no

Air suspension correctly set.

outside

Answer yes/no

Steering and brakes operating correctly.

inside

Answer yes/no

Load within limits, secured and weight distributed correctly.

inside

Answer yes/no

Tachograph calibrated with correct hours. Speed limiter plaque displayed.

inside

Answer yes/no

Trailer park brake operating correctly.

outside

Answer yes/no

Enter your odometer.

Odometer

number

#### **2.  LCV (default)** 

***QUESTION***

***PLACE***

***ANSWER TYPE***

Driving controls, seat and driver safety belt adjusted correctly.

inside

Answer yes/no

Good visibility for drivers through all cab windows and mirrors. All required mirrors fitted and adjusted correctly.

inside

Answer yes/no

Windscreen washer, wipers, demister and horn operating correctly.

inside

Answer yes/no

All instruments, gauges and other warning devices operating correctly.

inside

Answer yes/no

Cab clean with no obstructions or loose material.

inside

Answer yes/no

High visibility jacket/vest accessible in cab.

inside

Answer yes/no

Vehicle sitting square and not leaning to one side.

outside

Answer yes/no

Tax, insurance and transport (if applicable) discs present and valid. Number plates clearly visible.

outside

Answer yes/no

Wheels in good condition and secure. Tyres undamaged with correct inflation and tread depth.

outside

Answer yes/no

All lights and reflectors fitted, clean and in good condition.

outside

Answer yes/no

ABS/EBS warning lights off.

inside

Answer yes/no

Exhaust secure with no excess noise or smoke.

outside

Answer yes/no

Vehicle access, doors, steps and bodywork in good condition.

outside

Answer yes/no

Fuel cap seal in place and not leaking.

outside

Answer yes/no

Engine oil, water, windscreen washer reservoir and fuel levels checked and no leaks.

outside

Answer yes/no

Steering and brakes operating correctly.

inside

Answer yes/no

Load within limits, secured and weight distributed correctly.

inside

Answer yes/no

Enter your odometer.

Odometer

number

#### **3.   COVID (long)** 

  

***QUESTION***

***ANSWER TYPE***

Are you within any of the at risk options above

yes/no

In the last 14 days have you been advised by a doctor to self-isolate in the last at this time?

yes/no

In the last 14 days have you been advised by a doctor to cocoon at this time?

yes/no

In the last 14 days have you had a temperature of 38 degrees or higher or fever?

yes/no

In the last 14 days have you had any kind of cough, not just dry?

yes/no

In the last 14 days have you suffered from any shortness of breath?

yes/no

In the last 14 days have you suffered breathing difficulties?

yes/no

In the last 14 days have you been in close contact with a confirmed case of COVID- 19?

yes/no

In the last 14 days have you been living with someone with symptoms of COVID-19?

yes/no

In the last 14 days have you returned to the island of Ireland from abroad?

yes/no

Have you been diagnosed with confirmed or suspected COVID-19

yes/no

Have you completed 14 days of self isolation

yes/no

Have you had a high temperature or fever in the last 5 days?

yes/no

**Note: We need to include the content below on the screen for check 1**

*At Risk Groups*

*1\. Are you over 60*

*2\. Have long-term medical diseases for example, heart disease, lung diseases, diabetes, cancer, cerebrovascular disease, renal disease, liver disease or high blood pressure?*

*3\. Have you a weak immune system (immunosuppressed)*

*4\. Have a medical condition that can affect your breathing*

#### **4.   COVID (short)** 

***QUESTION***

***ANSWER TYPE***

Are you displaying any typical COVID 19 symptoms? (Cough, Fever, Difficulty breathing)

yes / no comment

Have you been in close contact with anyone with the above symptoms?

yes / no comment

Do you have sufficient PPE and hygiene supplies available for your work today?

yes / no comment

Have you wiped down steering wheels and door handles?

yes / no

Are you adhering to the social distancing recommendations where possible?

yes / no comment

Are you feeling safe and comfortable about your work today? (eg, not experiencing anxiety or stress)

yes / no comment

#### **5.  Driver Performance Score** 

***QUESTION***

***ACTION***

***DROP DOWN LISTS***

***ALERT***

What was your percentage score today?

Drop down list

1-50%, 51-80% and 81%-100%

Alert on anything below 80%

What was your rank?

number

 

 

How will you improve?

text

 

 

Do you need driver training help?

yes/no

 

Alert on 'Yes' response

####   **6.  JSSP** 

***QUESTION***

***ANSWER TYPE***

Who is the client?

Text

What is your location?

Location

Has a CAT scan been carried out?

yes/no

Is there sufficient light?

yes/no

Is a safe working platform required?

yes/no

Welfare facilities Identified

yes/no comment

**Are you wearing approved PPE?**

 

***QUESTION***

***ANSWER TYPE***

Safety Helmet

yes/no

Eye Protection

yes/no

Safety boots

yes/no

Hi Vis Vest

yes/no

Water resistant overalls

yes/no

Hearing protection

yes/no

Face mask (Covid 19)

yes/no

Other

text

**Other hazards and activities**

 

***QUESTION***

***ANSWER TYPE***

Manual handling

yes/no

Slips, trips, falls

yes/no

Objects falling

yes/no

Driving conditions

yes/no

Overhead services

yes/no

Weather

yes/no

Sharp needles

yes/no

Fire, smoke

yes/no

Animals

yes/no

Proximity to water

yes/no

Hazardous substances

yes/no

Other hazards

text

What is the task

List of answers:

-   Trial Pitting Slit trenching
-   Plate testing
-   Cable Percussion boring
-   Rotary Coring
-   Dynamic Probing

  

**Traffic Management**

 

***QUESTION***

***ANSWER TYPE***

Is traffic to be controlled

yes/no

Are Gardai/ Local authority notified

yes/no

Is CSCS holder on site

yes/no

Is Safety plan prepared

yes/no

Approved signs and cones

yes/no

Safe pedestrian passage

yes/no

other

text

**Inspect all Equipment and CSCS cards**

 

***QUESTION***

***ANSWER TYPE***

Valid Certification

yes/no

Approved to operate rig/ valid CSCS cards

yes/no

Inspect tools and plant equipment

yes/no

Inspect lifting equipment

yes/no

Emergency controls accessible

yes/no

Correct SWL

yes/no

Restrict 3rd party access

yes/no

Other

text

**Excavations**

 

***QUESTION***

***ANSWER TYPE***

Edge protection

yes/no

Safe access & Egress

yes/no

UG Networks

yes/no

Ground Conditions

yes/no

Hand Dig

yes/no

Erect warning signs/ Barriers

yes/no

Hazardous Substances

yes/no

Other Utilities

yes/no

Shore-Up, Batten back below 1.25m

yes/no

Other

text

**Personnel**

 

***QUESTION***

***ANSWER TYPE***

Name

Text

Contact

Text

**Job Completion**

 

***QUESTION***

***ANSWER TYPE***

Have control measures in this JSSP been implemented?

yes/no

If not provide details

text

Were there any issues on site during work?

yes/no

Specify Issue

list of answers 

-   Accident
-   Incident
-   Near Miss

Provide details

text

On completion of the works has the site been left safe for other users

yes/no

If no provide details

text

####   **7.  Rigid Truck** 

**HGV MANN TRUCKS**

***QUESTION***

***ANSWER TYPE***

IGNITION ON

Answer yes/no

DIDGI CARD INSERTED AND SET TO OTHER WORK

Answer yes/no

ENTER MILEAGE

Number

PHOTO OF DASHBOARD SHOWING ANY WARNING LIGHTS

photo (Camera and Gallery accesses or only Camera access can be set)

WIPERS/WASHERS WORKING

Answer yes/no

HORN WORKING/NO SMOKING SIGN

Answer yes/no

FRIDGE TURNED ON AND WORKING

Answer yes/no

TAKE PHOTO OF REGISTRATION PLATE

photo (Camera and Gallery accesses or only Camera access can be set)

TAKE PHOTO OF ALL LIGHTS WORKING

photo (Camera and Gallery accesses or only Camera access can be set)

GVTA DISC ON DISPLAY

photo (Camera and Gallery accesses or only Camera access can be set)

MIRRORS

Answer yes/no

FRONT TYRES

Answer yes/no

WHEEL NUTS TIGHT

Answer yes/no

DRIVERS SIDE CRASH BARRIER

Answer yes/no

DIESEL TANKS /CAPS

Answer yes/no

REAR TYRES DRIVERS SIDE

Answer yes/no

SIDE OF BODY DAMAGE FREE

Answer yes/no

PHOTO OF ALL REAR LIGHTS WORKING

photo (Camera and Gallery accesses or only Camera access can be set)

USE BAR TO TEST BRAKE LIGHTS

Answer yes/no

REAR DOORS

Answer yes/no

RUBBER SEALS

Answer yes/no

DOOR RETAINERS

Answer yes/no

BUFFER RUBBERS

Answer yes/no

BODY MARKER LIGHTS

Answer yes/no

INTERIOR BOX LIGHTS WORKING

Answer yes/no

INTERIOR SIDE RAILS

Answer yes/no

NEARSIDE REAR TYRES

Answer yes/no

NEARSIDE CRASH BARRIER

Answer yes/no

SIDE OF BODY DAMAGE FREE

photo (Camera and Gallery accesses or only Camera access can be set)

BATTERY BOX SECURE

Answer yes/no

N/S REAR TYRES

Answer yes/no

N/S FRONT TYRES

Answer yes/no

WHEEL NUTS TIGHT

Answer yes/no

WINDSCREEN

Answer yes/no

N/S MIRRORS

Answer yes/no

PLEASE TAKE A PICTURE OF THE MIRRORS

photo (Camera and Gallery accesses or only Camera access can be set)

OVERALL CLEANLINESS

Answer yes/no

Please confirm you have taken the required minimum of 11 minutes to complete this check?

Answer yes/no

####   **8.  Job Safety Site Plan** 

  

**Job Safety Site Plan (JSSP)**

***QUESTION***

***ANSWER TYPE***

Client name

Text

Location/site

Text

Date

Number

Has a CAT scan been carried out

Answer yes/no

WIPERS/WASHERS WORKING

Answer yes/no

HORN WORKING/NO SMOKING SIGN

Answer yes/no

FRIDGE TURNED ON AND WORKING

Answer yes/no

TAKE PHOTO OF REGISTRATION PLATE

photo (Camera and Gallery accesses or only Camera access can be set)

TAKE PHOTO OF ALL LIGHTS WORKING

photo (Camera and Gallery accesses or only Camera access can be set)

GVTA DISC ON DISPLAY

photo (Camera and Gallery accesses or only Camera access can be set)

MIRRORS

Answer yes/no

FRONT TYRES

Answer yes/no

WHEEL NUTS TIGHT

Answer yes/no

DRIVERS SIDE CRASH BARRIER

Answer yes/no

DIESEL TANKS /CAPS

Answer yes/no

REAR TYRES DRIVERS SIDE

Answer yes/no

SIDE OF BODY DAMAGE FREE

Answer yes/no

PHOTO OF ALL REAR LIGHTS WORKING

photo (Camera and Gallery accesses or only Camera access can be set)

USE BAR TO TEST BRAKE LIGHTS

Answer yes/no

REAR DOORS

Answer yes/no

RUBBER SEALS

Answer yes/no

DOOR RETAINERS

Answer yes/no

BUFFER RUBBERS

Answer yes/no

BODY MARKER LIGHTS

Answer yes/no

INTERIOR BOX LIGHTS WORKING

Answer yes/no

INTERIOR SIDE RAILS

Answer yes/no

NEARSIDE REAR TYRES

Answer yes/no

NEARSIDE CRASH BARRIER

Answer yes/no

SIDE OF BODY DAMAGE FREE

photo (Camera and Gallery accesses or only Camera access can be set)

BATTERY BOX SECURE

Answer yes/no

N/S REAR TYRES

Answer yes/no

N/S FRONT TYRES

Answer yes/no

WHEEL NUTS TIGHT

Answer yes/no

WINDSCREEN

Answer yes/no

N/S MIRRORS

Answer yes/no

PLEASE TAKE A PICTURE OF THE MIRRORS

photo (Camera and Gallery accesses or only Camera access can be set)

OVERALL CLEANLINESS

Answer yes/no

Please confirm you have taken the required minimum of 11 minutes to complete this check?

Answer yes/no

####  **9.  Accident Form** 

  

***QUESTION***

***PLACE***

***ANSWER TYPE***

Please enter Date and Time of Accident

1\. accident

text

Please enter exact Location of Accident

1\. accident

location

Please enter type of Road (Motorway, national road etc)

1\. accident

text

Please enter Weather Conditions (Wet/Dry/Frost)

1\. accident

combobox

Is company vehicle damaged press X to record damage.

3\. damage

option

Is third party vehicle damaged press X to record damage.

3\. damage

option

Is third Party property damaged press X to record damage.

3\. damage

option

Did Police attend the scene or was the incident reported to Police Station? Please enter Police officers name, number and station or Pulse ID number.

4\. garda

text

Please give description of accident, including any Third Party details.

2\. description

text

Please press camera to record image of front of form. Please send hard copy to Fleet Manager

6\. insurance

photo (Camera and Gallery accesses or only Camera access can be set)

Please press x to record image of rear of form. Please send hard copy to Fleet Manager

6\. insurance

option

Please press X to attach any other relevant information /Photos, accident site, position of vehicles, road conditions, third party Insurance Disc etc.

5\. other

option

####   **10.  Driver Declaration** 

***QUESTION***

***ANSWER TYPE***

Have you incurred ANY Penalty Points on your Licence? If yes, please give details (including quantity and whether these are still active)

text

additional text in question

Have you had any accidents, claims or convictions in the last five years? If yes, please give details

text

add in (Including quantity)

Attach a copy of my Drivers Licence (back & front). Press (X) or Swipe left to attach licence

option

need photo of license

Have any insurers ever refused or cancelled or declined to renew your personal motor insurance or imposed special terms? If yes, please give details:

text

 

I confirm I will notify the office as soon as I become aware of incurring Penalty Points, accidents, claims or convictions:

text

 

Date of Birth:

text

 

Do you suffer from any illness that may affect your ability to drive? i.e.Epilepsy, Sleep apnoea, diabetes, asthma, high blood pressure, defective vision or hearing etc. If Yes, please give details

text

 

Have you been convicted of a felony in the last 36 months?

text

extra question to be added

Have you been convicted of sale, handling or use of drugs in the last 36 months?

text

extra question to be added

Have you been convicted on an alcohol or drug-related offense while driving?

text

extra question to be added

Have you ever had your driver's license suspended or revoked?

text

extra question to be added

I confirm that the Category of License which I hold is valid and suitable for the type of vehicle which I will be driving.

text

 

I confirm that I am responsible for any citations, fines or charges issued against me on or by a court of law as a result of driving violations while operating a Company vehicle, regardless of whether incurred on or off duty

text

 

####  **11.  Site Inspection** 

  

***QUESTION***

***ANSWER TYPE***

Emplacement

location

Photo

option

####  **12.  CarVanJeep** 

***QUESTION*** 

***ANSWER TYPE***

No internal vehicle issues

option

No external vehicle issues

option

Enter number of passengers

text
