# What's New?

Back to home

1.  Knowledge Base 
3.  Whats New? 

-   Logging-in to your Transpoco account
    -   Login to your Transpoco account
    -   Transpoco Smartphone Apps
    -   2 Factor Authentication
    -   System requirements
    -   Overview of Transpoco
    -   Implementation
-   How to organise your account to achieve the best results
    
-   How to use each feature - step by step guides
    -   Users and permissions
    -   Walkaround Checks module
    -   Fuel/Electric Vehicles Module
    -   Maintain Module
    -   Dashboard
    -   Messaging module
    -   Scheduled Reports
-   How to Order More Trackers
    
-   Live Map
    
-   Cameras
    -   FAQ
-   Webinar Videos
    
-   Walkaround Checklists
    -   Walkaround Checklists
    -   Driver App
    -   Alerts
-   Reports
    -   Reports
    -   Viewing data in reports
-   Fuel
    
-   Dashboard
    
-   Maintain Module
    
-   Driving Style
    
-   Locations
    
-   Cost Management (TCO) Report
    
-   The Notification Features
    
-   Hardware and Installation
    
-   Removal & Repair of Hardware
    -   Requesting a Repair or a Deinstallation
-   Cameras & GDPR Guidelines
    
-   Scheduled Reports
    
-   Safety Program
    
-   Fleet Manager App
    
-   Users & Permissions
    
-   Alerts
    
-   Policies & Documents
    
-   Privacy Policy and Terms & Conditions
    -   RoPA
-   API
    
-   Transpoco User Manuals
    
-   Settings
    -   Garage
-   Whats New?
    
-   Account Mangement Services
    
-   Driver ID process
    
-   Security
    
-   Transpoco Locate
    
-   Subscriptions & Invoices
    
-   Tutorial videos
    
-   Cancelling your account
    
-   VOR
    
-   Installation
    
-   BIKLY
    

# What's New?

## Transpoco's Product Updates

### September 2025

#### 1) Walkaround new icon for untracked vehicles

You can easily identify untracked vehicles  in the Walkaround Weekly View now. 

#### 2) Service Types option added to the Services Scheduled Report

Once you pick the "Services" report to be sent via Scheduled Report, you can now filter it by the Service Types from your account and also combine this filter with the Service Status if you wish.

### August 2025

#### 1) A new column was added to the Cameras' Page: "Date Video Ready"

This new column will show at what time the video was downloaded to the platform.

#### 2) The Shift Times were added as an option to filter the "Total Time Driving" in the Dashboard.

With this new Shift Time option, the user can filter the total time driving by working hours / outside working hours for example. 

**Note:** All your custom shift times will be displayed as an option in this filter.

#### 3) For our self install OBD devices we have added an new option to alert when a tracking device is unplugged.

You can set an alert to know if a tracking device has been unplugged.

**Note:** This is working for self install OBD devices (Teltonika) only.

### July 2025

#### 1) Introduction of time range segments to help with manual requests of videos from cameras

In the Camera module we made a change to improve the user experience of manually requesting video from a camera. On each date, we will show the periods of time the camera recorded video (these segments are equivalent to the journeys we recorded on the date). The intention is to prevent users from making requests for video while the camera was not recording (the camera only records video while the ignition of the vehicle is turned on). We will also indicate the earliest available date for video. See the example below:

#### 2) Transactions Auto Assign to Vehicles Using EV Charging Data

EV Transactions are using EV Charging Data to auto-assign transactions to vehicles.

Three Rules are considered:

1)  We are considering electric vehicles which are in the geofence and have "battery level" information;

2) If there is no "battery level" information, and there is only one electric vehicle in the geofence, we do the matching.

3) If there is no "battery level" information, and there is more than one electric vehicle in the geofence, we CAN'T DO the matching.

#### 3) Export the Carbon Footprint Report

We've added a new option to export the Carbon Footprint report in PDF / CSV.  
You can now generate and download the data directly from the report view.

image-08-08-2025\_09\_29\_AM

#### 4) Possible to edit cost fields in a service ticket after completion

In the Maintain module, it’s now possible to edit the Cost, Currency, and Cost Centre fields even after a service has been completed.  
Previously, these fields were locked once the service was completed.

### June 2025

#### 1) Fuel Transactions – New Right-Click Filter and Column Resize

A sub-menu option has been added to the Fuel Transactions page to allow filtering based on the data selected with the right mouse click.

Screenshot 2025-06-13 at 09.11.57 (1)

You can now also resize the width of each column like a column in a spreadsheet.

### image-06-27-2025\_10\_01\_AM

#### 2) Select a custom period in the Carbon Footprint Calculations report

This month we provided the functionality to select a custom time period for the Carbon Footprint Calculations report.

Firefox\_Screenshot\_2025-05-29T17-04-36.365Z (1)

### Firefox\_Screenshot\_2025-05-29T17-05-14.285Z

#### 3) Improvement to the Driver App

This update includes usability improvements, allowing you to view the status of the walkaround checklist (failed / pending / submitted) and the Vehicle Reg + Description is shown alongside each record, just like in the Web account.

The screens updated with these changes are:

-   **View Driver History**
    
-   **View Vehicle History**
    

Untitled-document-Google-Docs-06-24-2025\_09\_05\_AM

#### 4) Camera health check events now appear in Notifications

Events regarding the status and performance of cameras have been moved to the Notifications section.

The 6 camera health checks are:

1.  Video Loss
2.  Illegal Shutdown
3.  Memory exception alarm/Abnormal alarm
4.  Abnormal storage boot
5.  Camera down

We explain the meaning of each camera health check in the **Notification Event Types** article, click **here** to find the definitions.

### May 2025

#### 1) Services added to the Audit Logs

image-05-28-2025\_11\_46\_AM

The Audit Logs provides a history of changes to sections of your Transoco account. In May 2025 we added the changes to services in the Maintain module. You can now view the details of updates, deletions and the creation of new services. We will display the name of the user who made each change.

To find the audit logs to **Settings menu > Company Details > Audit Logs**

Access to the Audit Log and the Settings menu depends on the permissions assigned to you.

#### 2) No Driver Detected and Video Loss alerts pushed to the Notifications section

### Notifications-05-28-2025\_02\_40\_PM-05-28-2025\_02\_41\_PM

This change applies to customers using cameras from Transpoco. The alerts for No Driver Detected and Video Loss have been moved to the Notifications section in your Transpoco account.

Click **here** to learn more about the Notifications section and the different types of notifications we provide.

#### 3) Fuel Transaction Odometer made editable

image-05-28-2025\_02\_59\_PM

Customers who use the Fuel module now have the option to edit the odometer value in a fuel transaction. If odometer in your Transpoco account at the time of the transaction is not accurate you can use the mileage provided by the driver at the time of the purchase if the mileage seems accurate. 

#### 4) AG Grid applied to the Fuel Transactions page

### Fuel-Control-05-29-2025\_12\_26\_PM

This month we made another improvement to the Fuel Transactions page in the Fuel module. We implemented a new AG Grid layout. Over time, we will add this layout to reports in Transpoco. The layout offers alot more functionalities similar to a spreadsheet. We created **this video** to demonstrate the functionalities of the AG Grid layout in the Fuel Transactions page.

### April 2025

#### 1) Driven Without Check report filtered by driver 

The Driven Without Check report in the Walkaround module can now by filtered by driver. This report will show the number of days without submitting a checklist during the selected time period. 

### Walkaround-04-16-2025\_02\_19\_PM

Click here to view a video demonstration of the Driven Without Check report

### March 2025

#### 1) Vehicles List with the Edition Option

The vehicles list option was added to the Fleet Manager App with the option to edit each vehicle. When ckicked to edit a vehicle the user sees each property of the selected vehicle as it is in your Web platform.

### vehicles-table

### February 2025

#### 1) Ireland Speed Limits Update

We've updated road speed limits to reflect the change from 80km to 60km on rural roads in Ireland.

message

**Note:** For more details, please check here.

#### 2) Improved permissions available for the User Management

A new section has been added to **Move/Profiles** to help customers manager better users.

-   These changes **only apply to new profile**

**user-management**

-   Existing profiles have been updated as follows:
    -   Users with access to **Settings and Users** can create, update, view, and delete users.
    -   Users with access to **Settings but not Users** can only view users.

table

-   -   If **User/View** is disabled, users can only see their own user.

table

#### 3) Fuel Module Access Permissions

Users who do not have access to all vehicles and drivers in their Transpoco account will no longer be able to view the Fuel Transactions report. Instead, they will see a notification message. This change ensures that users can only access data for the vehicles assigned to them, preventing any potential data breaches. However, all other Fuel module features, including the EV Suitability report and Fuel Consumption reports, remain available. 

**Note:** This change does not affect administrators who have access to view all vehicles and all drivers in their account.

message

#### 4) New Self-Install Driver ID Device Added

The **Netronix NBL-2 Reader** is now part of the product range, allowing for **self-install driver ID**.

-   Powered by **two AAA batteries**, lasting up to **two years**.
-   Emits a **beep every 60 seconds** if no RFID is presented.

More details: Netronix NBL-2 Reader  
Watch the video: Installation Guide

remote

#### 5) AI Support Chatbot

Our latest AI-powered support chatbot is now available. It will appear in the bottom left or right corner of the screen, ready to answer questions by automatically searching our knowledge base for the most relevant information. 

**Note:** The chatbot is available 24/7. An agent will help if the chatbot cannot provide a satisfactory answer. However, agents will only be available during office hours.

### arrow-down

### chat

### January 2025

#### 1) Integration with Texaco Fastfuel fuel card accounts

You can now integrate a fuel card account from Texaco Fastfuel with your Transpoco account. If you want to integrate your Texaco Fastfuel account contact the team in Transpoco at support@transpoco.com to start the process.

image-01-30-2025\_03\_51\_PM

### December 2024

#### 1) New layout to the Camera module 

We created this video to demonstrates the new layout of the Camera module and the additional functionalities we have added.

#### 2) Check the end time of an EV charge from Glen EV

Displaying

Transpoco now supports saving the end time of an EV charge by integrating with the GlenEV API. This enhancement ensures that the start and end times of EV charges are accurately recorded, using data from the EV report rather than raw CANBus data for improved reliability.

### October 2024

#### 1) Link to a list with examples of AI alerts

We added a link to the *List of events automatically recorded by AI cameras.*

*dashbpard*

#### 2) Walkaround module menu update

The "Weekly View" and "List of Checks" tabs were moved to the side menu.

weekly-report

#### 3) New "Driven Without Check" report

The "Driven without check" report lists the vehicles which were driven without check in a period of time selected, checklist, vehicle group and/or even the number of days these vehicles driven without check.

drive-img

### August and September 2024

#### 1) New Terms and Conditions (Personal And Business)

We’ve updated our Terms and Conditions for both Personal and Business customers. These new terms are live in our system now. Please take a moment to review the updated Terms and Conditions. 

#### 2) Canbus reports available: Fuel Used and Plant Utilisation

The "Canbus Fuel Used" report shows the fuel used in the selected period and the "Canbus Plant Utilisation" report shows mainly the working and idling times (the utilisation) of your plant machines.

Note: These reports use the Canbus data collected directly from your vehicles. 

dashboard

table-list

#### 3) Canbus battery level and charge state displayed where detected.

For electricity purchases, the system displays available CANbus data, including battery level and charge state, where detected.

Note:  This is exclusive to CANbus installed electric vehicles.

map

### July 2024

#### 1) More options added to the Fleet Manager app for user preferences

We added these user preferences to the Fleet Manager app. You can also find them in your Transpoco Move account, except for the currency.

-   Timezone Selection
-   Distance Unit Options
-   Vehicle Sorting Preferences
-   Currency

language

#### 2) New airports icons (GPU and Transfer)

We added these 2 icon options to Move (Live Map and Vehicle Details) and to the Fleet Manager app (Live Map) .

house

map-detail

#### 3) Sulfer Free Gas Oil (SFGO) added to the Carbon Footprint Calculations report

We added the Sulfer Free Gas Oil (SFGO) to the Carbon Footprint Calculations report. The SFGO and Diesel have the same carbon emission calculations as per the SEAI guideline.

graph

### June 2024

#### 1) Fuel Consumption Helper

We added a helper text box on the "Fuel Consumption" page explaining how fuel consumption is calculated, also with a link to the knowledge base.

list

calculated

### May 2024

#### 1) Fuel Consumption Report - Units as New Columns

The fuel consumption report now includes unit columns, making it easier to see the total electricity and petrol/diesel usage at a glance.

listing

#### 2) New attribute in the vehicle edition (Timezone) 

We implemented a new vehicle attribute to handle "Driven Without Check" walkaround alert.  Now, customers can manually set each vehicle to a specific company-approved time zone. By default, all vehicles still use UTC.

selects

### March 2024

#### 1) The Hydrotreated Vegetable Oil (HVO) is displayed as a new column in the Carbon Footprint report.

If you are purchasing HVO fuel type you are able to see the quantity bought through your Carbon Footprint report over a period of your choice.

graph

#### 2) Notification of a new app version

When a user is using an old version of the app, the app will pop up a notification saying there is a new app version available.

location

### February 2024

#### 1) Auto updating the odometer for a vehicle in your account using the odometer submitted in a walkaround checklist through our Driver app.

If your walkaround checklist includes a check requesting the driver to enter the odometer of the vehicle he is checking, we will use the odometer entered by the driver to update the odometer for the vehicle in your Transpoco account. This process will occur each time a checklist is submitted and will ensure the odometer in your account is close to the actual odometer of the vehicle.

We will only correct the odometer for a vehicle if the odometer provided by the driver is within a range of +/-10% of the odometer in your Transpoco account so we can avoid mistakes

**Note:** If you integrate your fuel card account with your Transpoco account we will also use the mileage declared by the driver for a fuel transaction to correct the odometer of the vehicle in your account. The same rule applies, we will only correct the odometer if the odometer entered by the driver is within a range of 10% of the odometer in your Transpoco account.

IMG\_2498 (1)

image-20240209-150314 (1)-1

### January 2024

#### 1) We introduced social login as a login option

If your Transpoco account is linked to an email address from Google, Microsoft or Apple you can now login to your account using the new social logins.

Transpoco-Login

#### 2) Split tracked vehicles and untracked vehicles in the Vehicles page in Settings

Up to now tracked vehicles and untracked vehicles were listed in the same page in the Vehicles page in Settings. We have now split tracked vehicles and untracked vehicles.

Untracked vehicles are useful if you do not want us to track a vehicle but you want the driver to submit walkaround checklist for a vehicle or you want to create services for a vehicle. 

Firefox\_Screenshot\_2024-01-09T18-41-13-008Z

To find this page go to the **Settings menu** and under **Garage** select **Vehicles**.

### 3) Improvement to the Audit log to log changes to user profiles

The audit log currently displays a record of changes in your Transpoco account and we will now show changes to user profiles.

Firefox\_Screenshot\_2024-01-09T18-30-10.442Z

To find the Audit log go to **Settings menu** and under **Company Details** select **Audit Logs**

For more details you can read this article.

### March, April and May 2023

#### 1) The **"Completion" and "Received" time columns added to the Walkaround List of Checks**

**Package: Move + / Perform / Protect**

The "Completion time" is the time which the checklist was completed in the app. The "Received time" is the time which the checklist was submitted to the web and you can see it in the Transpoco system. 

Note: The difference in these times might happen usually when the checklist is submitted to the web some time after completion and not straight away. e.g.: when the user is doing the checklist in the offline mode and submits the checklist only when internet access is available.

### list-checking

For more details, you can read this article.

#### 2) **Option to filter events out of the Stops/Idling report in the Scheduled Report module**

**Package: Move / Perform / Protect**

There is a new option available where the user can filter stops/idling out of the report. e.g.: The user can select to have only events greated or equal to 15 minutes for instance. This means all stop/idling events less than 15 minutes will be ignored and not displayed in the report. 

image-png-may

For more details, you can read this article.

#### 3) **Speed Summary Details available in the Scheduled Report module**

**Package: Move / Perform / Protect**

You are able to see the details of your drivers' speeding like where these events are mostly happening, speed limit, speed over the limit, percentage over the limit, etc.

report

table-list

For more details, you can read this article.

#### 4) Transpoco's New Privacy Policy

We have a new privacy policy available and it is intended for personal users and web visitors. While using your Transpoco account you will be prompted to accept the new privacy policy in a pop-up window - see the example below.

image (38)

For more details, you can read this article.

### December 2022, January and February 2023

#### 1) **WA Alert to Drivers who drove without a check being done**

**Package: Move + / Perform / Protect**

When creating / editing an alert for 'Driving Without Check', if you want your drivers to receive these email alerts as well, please check the highlighted box below.

**Note 1:** If it's an unknown driver, no driver will receive the alert. If the user who was set to receive the alert doesn't have access to the driver, the driver's name will be displayed as 'no access to driver's data'. But the driver will still receive the alert by email.

**Note 2:** Each driver will have access only to their own alert.

alert date

For more details, you can read this article.

#### 2) Alert when there is a Driver Id being used but not assigned to a driver or assigned to a driver of another company (when a customer has  2 or more Transpoco accounts)

**Package: Move + / Perform / Protect**

There is a new alert category which is the 'Driver'. There are 2 event types related to Drivers: 'Driver Id not assigned' and 'non company driver Id used'.

The 'Driver Id not assigned' is to inform the user of a Driver Id being used without being assigned to a driver. This means the system won't be able to identify the driver in the reports. Once the Driver Id is assigned to a driver the notification is automatically closed.

The 'non company Driver Id used' is to notify the user of a Driver Id being used but assigned to a driver of another Transpoco account. This only applies for customers who have 2 or more Transpoco accounts.

list

For more details, you can read this article.

#### 3) Cameras events/alerts into the Driving Summary Score

**Package:  Protect**

If you have our cameras installed, you can enable the camera events/alerts to be part of the Driving Score calculation. This will impact the drivers ranking directly. 

**Note 1:** To enable the camera events/alerts to be part of the Driving Score calculation, you can go to the Settings page into the Driving Style module. Please see the image below.

**Note 2:** If cameras' data is enabled in the Settings, the Driver App will also display camera events/alerts for each individual driver. 

Hubspot-Feb-17-2023-04-47-18-8359-PM

image-png-Feb-17-2023-05-03-16-9177-PM

Hubspot-Feb-24-2023-05-13-30-7377-PM

For more details, you can read this article.

#### 4) Driver Mileage Summary report added to the Driver App 

**Package:  Perform / Protect**

Your drivers will also have access to their own driver mileage data which means they are able to check their mileage done in business and private mode.

Hubspot-Mar-16-2023-04-54-36-2816-PM

For more details, you can read this article.

#### 5) Alerts added to the Audit Logs section in the system

**Package: Perform / Protect**

We have one more entity from the system added to the Audit Logs where you can see when, who and what changes were done in an alert from the system.

Hubspot-Mar-16-2023-05-02-04-3006-PM

For more details, you can read this article.

### November 2022

#### 1) Filter on journeys in the Percentage Of  Journeys with Driver ID Used metric in the Dashboard

**Package: Move + / Perform / Protect**

When creating / editing the 'Percentage of Journeys Driver ID Used' metric in the Dashboard, you can filter out small journeys eg. exclude journeys without Driver ID with less than 2km driven. This will help customers with the compliance percentage as most of these small journeys are done in a garage.

dec-08-2022

#### 2) WA List of Checks export in a new format

**Package: Move + / Perform / Protect**

When exporting the list of checks you can either select a CVS or Excel option. Both of them are downloaded in a new format where the questions are the titles of the columns in the file and each checklist submitted will be one line of this CSV / Excel. This helps customers to run different filters on the data.

dec-08-2022

**Note:** If in CSV format, each checklist will be exported into a different file. This is the reason your dowload will be ziped.

If in Excel format, different checklists will be exported into different tabs.

#### 3) Request a fuel station update when no station is found

**Package: Move + / Perform / Protect**

When there is a 'No Station Found' in your fuel transactions report, you can click on the yellow button and then request a fuel station update. An email will be sent to Transpoco Support Team, we will fix the station and get back to you as soon as possible.

dec-08-2022

dec-08-2022

### October 2022

#### 1) Defects reported by drivers through the Driver App can be automatically created into the Maintenance section 

**Package: Move + / Perform / Protect**

If you enable this feature in the Walkaround Settings section, you will have all the defects reported by the drivers automatically created in the Maintenance module. You can also set a default Garage for these services automatically created. 

nov-04-2022

#### 2) The metrics 'Total Checks Done' and 'Total Defects Reported' are available in the Dashboard

**Package: Move + / Perform / Protect**

The 'Total Checks Done' metric will show the number of checklists submitted by drivers in the period selected. The 'Total Defects Reported' will show the number of defects reported by drivers in the period selected.

nov-09-2022

#### 3) The driver's name (if any) will be shown in the Walkaround alert for vehicles driven without a check being completed 

**Package: Move + / Perform / Protect**

If the vehicle is assigned to a driver or the driver used a driver identification, this walkaround alert will show the driver's name with the vehicle registration.

nov-09-2022

#### 4) Alerts are automatically applied to vehicles based on the vehicle groups they are in.

**Package: Move / Perform / Protect**

When you set an alert to a specific vehicle group, all vehicles added to this group will be automatically assigned to this alert. The same happens if you take a vehicle out of the group. In this case, the vehicle will be unassigned from the alert.

nov-04-2022

### September 2022

#### 1) The Driving Summary can be set as a Scheduled Report now.

**Package: Move / Perform / Protect**

The Driving Summary report which shows Driver Performances can be sent to users when set as a scheduled report. It can be sent on a daily, weekly or monthly basis.

oct-12-2022oct-12-2022

For more details, you can read this article.

#### 2) Audit Logs enabled to all Default Admin users 

**Package: Move / Perform / Protect**

The objective of the audit logs is to log and display changes done in the system. Example: If a new scheduled report is created in the system, this section will show what scheduled report was created, when and who created it. If there are any changes in future, the edition will also be logged and displayed in the Audit Logs section.

You can use the filters provided like period, etc. And also click on the eye icon for more details.

oct-12-2022

For more details, you can read this article.

#### 3) Fuel Purchase Report direct link to the Fuel Transactions Report

**Package: Move + / Perform / Protect**

If you click on the purchase quantity in the Fuel Purchase Report, there is a link direct to the Fuel Transactions Report in order to show you the transactions taken into account for this quantity. 

oct-12-2022oct-12-2022

For more details, you can read this article.

#### 4) 'Vehicle Groups' column added to the 'Users' list

**Package: Locate / Move / Perform / Protect**

The vehicle groups column was added to the list of users so you can see at a glance the vehicle groups which each user has access to.

oct-12-2022

For more details, you can read this article.

### August 2022

#### 1) Fuel Purchase Summary Report

**Package: Move + / Perform / Protect**

The objective of this report is to show all the purchases made and distance driven by vehicle for the period selected. You can also export it as usual. In this report you will see the **all the purchases from the period selected,** not the consumption.

sep-09-2022

For more details, you can read this article.

#### 2) Have all fuel transactions from a card assigned to a specific vehicle

**Package: Move + / Perform / Protect**

If you have non-tracked vehicles and/or want to desconsider GPS checking for your purchases, you can assign a vehicle to a fuel card and/or add a registration to a card description to match with the vehicle declared at the till by the driver. It means that all transactions from the card will be automatically assigned to the vehicle related.

sep-09-2022

For more details, you can read this article.

### July 2022

#### 1) Driver Mileage Summary Report

**Package: Move / Perform / Protect**

The objective of the Driver Mileage Report is to summarize the distances driven in **business** and **private** mode. The report can be exported and also filtered by a selected time period, vehicle group, vehicle, driver group and driver.

Note: For journeys with no driver ID identified, the report will group them as "Unknown Driver". In case the system has a fob used during journey but this fob wasn't assigned to a driver, the report will show the ID number next to "Unknown Driver".

aug-05-2022

For more details, you can read this article.

#### 2) Electric Vehicle (EV) Suitability Report Customisation

**Package: Perform / Protect**

You can customise the range brackets for the EV Suitability Report and also set the limit for the "% days below / above X km when driven" in **Settings -** see the example below. 

Note 1: Any change you make will only change the EV Suitability Report in your profile, not for other users. 

Note 2: You can also attribute different colours to the ranges in order to help you with the data analysis at a glance.

aug-09-2022

For more details, you can read this article.

#### 3) Driver Group filter for the ranking position in the Driver App

**Package: Perform / Protect**

The objective of this Driver Group filter option added to the Ranking is to help the drivers with a more relevant ranking position compared to the other drivers from the same group. e.g.: If there are 200 or 300 drivers in a fleet the rank becomes irrelevant. To solve this problem, the driver can search for his rank in one or more Driver Groups. 

Note: The setting of the driver groups which should be displayed per driver needs to be done in the Driver section when registering / editing a driver. You can then give them the proper permissions.

aug-05-2022

For more details, you can read this article.

#### 4) Protection against brute-force attacks that target a single user account.

**Package: Locate / Move / Perform / Protect**

If a user enters their password incorrectly 10 or more times they will receive an email like the one below requesting them to Unblock their account. The following steps are followed:

• Lock the account temporarily if there are a number of consecutive failed  

logins on an account (e.g, 10) 

• Send an email to the registered owner of the account indicating that the  

account has been locked out due to the multiple failed login attempts. 

• Present a generic error to the user.

aug-05-2022

For more details, you can read this article.

#### 5) Internet Explorer 11 will end in August 2022

**Package: Locate / Move / Perform / Protect**

The IE11 browser will not be supported after August 2022 which means you won't be able to access your Transpoco account via IE11 after August 2022. All other browsers will keep working as usual. e.g.: Chrome, Microsoft Edge, Firefox, etc.

jan-31-2022

### May and June 2022

#### 1) Transpoco hosted a free **webinar** explaining how your fleet can transition to **electric vehicles**. The main topics are listed below:

-   How our new EV Suitability report can help you to identify vehicles which can be replaced by EV vehicles.
-   How to monitor EV charging data using our new EV Charging report.
-   Learn from our experiences helping private and public sectors fleets to transition to EV fleets.

Note: If you were not able to attend the webinar, you can watch it here at your convenience.

#### 2) The Multifactor Authentication option is available to be enabled 

**Package: Move / Perform / Protect**

Only users with Administrator privilege have access to the Security section. In this section, you will find the multi-factor authentication option which can be enabled to all your users, including you, except user logins to the Driver App. Once this is enabled, a second factor will be required to login to the system which means users will be required a 6 digit code after entering username and password. 

jun-09-2022

For more details, you can read this article.

#### 3) The vehicle distance driven was added to the Driving Summary report and export.

**Package: Move / Perform / Protect**

When running an analysis over the Driving Summary data, you can not only see the tracker alert events but also the distance driven.

jun-09-2022

For more details, you can read this article.

#### 4) A checklist filter was added to the Walkaround reports

**Package: Move + / Perform / Protect**

You can filter your "weekly view" report and/or "list of checks" report by one of the checklists you are using at a time. This will help you to see at a glance which vehicles have a specific check done during the week selected.

jun-09-2022

For more details, you can read this article.

### April 2022

#### 1) Electric Vehicle Suitability Report

**Package: Move + / Perform / Protect**

The objective of this EV Suitability Report is to assist you on choosing vehicles to be changed to electric.

Note: At the moment, the distance ranges and the 150 km are fixed in the system, but they will be able to be customised soon.

may-10-2022

For more details, you can read this article.

#### 2) Pre-set Profile Options Available

**Package: Move / Perform / Protect**

The system provides 4 different default profiles which are: 

\* Admin - With access to the whole system based on the package chosen;

\* Standard Viewer - Won't have access to the Settings menu option;

\* Email Only - Won't have access to the system but it can be set as a recipient for alerts and scheduled reports.

\* Custom -  Customised access 

may-05-2022

For more details, you can read this article.

#### 3) Internet Explorer 11 will end in August 2022

**Package: Locate / Move / Perform / Protect**

The IE11 browser won't be supported anymore after August 2022 which means you won't be able to access your Transpoco account via IE11 after August 2022. All the other browsers will keep working as usual. e.g.: Chrome, Microsoft Edge, Firefox, etc.

jan-31-2022

### March 2022

#### 1) Block speeding alerts in specific locations

**Package: Move / Perform / Protect**

You can create custom locations where you don't want to receive speeding alerts when above the speed limit. This will be automatically applied to all your vehicles. e.g: toll locations

apr-08-2022

apr-08-2022

For more details, you can read this article.

#### 2) Electric Vehicle Report

**Package: Move + / Perform / Protect**

With this report you will be able to check all your charging details like battery level, distance travelled, KHW charged, location, etc.

apr-08-2022

For more details, you can read this article.

#### 3) Natural Gas and Electricity Carbon Footprint added to the Carbon Footprint Calculations Report

**Package: Move + / Perform / Protect**

You can not only see the total carbon footprint purchased in your account per period but also by product type like Diesel, Petrol, Natural Gas and Electricity.

apr-11-2022

### February 2022

#### 1) Apply different shift times to some of your Scheduled Reports

**Package: Move / Perform / Protect**

You can apply customised shift times to the following reports in the Scheduled Report section: Fleet Summary, Summary, Journeys, Idling, Idling/Stops and/or Stops.

mar-04-2022

For more details, you can read this article.

#### 2) Create customised checklists for your drivers.

**Package: Move + / Perform / Protect**

You can create customised checklists using our checklist builder. You can also hide/unhide a checklist for your drivers into the Driver App.

mar-07-2022

For more details, you can read this article.

#### 3) New filter available for the Fuel Transactions Scheduled Report (Fuel Type Match)

**Package: Move + / Perform / Protect**

This filter permits you to have a report on transactions which don't match the vehicle fuel type with the purchase product. e.g.: If the vehicle fuel type is petrol and the purchase product is diesel, this report can display only these unmatches when selected the option "No".

mar-07-2022

For more details, you can read this article.

#### 4) Hours driven / Operating hours added to the Service creation

**Package: Move + / Perform / Protect**

If the option "Travel Time" is selected, the vehicle hours driven (opering hours) will be displayed to help you with this alert setup.

mar-07-2022

For more details, you can read this article.

### December 2021 and January 2022

#### 1) Notifications report can be sent by email via the Scheduled Report function

**Package: Move / Perform / Protect**

You can receive the Notifications report by email when setting a Schedule Report for it.

jan-12-2022

jan-12-2022

For more details, you can read this article.

#### 2) Filters added to the Fuel Transaction report

**Package: Move + / Perform / Protect**

You can filter your fuel transactions report by vehicle groups or vehicles.

jan-12-2022

For more details, you can read this article.

#### 3) Changes done in the Data Processing Terms

**Package: Locate / Move / Perform / Protect**

The links to the Transpoco's Record of Processing Activities (ROPA) and our GDPR page were added as part of these Terms.

jan-26-2022

For more details, you can read this

#### 4) Internet Explorer 11 will end in August 2022

**Package: Locate / Move / Perform / Protect**

The IE11 browser won't be supported anymore after August 2022 which means you won't be able to access your Transpoco account via IE11 after August 2022. All the other browsers will keep working as usual. e.g.: Chrome, Microsoft Edge, Firefox, etc.

jan-31-2022

### November 2021

#### 1) The Speed Summary report from the Driving Style Module had the locations added to the CSV files when exporting it

**Package: Move / Perform / Protect**

Now you can see the locations on the downloaded Speed Summary reports.

dec-08-2022

For more details, you can read this article.

#### 2) Edit the Checklists' title, hide, unhide, and delete them

**Package: Move+ / Perform / Protect**

You can edit a checklist title, hide, unhide, and delete them in order to have a better management.

dec-08-2022

For more details, you can read this article.

#### 3) New dashboard metric: Carbon Footprint

**Package: Move+ / Perform / Protect**

The Carbon emission can be added to your Dashboard as a new widget. All the default filter options are available in this metric. 

dec-08-2022

For more details, you can read this article.

### October 2021

#### 1) A new way to create vehicle groups

**Package: Move / Perform / Protect**

You can create a vehicle group in an easiest way, filtering vehicles using any column present on the list. You can also select all at once and create vehicle groups faster than before.

### nov-08-2022

For more details please read this article.

### 2) New fuel provider: Jigsaw

**Package: Move + / Perform / Protect**

You can request Transpoco to automatically import purchases from Jigsaw provider, helping you to manage your fleet fuel consumption more accurately.

nov-08-2021

For more details please read this article.

### 3) Improving the knowledge base

**Package: Move + / Perform / Protect**

We added a link to the fuel page to redirect you to our knowledge base where you will find all the steps to get the most out of the Fuel product.

nov-08-2021

For more details please read this article.

### September 2021

#### 1) The total number of vehicles was added beside each vehicle group name in the dashboard.

**Package: Move + / Perform / Protect**

You can view the total number of vehicles between brackets beside each vehicle group name when choosing vehicle groups for the metrics in the dashboard, and also view the total number of vehicle groups selected on the top right of each widget.

oct-08-2021                           

oct-08-2021

For more details please read this article.

#### 2) A new type of Scheduled Report was added to your Synx: Walkaround Defects report. 

**Package: Move + / Perform / Protect**

You can generate a schedule report for the Walkaround defects reported by your drivers.

oct-08-2021          oct-08-2021

For more details please read this article.

#### 3) Driver's contact number added to alerts where drivers are identified.

**Package: Move + / Perform / Protect**

If the driver is identified in the alert and the contact number is properly set in the system, the alert will bring both information in the email. Please check the example below:

oct-13-2021

For more details please read this article.

### July & August 2021

#### 1) Additional column options that can be added to Fleet Summary Export

**Package: Locate / Move / Perform / Protect**

You can add additional columns to your Fleet Summary Export by running the report for the desired time period and clicking the icon to export the data from the report. You will then see a popup like the one below:

sep-01-2021

For more details please read this article.

#### 2) Different filters you can apply to your Summary Scheduled Report data.

**Package: Move / Perform / Protect**

You can apply various filters to your Summary Scheduled Report data. The available filters are based on the columns of the original report. You can choose between 3 standard operators: "equal to", "greater than" and "less than". The unit of the value depends on the selected parameter. E.g.: Drive Distance > 100 km per day or Drive Duration < 10 hours per day.

sep-01-2021

For more details please read this article.

### June 2021

#### 1) You can check the total cost of your fuel transactions, filtering by product or any other purchase detail.

**Package: Perform**

In the example below, it's filtered by Diesel UK product and you can see not only the total price per transaction but also the sum of the costs at the bottom.

jul-07-2021

For more details please read this article.

#### 2) Services Scheduled Report (filtered by status: all, pending, overdue, complete)

The Services report is related to the services created in the Maintenance module.

Note: When selecting the ‘Services’ as your chosen Report Type, the Vehicle and Driver filters are not applied on this type of report.

jul-15-2021

You can select the Service Status as a filter to your report (All Status, Complete, Pending or Overdue).

googleusercon

For more details please read this article.

#### 3) Flag multiple transactions done in the same day

If you have a card which was used to purchase fuel twice or more in a day, the system will flag this to you in the Fuel Transactions report.

jul-15-2021

For more details please read this article.

#### 4) Switch to an Electric Vehicle Fleet with Transpoco solutions

Companies operating vehicle fleets are increasingly accepting the need to meet their responsibility to contribute to the Net Zero 2050 emissions targets within their local economies by replacing some or all of their current fleets with Electric Vehicles (EVs).

**How can we help?**

In addition to selecting the right type of vehicle, Fleet Managers faces the challenge of obtaining the necessary information on current fleet activity, deciding which types of vehicles are best suited for replacement with EVs, and once an EV has been selected, extracting the data that will enable effective monitoring of vehicle and driver performance.

Transpoco, has identified three key areas where our solutions can facilitate the transition to EVs:

1\. Which vehicles should be transitioned to EV?

A suitability check for switching to an EV can be carried out, which includes information such as current driving profiles, vehicle dwell time and driver behavior data.

2\. EV range anxiety and charging management

Ability to extract data showing vehicle battery level and charging performance, data to mitigate vehicle range anxiety and a Fleet Manager's overview of fleet vehicle performance. These are key differences in managing an EV fleet versus non-EV vehicles.

3\. Providing data on ongoing improvements in carbon footprint reduction

Monitoring the effectiveness of the EV fleet using specific energy management reporting indicators, such as battery level, is essential for providing data on vehicle efficiency, operating costs, maintenance and lifecycle.

For more detail please contact us at sales@transpoco.com

### May 2021

#### 1) You can add extra columns with vehicles information to the Fleet Summary Schedule Report in your account

**Package: Move / Perform**

The new option “Extra Columns (Fleet Summary Report)” will appear at the bottom of the Scheduled Report creation screen. Then you can add extra columns wiith Vehicles information to your scheduled report. 

googleuser

For more details please read this article.

#### 2) Driving Summary Score in your Dashboard

**Package: Perform**

You can add the Driving Summary Score to your dashboard. It indicates the overall driving summary score of selected vehicles/vehicle groups during any specific period.

**Note: This score takes into consideration the same settings from the Driving Style module.**

The image shows the driving summary score **per vehicle group** (split per group option) (**with** comparison period - two different periods): 

### googleuser

For more details please read this article.

#### 3) Transpoco Launches New Transpoco Protect Programme

**Package: Perform + Synx Vision AI**

Transpoco Protect, a fleet safety programme that focuses on driver safety and fleet Insurance costs reduction.

The introduction of the Fleet Safety Programme came from a collaboration with Actavo, an existing client. Working closely and understanding their needs it was very clear they wanted to go a step further from forward-facing camera technology and move to a solution that helps to in-cab coach the drivers and focus on preventing collisions in line with their safety first message across the group.

Please contact support@transpoco.com for further information.

### April 2021

#### 1) Option to send recurring messages to your fleet drivers in the Message Module

**Package: Move + Maintenance / Maintenance / Perform**

You can send recurring messages now via the message module in your Transpoco Synx account. They can be sent via SMS or Email. The recurrency can be daily, weekly, monthly and yearly. You can also choose an end time for them.

### may-17-2021

may-17-2021

For more details please read this article.

#### 2) Transpoco Launches New Integration Fuel Partnership with Johnston Fuel cards

**Package: Move + Maintenance / Maintenance / Perform**

The new partnership will allow Transpoco’s customers to benefit from the ability to integrate fuel card data in the UK across multiple fuel card providers, monitor transactions, capture data, and instantly verify fuel transactions. Whilst also having live vehicle location, journey history, and speeding reports.

Back office staff will have the ability analysis location alerts for when vehicles enter or leave specific fuel stations. This partnership gives customers the full picture and further helps to reduce admin time, loss of fuel, and revenue.

For more detail please contact us at support@transpoco.com

#### 3) Check out your Settings - Set up and show different shift times in your reports

**Package: Move + Maintenance / Maintenance / Perform**

You can set up your customized shift times, and also filter out your fleet reports by the specific shift times that you set up in your Transpoco Synx account.

There are two default shift time settings in your account:

-   Working hours (09:00 - 16:59, Monday to Friday)
-   Outside working hours (00:00 - 08:59 & 17:00 - 23:59, Monday to Friday + the whole weekend)

Only a few companies have it available now as beta testers. If you want to have it available, send a request to support@transpoco.com.

### may-17-2021

may-17-2021

**Note:** Only few reports have the shift time available

For more detail please read this article.

### February and March 2021

#### **1) Link between your Walkaround defects and services created to address them.**

**Package: Move + Maintenance / Maintenance / Perform**

You can see the service information related to the defects reported in the Walkaround checks.

### apr-13-2021

For more details please read this article.

#### **2)** New Business Vehicle Tracking Partnership with Workpal

**Package: All packages**

WorkPal is a software solution developed in-house to help manage mobile workforces. The new partnership will allow Transpoco’s customers to benefit from the ability to remotely schedule and assign jobs to field operatives, monitor job progress, capture data and instantly invoice clients.

### apr-13-2021

Please contact sales@transpoco.com for further information and a demonstration of the software.

#### **3)** Fuel checking for non tracked vehicles (without GPS coordinates)

**Package: Perform**

The system is now able to do fuel checks for non tracked vehicles (without GPS tracking). It will look for the vehicle registration given by the driver at the till and/or for a vehicle registration that can be set at the card description by the Fleet Manager. If the purchase data matches with the registration, then this purchase will be assigned to this vehicle. 

### apr-13-2021

For more details please read this article.

### January 2021

#### **1) Fleet Summary: F**ilter the Fleet Summary report by **Weekdays** or **Weekends**

**Package: Locate / Move / Perform**

You can filter the "Fleet Summary" report data by weekdays or weekends additionally based on the chosen period of date. 

If you choose the “Weekend Only” option, the report will bring the data related to the weekends (only Saturday and Sunday) from the period selected. The “Weekdays only” option is taking into consideration Monday to Friday days from the period selected.

#### **feb-19-2021**

For more details please read this article.

#### **2)** Tracker Units and Camera issues into your **Notifications** page

**Package: Move / Move+ / Perform**

The Notifications page will work like a "Hardware Health Check" page where you can see issues with your tracker units and/or camera.

**Note:** This is a new feature and it is currently rolling out.

If you don't have it enabled yet, you can request it to our Support Team on support@transpoco.com and we will make it available for you.

You can see a table in the Notifications page that includes: vehicle, make/model, date of event, category, event type, event duration, status and notes. Different filters can be applied to your search and the results are exportable.

**feb-22-2021**

For more details please read this article.

#### **3) Dashboard:** Check the **Driver ID usage by vehicle group**

**Package: Move+ / Perform**

You can add the metric called “Percentage of Journeys Driver ID Used” and split it by the vehicle groups from your choice.

#### **feb-19-2021**

**feb-19-2021**

For more details please read this article.

#### **4)** Extra security layer - IP address access restriction

**Package: Perform**

You can turn on/off the IP address access restrictions feature in order to give you an additional layer of security.

### feb-19-2021

feb-19-2021

Note: The IP addresses you add here will be the only ones with access to your account. For more details please read this article.

### December 2020

#### **1) Customised time between questions on the Walkaround checks**

**Package: Maintenance / Perform**

After the checklist is selected in the Driver App, the driver will start to answer the questions from the checklist and  the app will show a Warning by default if the driver is answering too fast (less than 5 seconds).

 If you want to customise it please contact our Support Team at **support@transpoco.com.**

googleuser

googleuser

For more details please read this article.

#### **2)** Search for specific questions/answers on the Walkaround and export them accordingly

**Package: Maintenance / Perform**

By typing in the search box, the system will look for the word(s) in the list of checks done, e.g. instruments. **Note:** The results will filter as you type.

### jan-13-2021

Exporting the results accordingly:

jan-13-2021

For more details please read this article.

#### **3)** Check the Average Fuel Consumption by vehicle group

**Package: Move + / Performance**

Once you choose the “Average Fuel Consumption” as the Metric type, you will see the "Split per Group" option available.

### jan-20-2021

Then, you will be able to see the “Average Fuel Consumption” value by vehicle group:

jan-20-2021

**Note:** At the moment, all vehicle groups will be taken into account. In future, you will be able to pick the vehicle groups you want.

For more details please read this article.

### November 2020

#### **1) AI Camera Alerts Report** 

**Package: Additional to Packages (Move / Perform)**

The AI Camera Alerts Report shows each single alert triggered by the camera(s) installed in the vehicle with the event time, video and snapshots. 

There are two types of camera: one is the Front Face camera which faces the driver with Artificial Intelligence (AI) functions and the another one is the camera which faces the road with advanced driver-assistance systems (ADAS).

**Note:**  You can view examples in this article.

### dec-14-2020

You can also request any video recorded by clicking “Request video” on the top right corner of the report.

dec-14-2020

For more details please read this article.

#### **2) AI Camera Metrics in the Dashboard**

**Package: Additional to Packages (Move / Perform)**

You can add the AI Camera metrics to your Synx Dashboard. The metrics are based on the alerts set in the cameras. You will be able to see the number of alerts for the period of time selected, vehicle, vehicle group and based on other filters available.

### dec-14-2020

For more details please read this article.

#### **3) Terms & Conditions + Privacy Policy link**

**Package: All packages.**

You can easily access the Terms & Conditions with the Privacy Policy through a new link available in the system.

### dec-14-2020

#### **4) Get in Touch link**

**Package: All packages.**

You can easily contact our Support Team through a new link available in the system.

### dec-14-2020

### October 2020

#### **1)** Average fuel consumption metric in the Dashboard

**Package: Additional to Packages (Move / Perform)**

If you want to know what is your fleet average fuel consumption or even for a particular vehicle group,  you can now add this metric to your Dashboard.

nov-18-2020

The screenshot above is showing the average from October to November as displayed in the period filter on the top. You can also compare the average fuel consumption from different periods.

### nov-18-2020

For more details please read this article.

#### **2)** Creating a service based on the odometer value rather than distance

**Package: Maintenance / Perform / Additional to Move Package**

When creating a new service you will be able to see the current odometer value of the vehicle selected and the odometer for the next service.

nov-23-2020

For more details please read this article.

#### **3) Filter to see and export only defects / no defects in the WA web module**

**Package: Maintenance / Perform / Additional to Move Package**

Filter by **Status** so the results only show those with a defect or only those No defect (**Note:** Default is ‘All Status’) by clicking on the **down arrow** to the right of ‘Status’.

nov-25-2020

**Note:**  The green thumbs up represents checklist done with No defects. 

            The red thumbs down represents checklist done with Defects.     

nov-26-2020

You can also export  the results that you have selected by clicking on the "Download Table (.CSV)" option highlighted above.

For more details please read this article.

### September 2020

#### **1)** **Electric Vehicle Reports (Canbus) - REAL-TIME BATTERY STATUS REPORTING**

**Package: Additional to Packages (Move / Perform)**

These reports are exclusive to CANbus installed in electric vehicles

Initial fields are displayed on active map to show vehicle battery status with other standard parameters such as Speed / Location / Driver ID / Battery Level / Charging State etc

This feature enables the visualized **data points** where vehicles **are being charged** and the **duration** of it being charged. It also provides a report logging all of the charging activity for the vehicles (depending on vehicle type) with location and duration of charge.

Monitor and manage **Battery Levels** and **Charge Points**, identify opportunities to improve the fleet functionality by building bespoke alerts / reports on key EV activity

ev real time display

aug-28-2020

For more details please read this article.

#### **2)** **Applegreen Fuel Provider**

**Package: Perform** 

We worked on this feature to get customers to  get their fuel transactions seamlessly sent to us daily directly from Applegreen so the translations are automatically loaded onto the customer fuel account.

Prior to setup up your Applegreen account, you need to send to Transpoco an email (using the template provided) to authorise use of your Applegreen account so they can start sending daily file with fuel transaction to our FTP site. These transactions are then automatically loaded onto your fuel account.

aug-31-2020

For more details please read this article.

### August 2020

#### **1) Speed Trend Report**

**Package: Perform**

The Speed Trend shows the total percentage of speeding events by vehicles over different time periods like past 3 weeks for instance. The default is a stacked graph, but you can change this to a line graph.

image-454

image-454

For more details please read this article.

---

#### 2) **Speed Improvement Report**

**Package: Perform**

This information shows how much drivers have reduced (improved) their speeding events, or not, over different time periods. Positive numbers mean more speeding events (not improved) and negative numbers mean less speeding events (improved).

image-468

For more details please read this article.

---

#### **3)** Driving Style inside Driver App

**Package: Perform**

Your drivers will be able to access their own data inside app without knowing about the other drivers. Only for the Fleet Managers will be displayed the top 5 most "dangerous" drivers data. 

**Driving Summary:** Your Drivers will be able to check their *Speeding, Harsh Braking, Rapid Acceleration and Harsh Cornering percentages* *(depending on what is set in the Web solution).*

*image-484*

**Speed Summary:** Your Drivers will be able to check their *Speeding* regarding the percentage *over Speed Limit (depending on what is set in the Web solution).*

*image-487*

**Driving Trend:** Your Drivers will be able to *check their score for the* past days / weeks in a trend graphic which will help them improve their safety each day / week.

image-490

**Driver Rank:** Drivers Rank is based on your drivers’ score from the day before which means the Rank can change on a daily basis. Fleet Managers can follow it from the Driving Summary (in the Web solution) which is ordered by score as well.

image-495

For more details please read this article.

---

### July 2020

#### **1) Brand new layout for the Temperature Reports**

**Package: Move + / Perform + "Adittional Temperature Option"**

With the addition of a temperature probe into your GPS telematics hardware you can monitor temperature in real time and historically.

You can view the temperature details at any points on the graph by putting your cursor at the specifc point. 

temperture

For more details please read this article.

---

#### **2) Alerts for Temperature**

Real-time Alerts notifying key stakeholders of any critical temperature changes within pre set thresholds can be configured. 

Annotation 2020-06-16 105102

image-3

For more details please read this article.
