# [Fleet Summary Export] - How do I add extra columns to the export of my Fleet Summary Report?

Back to home

1.  Knowledge Base 
3.  Reports 
5.  Reports 

-   Logging-in to your Transpoco account
    -   Login to your Transpoco account
    -   Transpoco Smartphone Apps
    -   2 Factor Authentication
    -   System requirements
    -   Overview of Transpoco
    -   Implementation
-   How to organise your account to achieve the best results
    
-   How to use each feature - step by step guides
    -   Users and permissions
    -   Walkaround Checks module
    -   Fuel/Electric Vehicles Module
    -   Maintain Module
    -   Dashboard
    -   Messaging module
    -   Scheduled Reports
-   How to Order More Trackers
    
-   Live Map
    
-   Cameras
    -   FAQ
-   Webinar Videos
    
-   Walkaround Checklists
    -   Walkaround Checklists
    -   Driver App
    -   Alerts
-   Reports
    -   Reports
    -   Viewing data in reports
-   Fuel
    
-   Dashboard
    
-   Maintain Module
    
-   Driving Style
    
-   Locations
    
-   Cost Management (TCO) Report
    
-   The Notification Features
    
-   Hardware and Installation
    
-   Removal & Repair of Hardware
    -   Requesting a Repair or a Deinstallation
-   Cameras & GDPR Guidelines
    
-   Scheduled Reports
    
-   Safety Program
    
-   Fleet Manager App
    
-   Users & Permissions
    
-   Alerts
    
-   Policies & Documents
    
-   Privacy Policy and Terms & Conditions
    -   RoPA
-   API
    
-   Transpoco User Manuals
    
-   Settings
    -   Garage
-   Whats New?
    
-   Account Mangement Services
    
-   Driver ID process
    
-   Security
    
-   Transpoco Locate
    
-   Subscriptions & Invoices
    
-   Tutorial videos
    
-   Cancelling your account
    
-   VOR
    
-   Installation
    
-   BIKLY
    

# \[Fleet Summary Export\] - How do I add extra columns to the export of my Fleet Summary Report?

## You can export your Fleet Summary report with extra columns in the Synx product. The detailed instructions as follows:

1.  Log in to your Transpoco Synx account.
2.  Click on Services > Live Map > Fleet Summary.  
    
3.  In the default report, it contains 11 columns as shown below:  
    
4.  Click on the “Export” on the top right corner of the page. .
5.  Then type the email address and choose a suitable format of the report.  
    
6.  Then you can add preferred extra columns from the options below to your export.  
    
7.  Then choose an export option.  
    
8.  Click on the “Export” button .
9.  You will receive your report via email or downloaded locally, depending on your choice in step 7.
