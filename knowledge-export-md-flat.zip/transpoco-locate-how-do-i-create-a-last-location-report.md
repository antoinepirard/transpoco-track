# Transpoco Locate: How do I create a Last Location Report?

Back to home

1.  Knowledge Base 
3.  Transpoco Locate 

-   Logging-in to your Transpoco account
    -   Login to your Transpoco account
    -   Transpoco Smartphone Apps
    -   2 Factor Authentication
    -   System requirements
    -   Overview of Transpoco
    -   Implementation
-   How to organise your account to achieve the best results
    
-   How to use each feature - step by step guides
    -   Users and permissions
    -   Walkaround Checks module
    -   Fuel/Electric Vehicles Module
    -   Maintain Module
    -   Dashboard
    -   Messaging module
    -   Scheduled Reports
-   How to Order More Trackers
    
-   Live Map
    
-   Cameras
    -   FAQ
-   Webinar Videos
    
-   Walkaround Checklists
    -   Walkaround Checklists
    -   Driver App
    -   Alerts
-   Reports
    -   Reports
    -   Viewing data in reports
-   Fuel
    
-   Dashboard
    
-   Maintain Module
    
-   Driving Style
    
-   Locations
    
-   Cost Management (TCO) Report
    
-   The Notification Features
    
-   Hardware and Installation
    
-   Removal & Repair of Hardware
    -   Requesting a Repair or a Deinstallation
-   Cameras & GDPR Guidelines
    
-   Scheduled Reports
    
-   Safety Program
    
-   Fleet Manager App
    
-   Users & Permissions
    
-   Alerts
    
-   Policies & Documents
    
-   Privacy Policy and Terms & Conditions
    -   RoPA
-   API
    
-   Transpoco User Manuals
    
-   Settings
    -   Garage
-   Whats New?
    
-   Account Mangement Services
    
-   Driver ID process
    
-   Security
    
-   Transpoco Locate
    
-   Subscriptions & Invoices
    
-   Tutorial videos
    
-   Cancelling your account
    
-   VOR
    
-   Installation
    
-   BIKLY
    

# Transpoco Locate: How do I create a Last Location Report?

## See your vehicles in real-time on the map and in a report in SynX Locate.

This report differs from the others as it is capturing real-time information so the dates cannot be changed.

Ensure you are in **Live Map** view.

Home Page

1.  Select the **Vehicle(s)**.
2.  Select ‘Last Location’ from the **Report** drop-down list.
3.  Select **Reports** from the header menu and the real-time data will appear in a table.

Last Location Table

The standard information contained in this report is:

-   Vehicle: Vehicle name/number
-   Date/Time: Time of last update
-   Location: Location at last update
-   Speed: Speed at last update
-   Engine: Engine current status, On/Off
-   GPS Odometer: GPS-based mileage counter at last update
-   GPS Signal: Indication of current GPS signal strength
-   GSM Signal: Indication of current GSM signal strength
