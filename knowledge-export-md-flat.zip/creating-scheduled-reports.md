# Creating Scheduled Reports

Back to home

1.  Knowledge Base 
3.  How to use each feature - step by step guides 
5.  Scheduled Reports 

-   Logging-in to your Transpoco account
    -   Login to your Transpoco account
    -   Transpoco Smartphone Apps
    -   2 Factor Authentication
    -   System requirements
    -   Overview of Transpoco
    -   Implementation
-   How to organise your account to achieve the best results
    
-   How to use each feature - step by step guides
    -   Users and permissions
    -   Walkaround Checks module
    -   Fuel/Electric Vehicles Module
    -   Maintain Module
    -   Dashboard
    -   Messaging module
    -   Scheduled Reports
-   How to Order More Trackers
    
-   Live Map
    
-   Cameras
    -   FAQ
-   Webinar Videos
    
-   Walkaround Checklists
    -   Walkaround Checklists
    -   Driver App
    -   Alerts
-   Reports
    -   Reports
    -   Viewing data in reports
-   Fuel
    
-   Dashboard
    
-   Maintain Module
    
-   Driving Style
    
-   Locations
    
-   Cost Management (TCO) Report
    
-   The Notification Features
    
-   Hardware and Installation
    
-   Removal & Repair of Hardware
    -   Requesting a Repair or a Deinstallation
-   Cameras & GDPR Guidelines
    
-   Scheduled Reports
    
-   Safety Program
    
-   Fleet Manager App
    
-   Users & Permissions
    
-   Alerts
    
-   Policies & Documents
    
-   Privacy Policy and Terms & Conditions
    -   RoPA
-   API
    
-   Transpoco User Manuals
    
-   Settings
    -   Garage
-   Whats New?
    
-   Account Mangement Services
    
-   Driver ID process
    
-   Security
    
-   Transpoco Locate
    
-   Subscriptions & Invoices
    
-   Tutorial videos
    
-   Cancelling your account
    
-   VOR
    
-   Installation
    
-   BIKLY
    

# Creating Scheduled Reports

## In this article we will explain how you can create a scheduled report for a variety of reports which you will receive by email.

### **Where are the Scheduled Reports in your account?**

Scheduled Reports is a feature available to customers subscribing to our **Move** and **Perform** packages.

You can find Scheduled Reports on the **Services menu.** 

  

image (45)

  
  

When you open Scheduled Reports you can view the existing scheduled reports created in your account.

The standard information (can be customised) contained in this table covers the following:

-   Report Name:        Name of the Scheduled Report
-   Vehicle Group:        Vehicle Group included in the Scheduled Report
-   Vehicle:         Single vehicle included in the Scheduled Report
-   Reports:        Pre-defined Generated Reports included in the Scheduled Report
-   Schedule:        Frequency of Scheduled Report
-   Created By:        User who created the Scheduled Report
-   Actions:        Edit or delete the Scheduled Report, and show the schedule history

### How to create a new scheduled report?

-   Click on the blue **New Schedule Report** button above the list of Scheduled Reports.

Scheduled-reports

The form opens with blank fields and three tabs. **Note:** fields with an asterisk must have criteria added.

-   Type a subject name, which will be the name of the Scheduled Report being created (e.g. Evening Journeys).
-   Type a brief description of what the Scheduled Report is about (e.g. All journeys after 6pm).

The Scheduled Report can be filtered by vehicles or drivers.

To filter by **vehicles**:

-   To select a vehicle group to be included in the Scheduled Report, either leave ‘All Vehicles’ (default) or choose one or more vehicle groups from the Filter By Vehicle Group drop-down list.
-   Alternatively, select one vehicle from the Vehicle drop-down list if the Scheduled Report is to only include a specific vehicle.

To filter by **drivers**:

-   To select a driver group to be included in the Scheduled Report, either leave ‘All Driver Groups’ (default) or choose one or more driver groups from the Filter By Driver Group drop-down list.
-   Alternatively, select one driver from the Driver drop-down list if the Scheduled Report is to only include a specific driver.
-   Choose the reports to be included in the Scheduled Report by selecting one or more from the drop-down list (e.g. Journey; Summary).

**Note:** To delete any criteria, click on the ‘x’.

Click on the **Next** button to advance to the Configuration tab.  

-   Select Daily, Weekly or Monthly from the Schedule drop-down menu (default is Daily).
-   Select the two-hour time slot for creating and sending the report from the Schedule Time drop-down menu (default time is 6am – 8am).
-   Choose the file format (PDF or CSV) in the File Format drop-down menu (default is PDF).
-   Choose the language of the report (currently English, French or Spanish) from the Report Language drop-down menu (default is English).
-   Choose the required time zone (currently Dublin, Paris or Madrid) from the Time Zone drop-down menu (default is Dublin).
-   Choose the preferred unit of distance (kilometres or miles) from the Distance Unit drop-down menu (default is KM, but can be changed to miles for UK users).
-   Type in the start and end shift times that the Scheduled Report will cover in the Shift Time Begin and Shift Time End fields. **Note:** to amend the times, highlight the hours or minutes and click on the up/down arrows.
-   Click on the **Next** button to advance to the Alert and Permission tab.

-   Select the name(s) of the intended recipient(s) of the Scheduled Report from the Send Reports To drop-down menu.
-   Select the name(s) of the users who will be granted access to see, edit and delete the Scheduled Report from the Who Can Manage This Schedule? drop-down menu.
-   Click on the **Confirm** button to create the new Scheduled Report.

You will briefly see a message in the bottom left of the screen to confirm the new Scheduled Report has been created.

The new Scheduled Report has been added to the list.

### **Which reports are available?**

The reports available to configure for a scheduled report will depend on your package but here is a full list of all available scheduled reports:

-   Alerts
-   Driving Summary
-   Engine
-   Fleet Summary
-   Fuel Consumption
-   Fuel Consumption Summary
-   Fuel Transactions
-   Idling
-   Journeys
-   Last Location
-   Locations
-   Notifications
-   Services
-   Stops
-   Stops/Idling
-   Speed Summary
-   Speed Summary Chart
-   Speed Summary Detail
-   Temperature
-   Walkaround Check Questions
-   Walkaround Check Summary

### **Viewing a Scheduled Report (for recipients only)**

-   Click on the Download link in the email. The file will open in the preferred format.

-   Print or download the file as required.

### **Editing an existing scheduled report**

-   Click on the **green** **edit** icon at the end of the required Scheduled Report row.

-   Select the tab where you want to make the change (e.g. Configuration).
-   Make the required change (e.g. change Daily to Weekly schedule).

-   Click Next to go to the next tabbed page. Repeat if necessary.
-   Click Confirm to complete the update.

You will briefly see a message in the bottom left of the screen to confirm the Scheduled Report has been updated.

### **Viewing the history of a scheduled report**

-   Click on the **blue schedule history** icon at the end of the required Scheduled Report row.

The Schedule History list includes the following:

-   Report Name:        The name of the Scheduled Report.
-   Start Date:        The start date for the vehicle activity.
-   End Date:        The end date for the vehicle activity (**Note:** this is a weekly report, so  
    the start and ends dates are a week apart.)
-   To order the reports in ascending or descending order, click once or twice respectively in the required column header (e.g. in the image above, this is the End Date).
-   Click on the **Download** button to download the report in the preferred format (PDF or CSV).

1.  **Delete Scheduled Report**

-   Click on the **red delete** icon at the end of the required Scheduled Report row.

-   Click **Delete** on the confirmation pop-up.

You will briefly see  a message in the bottom left of the screen to confirm the Scheduled Report has been deleted.
