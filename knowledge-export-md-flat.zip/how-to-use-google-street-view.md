# How to use Google Street View?

Back to home

1.  Knowledge Base 
3.  Live Map 

-   Logging-in to your Transpoco account
    -   Login to your Transpoco account
    -   Transpoco Smartphone Apps
    -   2 Factor Authentication
    -   System requirements
    -   Overview of Transpoco
    -   Implementation
-   How to organise your account to achieve the best results
    
-   How to use each feature - step by step guides
    -   Users and permissions
    -   Walkaround Checks module
    -   Fuel/Electric Vehicles Module
    -   Maintain Module
    -   Dashboard
    -   Messaging module
    -   Scheduled Reports
-   How to Order More Trackers
    
-   Live Map
    
-   Cameras
    -   FAQ
-   Webinar Videos
    
-   Walkaround Checklists
    -   Walkaround Checklists
    -   Driver App
    -   Alerts
-   Reports
    -   Reports
    -   Viewing data in reports
-   Fuel
    
-   Dashboard
    
-   Maintain Module
    
-   Driving Style
    
-   Locations
    
-   Cost Management (TCO) Report
    
-   The Notification Features
    
-   Hardware and Installation
    
-   Removal & Repair of Hardware
    -   Requesting a Repair or a Deinstallation
-   Cameras & GDPR Guidelines
    
-   Scheduled Reports
    
-   Safety Program
    
-   Fleet Manager App
    
-   Users & Permissions
    
-   Alerts
    
-   Policies & Documents
    
-   Privacy Policy and Terms & Conditions
    -   RoPA
-   API
    
-   Transpoco User Manuals
    
-   Settings
    -   Garage
-   Whats New?
    
-   Account Mangement Services
    
-   Driver ID process
    
-   Security
    
-   Transpoco Locate
    
-   Subscriptions & Invoices
    
-   Tutorial videos
    
-   Cancelling your account
    
-   VOR
    
-   Installation
    
-   BIKLY
    

# How to use Google Street View?

## How to enable and use Google Street View in Transpoco Locate

You cannot view your vehicles in Street View as these are made up of Google images, but you can, as examples, view the exact location a vehicle has passed or stopped, follow its route, or see where it was speeding.

To enable Street View, either:

Drag **Pegman** and drop onto the required blue highlighted road.

**Note:** if a road is not highlighted in blue, then there are no Street View images available.

Street View - dragging pegman

Or

Right click on a road and select ‘Street View’ from the pop-up menu.

Street View - right click

Street View

Once in Street View, you can:

-   Pan the view by **left clicking and dragging** the view left or right.
-   Follow the road by clicking on the **arrow icons** displayed on the road.
-   Expand to full screen by clicking on the **full screen** icon in the top right-hand corner of the screen.
-   Exit full screen by pressing the **ESC** key on your keyboard or clicking on the reduce screen icon in the right-hand corner of the screen.
-   View directly in Google Maps by clicking on **View in Google Maps** in the top left-hand corner. Google Street Maps will open in a new browser tab so the map is still open in Transpoco Locate as you left it.

Click the **left** **arrow** in the left-hand corner of the screen to exit Street View and return to the Map view.
