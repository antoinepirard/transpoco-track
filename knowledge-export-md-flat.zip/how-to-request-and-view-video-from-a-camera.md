# How to request and view video from a camera

Back to home

1.  Knowledge Base 
3.  Cameras 

-   Logging-in to your Transpoco account
    -   Login to your Transpoco account
    -   Transpoco Smartphone Apps
    -   2 Factor Authentication
    -   System requirements
    -   Overview of Transpoco
    -   Implementation
-   How to organise your account to achieve the best results
    
-   How to use each feature - step by step guides
    -   Users and permissions
    -   Walkaround Checks module
    -   Fuel/Electric Vehicles Module
    -   Maintain Module
    -   Dashboard
    -   Messaging module
    -   Scheduled Reports
-   How to Order More Trackers
    
-   Live Map
    
-   Cameras
    -   FAQ
-   Webinar Videos
    
-   Walkaround Checklists
    -   Walkaround Checklists
    -   Driver App
    -   Alerts
-   Reports
    -   Reports
    -   Viewing data in reports
-   Fuel
    
-   Dashboard
    
-   Maintain Module
    
-   Driving Style
    
-   Locations
    
-   Cost Management (TCO) Report
    
-   The Notification Features
    
-   Hardware and Installation
    
-   Removal & Repair of Hardware
    -   Requesting a Repair or a Deinstallation
-   Cameras & GDPR Guidelines
    
-   Scheduled Reports
    
-   Safety Program
    
-   Fleet Manager App
    
-   Users & Permissions
    
-   Alerts
    
-   Policies & Documents
    
-   Privacy Policy and Terms & Conditions
    -   RoPA
-   API
    
-   Transpoco User Manuals
    
-   Settings
    -   Garage
-   Whats New?
    
-   Account Mangement Services
    
-   Driver ID process
    
-   Security
    
-   Transpoco Locate
    
-   Subscriptions & Invoices
    
-   Tutorial videos
    
-   Cancelling your account
    
-   VOR
    
-   Installation
    
-   BIKLY
    

# How to request and view video from a camera

## In this article we will explain how you can manually request video from a driver facing or forward facing camera.

In this video, we will demonstrate how to request video from a camera in your vehicle. 

#### As demonstrated in the video above, there are 2 ways to manually request video from a forward facing or driver facing camera:

#### 1\. Request video in the Camera module:

1.  Log on to your Transpoco account.
2.  Click Services > Camera.  
    pasted image 0-2
3.  You will be able to see the full report as follows:  
      
    Camera-12-16-2024\_11\_45\_AM  
      
    

**Note:** Video will only download if the ignition is turned on (indicated as green). If the ignition is turned off (indicated as red) you will have to wait until the ignition has been turned on in order to download and view video.

1.  You could filter this report by date period. You can either select a specific range of date on the calendar or pick a certain date period at the bottom.  
    pasted image 0 (1)-2
2.  You could filter the report by vehicle groups.  
    
3.  You can filter this report by vehicles in a selected group.  
    
4.  You could also choose to show the requests which have failed.  
    
5.  Once you are ready, click on the “Apply Filter” option, or click close if you wish to remain default filter setting.
6.  There are default columns in the report:   
    Camera-12-16-2024\_11\_59\_AM  
      
    You can add more columns to the view by clicking **'Columns'** and selecting the columns you want to add.  
      
    Camera-12-16-2024\_12\_021\_PM
7.  You can turn the vehicle off and a red mark will appear besides the vehicle.  
    
8.  You can reorder each one column:  
    image-12-16-2024\_12\_08\_PM  
    There is a filter available for each column:  
    image-12-16-2024\_12\_12\_PM
9.  You can request any video recorded by clicking on “Request video” on the top right corner of the report.
    

**Note:**  You can view some video samples in this article.

10  You can also view the records of a specific event after you have requested any specific videos. 

**Note:** You can request the video of any vehicle, at any date with available data, at any time as the length of video up to 60 seconds.

11\. You will see a dialog as follows after you have requested the video. And the video icon will change from “Camera” to “Play” .

**Note:** If the request has failed, it will only show you once you have chosen this option in the filter.

12\. If you have a driver and forward facing video we will display the video from both cameras for the date and time requested - see the example below.

Camera-12-16-2024\_12\_47\_PM

#### 2\. Request a video from the route playback of a Fleet Summary report

1.  You could also request and view a video that related to a specific journey in the Fleet Summary report.
2.  Generate your Fleet Summary report and click on the “View route”.   
      
    
3.  You can click on the camera icon to request a video related to this particular journey.  
      
      
      
    

Note: Once you click on the camera icon , it will change to a clock icon for video requested, then it will change to the play button when the video is ready.
