# Tableau de bord - Comment contrôler le pourcentage d’utilisation del’Identification Conducteur par véhicule

Back to home

1.  Knowledge Base 
3.  Dashboard 

-   Logging-in to your Transpoco account
    -   Login to your Transpoco account
    -   Transpoco Smartphone Apps
    -   2 Factor Authentication
    -   System requirements
    -   Overview of Transpoco
    -   Implementation
-   How to organise your account to achieve the best results
    
-   How to use each feature - step by step guides
    -   Users and permissions
    -   Walkaround Checks module
    -   Fuel/Electric Vehicles Module
    -   Maintain Module
    -   Dashboard
    -   Messaging module
    -   Scheduled Reports
-   How to Order More Trackers
    
-   Live Map
    
-   Cameras
    -   FAQ
-   Webinar Videos
    
-   Walkaround Checklists
    -   Walkaround Checklists
    -   Driver App
    -   Alerts
-   Reports
    -   Reports
    -   Viewing data in reports
-   Fuel
    
-   Dashboard
    
-   Maintain Module
    
-   Driving Style
    
-   Locations
    
-   Cost Management (TCO) Report
    
-   The Notification Features
    
-   Hardware and Installation
    
-   Removal & Repair of Hardware
    -   Requesting a Repair or a Deinstallation
-   Cameras & GDPR Guidelines
    
-   Scheduled Reports
    
-   Safety Program
    
-   Fleet Manager App
    
-   Users & Permissions
    
-   Alerts
    
-   Policies & Documents
    
-   Privacy Policy and Terms & Conditions
    -   RoPA
-   API
    
-   Transpoco User Manuals
    
-   Settings
    -   Garage
-   Whats New?
    
-   Account Mangement Services
    
-   Driver ID process
    
-   Security
    
-   Transpoco Locate
    
-   Subscriptions & Invoices
    
-   Tutorial videos
    
-   Cancelling your account
    
-   VOR
    
-   Installation
    
-   BIKLY
    

# Tableau de bord - Comment contrôler le pourcentage d’utilisation del’Identification Conducteur par véhicule

## Dans le Tableau de Bord Synx, vous pouvez ajouter un métrique appelé “Pourcentage de trajets avec Conducteurs Identifiés” et répartir par groupe de véhicules.

1.  Après avoir cliqué sur “Ajouter'' dans le Tableau de Bord Synx, ajouter un titre dans le champ correspondant.  
    
2.  Choisir alors“ Pourcentage de trajets avec Conducteurs Identifiés” comme type de Métrique.
    
3.  L’option “Répartir par groupe” apparaîtra, il suffira de la sélectionner en cliquant sur le carré à côté du texte.
    
4.  Vous pouvez maintenant choisir le ou les groupes de véhicules depuis la liste.
    
      
    
5.  ne fois ces tâches effectuées, cliquer sur le bouton “Sauvegarder”.   
      
    
6.  Descendre en bas de la page du Tableau de Bord  afin de visionner le Pourcentage des trajets avec conducteur identifié par Groupe de Véhicules sélectionné.
    
7.  Vous avez la possibilité de modifier, rafraîchir, supprimer à tout moment ce métrique depuis la barre des tâches en haut à droite du métrique en question. .
