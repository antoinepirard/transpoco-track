# General definitions from Transpoco's system

Back to home

1.  Knowledge Base 
3.  Settings 

-   Logging-in to your Transpoco account
    -   Login to your Transpoco account
    -   Transpoco Smartphone Apps
    -   2 Factor Authentication
    -   System requirements
    -   Overview of Transpoco
    -   Implementation
-   How to organise your account to achieve the best results
    
-   How to use each feature - step by step guides
    -   Users and permissions
    -   Walkaround Checks module
    -   Fuel/Electric Vehicles Module
    -   Maintain Module
    -   Dashboard
    -   Messaging module
    -   Scheduled Reports
-   How to Order More Trackers
    
-   Live Map
    
-   Cameras
    -   FAQ
-   Webinar Videos
    
-   Walkaround Checklists
    -   Walkaround Checklists
    -   Driver App
    -   Alerts
-   Reports
    -   Reports
    -   Viewing data in reports
-   Fuel
    
-   Dashboard
    
-   Maintain Module
    
-   Driving Style
    
-   Locations
    
-   Cost Management (TCO) Report
    
-   The Notification Features
    
-   Hardware and Installation
    
-   Removal & Repair of Hardware
    -   Requesting a Repair or a Deinstallation
-   Cameras & GDPR Guidelines
    
-   Scheduled Reports
    
-   Safety Program
    
-   Fleet Manager App
    
-   Users & Permissions
    
-   Alerts
    
-   Policies & Documents
    
-   Privacy Policy and Terms & Conditions
    -   RoPA
-   API
    
-   Transpoco User Manuals
    
-   Settings
    -   Garage
-   Whats New?
    
-   Account Mangement Services
    
-   Driver ID process
    
-   Security
    
-   Transpoco Locate
    
-   Subscriptions & Invoices
    
-   Tutorial videos
    
-   Cancelling your account
    
-   VOR
    
-   Installation
    
-   BIKLY
    

# General definitions from Transpoco's system

## Here you can find some concepts / definitions from your SynX product.

#### **Index:**

-   From the Core System
-   From the Alerts Section
-   From the Driving Style Module
-   Difference Between Driving Style % Speeding Events and Alerts Set For Speed Above Road Limit
-   From the Fuel Module
-   From the Walkaround Module
-   From the Cameras Module
-   Asset Tracker
-   Immobilisation
-   Canbus / OBD

#### **From the Core System:**

**1) Device updates**

Send updates every 500m distance moved 

**OR** after 60 seconds with ignition on 

**OR** if direction change of more than 35 degrees

  

Device updates every 1 hour with ignition off

Devices goes into sleep mode after 4200 seconds (1.1hours / 70 minutes)

In sleep mode GPS and GSM turns off and reactivates when ignition is turned on. 

Device will wake up every hour while ignition is off and try to send update.

**Note 1:** We can custom how often the tracker updates eg. 30s.

**Note 2:** The deep sleep mode turns off the modem and gps about 10 minutes after the ignition goes off. The modem and gps wake up every 1 hour and try to send data.

**2) The Heatmap**

The heatmap displays in different colours the places where fleet vehicles were driven most part of the day. The system considers since midnight of the current day.

**3) Data storage capability without data connection**

About 10000 updates approx 80hours of driving without data connection.

**4) Driver ID settings**

Driver id with buzzer is enabled

Driver deregistration (logout) time is 3 mins

Buzzer will beep for 3mins if no login

**5) Unit Down:** indicates that the tracker in the vehicle has stopped functioning and has not sent an update for over 7 days.

**Yellow Pin on the Map:**  indicates that the tracker in the vehicle has stopped functioning and has not sent an update for over 12 hours. 

**Note:** Check if the vehicle does not have a dead battery or a master switch engaged. If not, please reach out to support for help.

**6) Private Mode**

When the vehicle is in private mode and the engine is turned OFF, the vehicle remains in private mode. Once the engine is turned ON, the driver will have a few seconds to remain in private mode if he uses the related fob during the beeping time. Otherwise, the vehicle will be back to business mode automatically.

 For the private mode, the latitude and the longitude are sent as 0,0.

**7) Tracker events considered for Journeys, Alerts, etc**

We only consider tracker events with the number of satellites >=5. If the satellites are lower than 5, we disconsider that event.

**8) The 3/4G technology**

The Eco4 unit is eligible but not the FMT100 is GSM based technology. 

**9) Vehicle timezone**

The vehicle timezone is only applied to the WA alerts in the system.

**10) Shift time**

The custom shift times will only work from the day they are created on.

**11) Orange Vehicle Icon**

When the system shows the orange icon it indicates the vehicle is idling.

**12) We don't consider the events below when generating journeys:**

-   -   Visible satellites are less than 5
    -   Latitude or longitude is null or invalid
    -   When the event\_id = 53 (???)
    -   When the timestamp of the event is too old  
          
        

**13) If the user complains they are not receiving the platform emails**

The email can be going to SPAM or being blocked by the company's firewall. This is our email provider which has to be unblocked if it's the case: pm\_bounces@pm.mtasv.net. It's used to verify if an email address is active or if the email has bounced.

#### **From the Alerts Section:**

**1) Speeding in Zone**

For this alert you need to specify exact the speed limit you want to target (eg 30km/h or 50km/h or 80km/h etc) and add an alert for this limit.

Eg speeding in zone = 30 and speed above road limit >3

In this example, you will just get alerts if the vehicle is over 33km/h in a 30 zone.

**2) Day parameter in the Alerts section**

The system considers each day of the week as a sequential number like 1, 2, 3...with Saturday being number 6 for instance. When we set an alert to less than Saturday, it means less than 6 so the system will ignore Saturday and Sunday on these alerts.

#### **From the Driving Style Module:**

**1) Rapid Acceleration**

Ruptela devices: Events are set to trigger if the next event is above 6m/s/s (increase of 21.6km/h in 1 second)

Teltonika devices: Events are set to trigger if the next event is above 2.8m/s/s (increase of 10 km/h in 1 second)

**Harsh Braking**

Ruptela devices: Events are set to trigger if the next event is below 6m/s/s (decrease of 21.6km/h in 1 second)

Teltonika devices: Events are set to trigger if the next event is above 2.8m/s/s (decrease of 10km/h in 1 second)

**Harsh Cornering**

Ruptela devices: Events are set to trigger if the next event is above 6m/s/s (increase of 21.6km/h in 1 second) when cornering

Teltonika devices: Events are set to trigger if the next event is above 2.8m/s/s (increase of 10km/h in 1 second)

**2) Road speed records and GPS accuracy**

To check the speed limits we validate the GPS speed received from the tracker against Inrix and then OpenCage. Some customers requested to use only Opencage.

We also manually check about 1000 speed alerts against Google Maps Street View per quarter. This is from where the 99% accuracy comes.

Our trackers GNSS accuracy depends on radio signals from three satellite networks (GPS ,Glonass,Galileo).

GNSS doesn't work indoors and the GNSS antenna needs to be placed facing the sky to receive a good signal.

We filter out any low accuracy data based on the number of satellites seen or limited section of the sky viewed (HDOP) 

US government GPS accuracy data here

**3) Private Mode x Driving Style Data**

When a vehicle is in Private Mode, the Driving Style section doesn't display Speeding, Harsh Braking, Harsh Cornering and Rapid Acceleration. We can see the last 3 events mentioned in the tracker logs but we can't see them in the Driving Style section.

#### **Difference between Driving Style % Speeding Events and Alerts set for speed above road limit:**

1\.  

2.

3.

#### **From the Fuel Module:**

**1) Carbon Footprint (Kg)**

The total is calculated by multiplying the total number of:

refill petrol litres by 2.3kg

refill diesel litres by 2.7kg

refill CNG kilos by 2.4kg

refill Electricity kWh by 0.2958kg

**2) Fuel Transactions reprocessed by stations created/edited**

When creating/editing a station in the system, all transactions within a period of 3 months will be reprocessed.

**3) Formula used to calculate the fuel consumption (l/100km or mpg)**

((fuel quantity / distance  between refills) \* 100, unit)

****4) Rules to match the fuel transactions automatically****

Vehicle fuel type, Fuel type that can be assigned

'Diesel', 'Diesel'

'Diesel', 'Others'

'Diesel', 'HVO'

'Petrol', 'Petrol'

'Petrol', 'Others'

'Hybrid', 'Petrol'

'Hybrid', 'Electricity'

'Electricity', 'Electricity'

'Unknown', 'Diesel'

'Unknown', 'Petrol'

'Unknown', 'Electricity'

'Unknown', 'Others'

'Unknown', 'CNG'

'Unknown', 'HVO'

'Unknown', 'SFGO'

**5) List of products we take into account in the Fuel module**

**provider\_name**

**product\_description**

Applegreen

Diesel

Applegreen

Car Wash

Applegreen

Ad Blue

Applegreen

Petrol

Corrib Oil

Unleaded Petrol

Corrib Oil

SFGas Oil 10ppm

Corrib Oil

Kerosene

Corrib Oil

Diesel

Corrib Oil

Diesel MilesPlus

Corrib Oil

AdBlue

DCI/Fuel wise

Diesel Unleaded

DCI/Fuel wise

Ad Blue Pack

DCI/Fuel wise

Diesel

DCI/Fuel wise

Car Wash

DCI/Fuel wise

Petrol

DCI/Fuel wise

Diesel Premium

DCI/Fuel wise

Ad Blue (pumped)

Epower

Electricity

ESB

Electricity

Glen EV

Electricity

Jigsaw

Adblue

Jigsaw

HVO

Jigsaw

BIO Fuel

Jigsaw

Diesel

Jigsaw

B7 GAZOLE

Jigsaw

Gas Oil

Johnston Oil Keyfuels

Petrol

Johnston Oil Keyfuels

Diesel

Johnston Oil Shell

Petrol

Johnston Oil Shell

Diesel

Johnston Oil UK Fuels

Petrol

Johnston Oil UK Fuels

Diesel

LeasePlan

Diesel

LeasePlan

Anti-Freeze

LeasePlan

Lubricants

LeasePlan

CNG

LeasePlan

Unleaded Petrol

LeasePlan

Lead Replacement Petrol

LeasePlan

Ad Blue

LeasePlan

Gas Oil

LeasePlan

Liquid Petroleum Gas

LeasePlan

Car Wash

LeasePlan

Petrol

LeasePlan

Fuel Station Purchases

LeasePlan

Fuel Abroad

Maxol

Gas Oil

Maxol

Lub Oil

Maxol

Super Unleaded

Maxol

Kero

Maxol

Car Wash

Maxol

Unleaded

Maxol

AdBlue (Packaged)

Maxol

Diesel

Maxol

AdBlue

Maxol

Liquid Petroleum Gas

Morgan Fuels

AdBlue pump

Morgan Fuels

Oil (Standard)

Morgan Fuels

HVO

Morgan Fuels

AdBlue Cans

Morgan Fuels

Oil

Morgan Fuels

HVO 100%

Morgan Fuels

Super Leaded

Morgan Fuels

Tolls

Morgan Fuels

Retail Diesel/Premium Diesel

Morgan Fuels

Screen Wash

Morgan Fuels

LPG

Morgan Fuels

Parking

Morgan Fuels

Car wash

Morgan Fuels

Diesel

Morgan Fuels

Gas Oil

Morgan Fuels

CNG

Morgan Fuels

Anti Freeze

Morgan Fuels

Unleaded

xxxxx

B7 GAZOLE

xxxxxx

AUS32

SSE Airtricity

Electricity

Topaz

Car Wash credit

Topaz

Diesel

Topaz

LPG

Topaz

EV Ultrafast Charging

Topaz

Anti Freeze

Topaz

HVO 100

Topaz

CNG

Topaz

Miles+ Diesel

Topaz

Petrol

Topaz

EV Transaction Fee

Topaz

AdBlue

Topaz

EV Charging

Topaz

EV Monthly Card Fee

Topaz

Car Wash

Topaz

AdBlue Pack

Topaz

Petrol Miles+ Unleaded

Topaz

EV Fast Charging

Topaz

SFGO

Topaz

EV Rapid Charging

Topaz

Lubes

Total

Lavage Progr. 1

Total

PÃ©age TVA

Total

Lavage Carte TW A

Total

Lavage Progr. 2

Total

AdBlue Pompe

Total

Lavage Carte TW B

Total

Electricity

Total

Gazole Premier

Total

Lavage Progr. 3

Total

AdBlue Bidon

Total

Lavage

Total

Gazole Excellium

Total

Lavage Carte TOTAL B

Total

Lavage Hte Pression

Total

Super 95 Sans PL

Total

Sans Plomb 95 E10

Total

Lavage Carte TOTAL A

**6) Mileage updated automatically by the mileage declared at the till**

In the fuel module , currently when a driver declares the vehicles mileage when filling up for fuel we update the vehicle odometer if the value given by the driver is with 10% of what we think the vehicles odometer is (mileage + tracker gps odometer).

#### **From the Walkaround Module:**

**1) WA alert threshold**

Speeding above 30km/h

**2) Services created from the Walkaround Module as per defect reported by the driver**

When we manually create a service from the walkaround module as an action of a defect reported, the system set it as due by default on the day of its creation. It means the schedule is set for today's date which is the date of its creation.

**3) Completion x Received Time of the Checklists Done**

Completion time of the checklist - is the time of the last checklist question answered.

Received time of the checklist - is the time when Transpoco's server receives the checklist done.

We record these different times as the Driver App can be used in an offline mode which means the driver can complete the checklist without submitting it or can click to submit it but there is no internet connexion to send the checklist at the time. In this case, the app will hold until having proper connexion to send it. 

**4) Maximum number of photos for a defect reported**

The maximum number of photos for a defect reported is 2.

**5) Mileage updated automatically by the odometer given via checklist**

Any time the driver completes the odometer type question if the odometer given is within 10% of what we think it is, the system updates the vehicles odometer.

#### **From the Cameras Module:**

**1) Alarms set with Video Evidences**

Driver Smoking, Fatigue Driving and Driver Making Calls.

**2) Speed and Location on Cameras**

If we have GPS signal on the camera we should get speed and location from it.

####  **Asset Tracker:**

**1) TAT100 (from Teltonika)**

It's set for 1 pin a day. We can't change this at the moment.

#### **Immobilisation:**

We don't need CANbus but the whitelisted drivers feature is only available on the Ruptela devices. 

We use Eco4 Light S and T in Ireland but these are 2G. 

We also have the HCV5-lite working with the functionality.

**CanBus/ OBD:**

These are the parameters we have mapped in the system so far:

Ruptela:

Teltonika:
