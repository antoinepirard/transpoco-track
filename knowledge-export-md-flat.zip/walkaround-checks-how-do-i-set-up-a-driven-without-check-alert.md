# Walkaround Checks: How do I set up a Driven Without Check alert?

Back to home

1.  Knowledge Base 
3.  Walkaround Checklists 
5.  Alerts 

-   Logging-in to your Transpoco account
    -   Login to your Transpoco account
    -   Transpoco Smartphone Apps
    -   2 Factor Authentication
    -   System requirements
    -   Overview of Transpoco
    -   Implementation
-   How to organise your account to achieve the best results
    
-   How to use each feature - step by step guides
    -   Users and permissions
    -   Walkaround Checks module
    -   Fuel/Electric Vehicles Module
    -   Maintain Module
    -   Dashboard
    -   Messaging module
    -   Scheduled Reports
-   How to Order More Trackers
    
-   Live Map
    
-   Cameras
    -   FAQ
-   Webinar Videos
    
-   Walkaround Checklists
    -   Walkaround Checklists
    -   Driver App
    -   Alerts
-   Reports
    -   Reports
    -   Viewing data in reports
-   Fuel
    
-   Dashboard
    
-   Maintain Module
    
-   Driving Style
    
-   Locations
    
-   Cost Management (TCO) Report
    
-   The Notification Features
    
-   Hardware and Installation
    
-   Removal & Repair of Hardware
    -   Requesting a Repair or a Deinstallation
-   Cameras & GDPR Guidelines
    
-   Scheduled Reports
    
-   Safety Program
    
-   Fleet Manager App
    
-   Users & Permissions
    
-   Alerts
    
-   Policies & Documents
    
-   Privacy Policy and Terms & Conditions
    -   RoPA
-   API
    
-   Transpoco User Manuals
    
-   Settings
    -   Garage
-   Whats New?
    
-   Account Mangement Services
    
-   Driver ID process
    
-   Security
    
-   Transpoco Locate
    
-   Subscriptions & Invoices
    
-   Tutorial videos
    
-   Cancelling your account
    
-   VOR
    
-   Installation
    
-   BIKLY
    

# Walkaround Checks: How do I set up a Driven Without Check alert?

## This alert will notify selected recipients when a vehicle has been driven without the driver first undertaking the walkaround check.

This alert triggers if the vehicle has driven at a speed above 30km/h without a walkaround check being complete during the same calendar day.

As an example, the following shows how to set up an alert for when any of the company vehicles have been driven without a check.

Go to **Services Menu** \>  **Walkaround > Alerts**  >

On the Alerts page click the **+New Alert** button.

Alerts - new button

New alert blank

Type in a **name** for the new alert.

Select ‘Driven Without Check’ from the drop-down list of **Alert Types**.

New alert no check 1

Next, click on the drop-down box to select which **vehicles** the alert is for – either all vehicles, vehicle group or individual vehicle(s). In our example, this is ‘Vehicle Groups’.

Then select the vehicle group from the **vehicle groups** drop-down list.

**Note:** If required, click on other vehicle groups to add more; to remove them if added in error, click on the **x** next to the group name.

Finally, select a recipient of the alert from the drop-down list of users.

If required, click on more names to add further recipients; to remove them if added in error, click on the **x** next to their name.

**Note 1:** If you want your drivers to receive this email alert, please check the box 'send email alert to the driver'. If it's an unknown driver, no driver will receive the alert. If the user who was set to receive the alert doesn't have access to the driver, the driver's name will be displayed as 'no access to driver's data'. But the driver will still receive the alert by email.

**Note 2:** Each driver will have access only to their own alert.

Click on **Create Alert**.

When the alert has been successfully created, the system will show a green confirmation message in the bottom left corner of the screen.

New alert message

The message will fade after a few seconds, or click the **x** to close it immediately.

When the alert has been triggered, an email will be sent to the selected recipients.
