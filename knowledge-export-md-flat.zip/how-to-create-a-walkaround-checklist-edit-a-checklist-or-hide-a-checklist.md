# How to create a walkaround checklist, edit a checklist or hide a checklist

Back to home

1.  Knowledge Base 
3.  How to use each feature - step by step guides 
5.  Walkaround Checks module 

-   Logging-in to your Transpoco account
    -   Login to your Transpoco account
    -   Transpoco Smartphone Apps
    -   2 Factor Authentication
    -   System requirements
    -   Overview of Transpoco
    -   Implementation
-   How to organise your account to achieve the best results
    
-   How to use each feature - step by step guides
    -   Users and permissions
    -   Walkaround Checks module
    -   Fuel/Electric Vehicles Module
    -   Maintain Module
    -   Dashboard
    -   Messaging module
    -   Scheduled Reports
-   How to Order More Trackers
    
-   Live Map
    
-   Cameras
    -   FAQ
-   Webinar Videos
    
-   Walkaround Checklists
    -   Walkaround Checklists
    -   Driver App
    -   Alerts
-   Reports
    -   Reports
    -   Viewing data in reports
-   Fuel
    
-   Dashboard
    
-   Maintain Module
    
-   Driving Style
    
-   Locations
    
-   Cost Management (TCO) Report
    
-   The Notification Features
    
-   Hardware and Installation
    
-   Removal & Repair of Hardware
    -   Requesting a Repair or a Deinstallation
-   Cameras & GDPR Guidelines
    
-   Scheduled Reports
    
-   Safety Program
    
-   Fleet Manager App
    
-   Users & Permissions
    
-   Alerts
    
-   Policies & Documents
    
-   Privacy Policy and Terms & Conditions
    -   RoPA
-   API
    
-   Transpoco User Manuals
    
-   Settings
    -   Garage
-   Whats New?
    
-   Account Mangement Services
    
-   Driver ID process
    
-   Security
    
-   Transpoco Locate
    
-   Subscriptions & Invoices
    
-   Tutorial videos
    
-   Cancelling your account
    
-   VOR
    
-   Installation
    
-   BIKLY
    

# How to create a walkaround checklist, edit a checklist or hide a checklist

## Here you'll find all the instructions that you need to manage your checklists.

### **Accessing the module**

Click on the Walkaround module at the Services menu

Then click on the "Checklist" option:

### **Creating a customised walkaround checklist**

### How to create a walkaround checklist

You can create customised checklists using our checklist builder and you can create as many as you want. To start go the **Services menu > Walkarounds > Checklists**

We provide 2 default walkaround checklists to help you to get started:

-   HGV checklist
-   LCV checklist.

To build your checklist click the blue **'New checklist'** button above the **Actions** column.

Start by entering a name and save the title.

To create your first check click the blue **'edit question'** button. 

You will enter the text of the check and then select the type. For example the default is the 'okay or default' (Yes or No) response. You can can change the check to accommodate different outcomes like entering an odometer or entering a number.

You can set a warning time for each check, the minimum is 5 seconds. The user cannot move to the next check until the 5 seconds has elapsed but you can customise this delay.

Finally, if you want to divide your checklist into sub-checklists like inside or outside use more than 1 description in the **Area** field. For example, checks with Inside' in the 'Area' field will appear in a sub-checklist called 'Indoor'.

If you want the checks to appear in a single checklist use the same description in the 'Area' field (like 'Start Checklist').

**Repeat process for each check- click 'New question' to create a new check.** 

Click the '**Submit'** button to save the checklist. The checklist will appear in the list of checklists in your Trnspoco account and will be visible to the drivers when they search for a checklist in the Driver App.

### **Editing a checklist title**

To edit a checklist title you need to click on the green button next to the checklist that you want to edit:

Then choose the new title:

Note that you can't edit the default checklists (LCV and HGV).

When clicking on Confirm, you should see a success message:

### **Hiding and unhiding a checklist**

You can also hide a checklist to remove it from your walkaround checks, just by clicking on the "eye" icon next to the name of the checklist:

After hiding a checklist, you can see it again changing the filter on the top of the page:

If you need to unhide a checklist, you need to select the "Hidden" option on the Status filter and then click again on the eye Icon:

A pop-up will be opened and then you click on "Unhide Checklist" to complete the process:

### **Deleting a checklist**

You can also delete a checklist. To delete it, the checklist needs to be hidden before. Select the "hidden" status in the filter and click on the "trash can" icon next to the checklist you want to exclude:

After this, a confirmation message will pop-up on the screen asking the user to confirm the exclusion:

Note: Deleting a checklist is irreversible, it will delete all answers and all historical data from the deleted checklist.
