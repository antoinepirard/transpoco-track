# Transpoco cameras and GDPR - guidelines

Back to home

1.  Knowledge Base 
3.  Cameras & GDPR Guidelines 

-   Logging-in to your Transpoco account
    -   Login to your Transpoco account
    -   Transpoco Smartphone Apps
    -   2 Factor Authentication
    -   System requirements
    -   Overview of Transpoco
    -   Implementation
-   How to organise your account to achieve the best results
    
-   How to use each feature - step by step guides
    -   Users and permissions
    -   Walkaround Checks module
    -   Fuel/Electric Vehicles Module
    -   Maintain Module
    -   Dashboard
    -   Messaging module
    -   Scheduled Reports
-   How to Order More Trackers
    
-   Live Map
    
-   Cameras
    -   FAQ
-   Webinar Videos
    
-   Walkaround Checklists
    -   Walkaround Checklists
    -   Driver App
    -   Alerts
-   Reports
    -   Reports
    -   Viewing data in reports
-   Fuel
    
-   Dashboard
    
-   Maintain Module
    
-   Driving Style
    
-   Locations
    
-   Cost Management (TCO) Report
    
-   The Notification Features
    
-   Hardware and Installation
    
-   Removal & Repair of Hardware
    -   Requesting a Repair or a Deinstallation
-   Cameras & GDPR Guidelines
    
-   Scheduled Reports
    
-   Safety Program
    
-   Fleet Manager App
    
-   Users & Permissions
    
-   Alerts
    
-   Policies & Documents
    
-   Privacy Policy and Terms & Conditions
    -   RoPA
-   API
    
-   Transpoco User Manuals
    
-   Settings
    -   Garage
-   Whats New?
    
-   Account Mangement Services
    
-   Driver ID process
    
-   Security
    
-   Transpoco Locate
    
-   Subscriptions & Invoices
    
-   Tutorial videos
    
-   Cancelling your account
    
-   VOR
    
-   Installation
    
-   BIKLY
    

# Transpoco cameras and GDPR - guidelines

## Guidelines regarding Transpoco cameras and GDPR, including Introduction, Policy creation, Advising the public of the recording, Storing data and timeframes, Data Security & Management, Data requests from law enforcement, Data requests from insurers.

### Introduction

The first point to clearly make is that using a dash cam in your company vehicles does involve recording data in a public setting. There are very logical reasons for making this recording but it must be noted that respect must be paid to data protection and GDPR legislation, and your company will be the data controller of the data held. Transpoco take the role of the data processor. The remainder of this document is designed to outline the important considerations and steps that should be taken in order to comply with recommendations from data protection regulators. If there is a complaint from an individual, the data protection agencies may be required to investigate the incident, it is important to show that you are compliant with data protection legislation.

### Policy creation (Sample - Camera Policy Doc)

-   You need to have a policy in place that covers the reasons for recording the data, how the data will be used, how long it will be stored and whether video and audio, or just video will be stored.
-   You should also consider in the policy your process for handling data request queries. 

Transpoco can provide a sample policy if required. Naturally, you will need to get your own professional advice relevant to your company before implementing your new policy.

### Advising the public of the recording (please find more details here)

-   In the first instance, there should be a clearly visible sign or sticker or other indication on and/or inside the vehicle, as applicable, to indicate that recording is taking place. A member of the public is entitled to know they have been recorded and can make a data request. 
-   How a data request from the public is handled and the time frame for response(1 months is reasonably) should be detailed in your policy. 
-   When dealing with a data request, it is advised to ensure you are sending data only related to the person making the request, for example other members of the public should be redacted from the video. Where required Transpoco can assist with the process of redacting if required.
-   In the event of an accident is is also advisable for the driver to verbally inform the other parties involved in the accident that the incident has been recorded

### Storing data and timeframes

The length of time footage is held needs to be defined in your policy document. Footage may be required for a historical incident, so footage may be kept in accordance with this. 

It is also important to note how Transpoco store video data. It works as follows:

-   For a forward facing camera we have a 64GB storage capacity as standard (storage capacity varies for other models)
-   Incidents triggered on the camera are automatically stored in snap shot form(an image a second for 10 second period) and these images are stored for xx years as default by Transpoco. If you require a different storage period or deletion sooner than this please advise. 
-   Video needs remotely downloaded from the camera, this is done through the web interface and phone apps where appropriate. Once downloaded the video is stored for xx years in line with our default data storage policy related to video
-   As the camera has limited capacity, video footage will overwrite itself on the camera. A standard forward facing camera has 64GB capacity and this records roughly 55 hours of video. If this video is not downloaded it will be overwritten and not available for future access
-   In the event where data has been overwritten and a member of the public requests to view video recording they believe may have been captured on the camera, in this event the a response to the request should detail reference your policy to provide the data but also the information that the video is no longer stored and thus not available.

**Note:** The footage in the SD card is not encrypted, it's an H264 or H265 format file

### Data Security & Management

-   Data needs to be held securely. There are a number of elements to this:
    
    -   We take data security very seriously and we have detailed policy and procedure in place. We keep pace with international best practice and maintain an ISO27001 certification in data security and management.
    
    -   Your policy document should consider all areas of potential risk related to a data breach, these are mostly related to human factors such as account access and sharing of data both internally and externally in your company. For example emailing a downloaded video (or posting on social media) and the conditions surrounding same should be very clearly outlined in your policy documents
    -   It is worth considering a privacy impact assessment related to telematics and video. This is an audit that examines all of the risks that exist and offers advice to minimise these risks. Transpoco can provide some information on how to carry out your own internal audit or engaging an appropriate consultant
    -   In relation to the driver or people with access to the inside of the vehicle: we provide locking cases as standard with our camera. This removes the risk anyone removing data manually from the camera in the vehicle

-   Transpoco’s role as the data processor. 
-   Your role as a data controller.

### Data requests from law enforcement

-   There are occasions where  a police force may request footage to help with an investigation.
-   According to data protection regulation if the police force can demonstrate that footage they request is necessary for the investigation of a criminal offence it is reasonable to comply with their request.
-   It is recommended to seek a written request for the data from the police force.

### Data requests from insurers

-   If you are submitting to an insurance company you need to be satisfied they will process that data in line with data privacy principles and will only hold the data as long as required.
-   It is recommended that you seek confirmation of their data processing process in writing.
-   If your insurance company asked you to install the camera and has ongoing access to data and incidents, they may be acting as a joint data controller.
-   If this is the case there should be a written agreement  in place that sets out the data protection responsibilities of all parties
