# Running a report for an archived vehicle

Back to home

1.  Knowledge Base 
3.  Settings 

-   Logging-in to your Transpoco account
    -   Login to your Transpoco account
    -   Transpoco Smartphone Apps
    -   2 Factor Authentication
    -   System requirements
    -   Overview of Transpoco
    -   Implementation
-   How to organise your account to achieve the best results
    
-   How to use each feature - step by step guides
    -   Users and permissions
    -   Walkaround Checks module
    -   Fuel/Electric Vehicles Module
    -   Maintain Module
    -   Dashboard
    -   Messaging module
    -   Scheduled Reports
-   How to Order More Trackers
    
-   Live Map
    
-   Cameras
    -   FAQ
-   Webinar Videos
    
-   Walkaround Checklists
    -   Walkaround Checklists
    -   Driver App
    -   Alerts
-   Reports
    -   Reports
    -   Viewing data in reports
-   Fuel
    
-   Dashboard
    
-   Maintain Module
    
-   Driving Style
    
-   Locations
    
-   Cost Management (TCO) Report
    
-   The Notification Features
    
-   Hardware and Installation
    
-   Removal & Repair of Hardware
    -   Requesting a Repair or a Deinstallation
-   Cameras & GDPR Guidelines
    
-   Scheduled Reports
    
-   Safety Program
    
-   Fleet Manager App
    
-   Users & Permissions
    
-   Alerts
    
-   Policies & Documents
    
-   Privacy Policy and Terms & Conditions
    -   RoPA
-   API
    
-   Transpoco User Manuals
    
-   Settings
    -   Garage
-   Whats New?
    
-   Account Mangement Services
    
-   Driver ID process
    
-   Security
    
-   Transpoco Locate
    
-   Subscriptions & Invoices
    
-   Tutorial videos
    
-   Cancelling your account
    
-   VOR
    
-   Installation
    
-   BIKLY
    

# Running a report for an archived vehicle

## How to view data from a vehicle we have stopped tracking.

After we stop the tracking of a vehicle the registration will disappear from the list of registrations in the Reports section. However, if you need to access data for a vehicle we have stopped tracking there is a solution.

In this video we demonstrate how you can run a report for a vehicle which was archived.

In the **Settings** menu, select **Vehicles** under **Garage,** then click the **archive tab**, search for the vehicle in question and click the **eye icon** button in the **Visibility** column. After this change, you will be able to select this registration to run a report.

(If you cannot see the registration on the list of vehicles log-out and log-in for the change to take affect)

To re-archive the vehicle do the opposite, enter vehicle archive section, search for the vehicle in question and click the hide button in the visibility column.
