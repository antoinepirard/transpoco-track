# How do I apply different shift times to my scheduled reports?

Back to home

1.  Knowledge Base 
3.  Scheduled Reports 

-   Logging-in to your Transpoco account
    -   Login to your Transpoco account
    -   Transpoco Smartphone Apps
    -   2 Factor Authentication
    -   System requirements
    -   Overview of Transpoco
    -   Implementation
-   How to organise your account to achieve the best results
    
-   How to use each feature - step by step guides
    -   Users and permissions
    -   Walkaround Checks module
    -   Fuel/Electric Vehicles Module
    -   Maintain Module
    -   Dashboard
    -   Messaging module
    -   Scheduled Reports
-   How to Order More Trackers
    
-   Live Map
    
-   Cameras
    -   FAQ
-   Webinar Videos
    
-   Walkaround Checklists
    -   Walkaround Checklists
    -   Driver App
    -   Alerts
-   Reports
    -   Reports
    -   Viewing data in reports
-   Fuel
    
-   Dashboard
    
-   Maintain Module
    
-   Driving Style
    
-   Locations
    
-   Cost Management (TCO) Report
    
-   The Notification Features
    
-   Hardware and Installation
    
-   Removal & Repair of Hardware
    -   Requesting a Repair or a Deinstallation
-   Cameras & GDPR Guidelines
    
-   Scheduled Reports
    
-   Safety Program
    
-   Fleet Manager App
    
-   Users & Permissions
    
-   Alerts
    
-   Policies & Documents
    
-   Privacy Policy and Terms & Conditions
    -   RoPA
-   API
    
-   Transpoco User Manuals
    
-   Settings
    -   Garage
-   Whats New?
    
-   Account Mangement Services
    
-   Driver ID process
    
-   Security
    
-   Transpoco Locate
    
-   Subscriptions & Invoices
    
-   Tutorial videos
    
-   Cancelling your account
    
-   VOR
    
-   Installation
    
-   BIKLY
    

# How do I apply different shift times to my scheduled reports?

## You can apply customized shift times to the main reports in the scheduled report section. Please find the detailed instructions below:

 Log in to your Transpoco account.

1.  Click on the Services > Analytics > Scheduled Report.  
    
2.  You will see the scheduled reports page, then click on the “+ New Schedule Report”.  
    
3.  Type in “Subject”, “Description”, select “Vehicles” or “filter by vehicle groups”, and then select one or more of the following options: Fleet Summary, Summary, Journeys, Idling, Idling/Stops and/or Stops.  
      
    
4.  Then click “Next” , go to the “Configuration” .
5.  Set the following options: Schedule period, Schedule Time, File format, Report Language, Time Zone, Distance Unit and Shift time and click on "Next".

Note: Please check here to see how you can set up the customised shift times which will be displayed in the Shift Time list below.

  

6\. Then select the recipients for your report(s) and who can manage this scheduled report on the "Alert and Permission" tab and click to confirm.

7\. The scheduled report will be displayed in your list of scheduled reports.
