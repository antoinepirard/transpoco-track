# Transpoco Locate: How do I create a Stops/Idling Report?

Back to home

1.  Knowledge Base 
3.  Transpoco Locate 

-   Logging-in to your Transpoco account
    -   Login to your Transpoco account
    -   Transpoco Smartphone Apps
    -   2 Factor Authentication
    -   System requirements
    -   Overview of Transpoco
    -   Implementation
-   How to organise your account to achieve the best results
    
-   How to use each feature - step by step guides
    -   Users and permissions
    -   Walkaround Checks module
    -   Fuel/Electric Vehicles Module
    -   Maintain Module
    -   Dashboard
    -   Messaging module
    -   Scheduled Reports
-   How to Order More Trackers
    
-   Live Map
    
-   Cameras
    -   FAQ
-   Webinar Videos
    
-   Walkaround Checklists
    -   Walkaround Checklists
    -   Driver App
    -   Alerts
-   Reports
    -   Reports
    -   Viewing data in reports
-   Fuel
    
-   Dashboard
    
-   Maintain Module
    
-   Driving Style
    
-   Locations
    
-   Cost Management (TCO) Report
    
-   The Notification Features
    
-   Hardware and Installation
    
-   Removal & Repair of Hardware
    -   Requesting a Repair or a Deinstallation
-   Cameras & GDPR Guidelines
    
-   Scheduled Reports
    
-   Safety Program
    
-   Fleet Manager App
    
-   Users & Permissions
    
-   Alerts
    
-   Policies & Documents
    
-   Privacy Policy and Terms & Conditions
    -   RoPA
-   API
    
-   Transpoco User Manuals
    
-   Settings
    -   Garage
-   Whats New?
    
-   Account Mangement Services
    
-   Driver ID process
    
-   Security
    
-   Transpoco Locate
    
-   Subscriptions & Invoices
    
-   Tutorial videos
    
-   Cancelling your account
    
-   VOR
    
-   Installation
    
-   BIKLY
    

# Transpoco Locate: How do I create a Stops/Idling Report?

## How to run a report in Locate to view both stops and idling events for your vehicle(s).

The Stop/Idling Report combines the information from the Stops Report and Idling Report.

**Note:** If you require more detailed information about how to run the report, see How do I create a report?

1.  Select the **Vehicle(s)**.
2.  Select ‘Stops/Idling’ from the **Reports** drop-down list.
3.  Select the **date range**.
4.  Click on the **View Report** button.

The total stops/idling duration for the fleet (or selected group of vehicles) is in the pink row.

The standard information contained in this report covers the following for each day during the selected period:

-   Event Start: The time (in hours & minutes) the vehicle stopped or began idling
-   Location: Where the stop or idling event occurred
-   Event Stop: The time (in hours & minutes) the vehicle starting moving
-   Event Duration: Length of time (in hours & minutes) the vehicle stopped (engine off & on)
-   Event: Engine off; or Engine on, speed zero
-   Map: View the location of the stop or idling on the map
-   Street View: View the location of the stop or idling in Street View

As in the Stops Report and Idling Report, red pins indicate stops and blue pins indicate idling.

In addition, the Stops/Idling Report can be filtered to only display stops and idling events greater or lesser than a certain length of time in minutes. The default is greater than 1 minute.

1.  Click on the **down arrow** and select either > (greater than) or < (less than).
2.  Type the number of minutes in the text box.
3.  Click on the green **refresh**

The table will be refreshed with the filtered data.

To export the data as .csv or .xls format, click on the **Export** icon above the far right column. See How do I export a report? for more information.

### View all stops/idling events on the map

In Table view, click on the **Map** The map will include all the stops and idling specified in the Report Generator and Duration filter.

Stops may be clustered on the map when viewing the area small scale.

Use the Google tools to zoom in to see the stops and idling locations.

To view the map in full screen, click on the **Full Screen** icon in the top left-hand corner.

To see details of the stop/idling (vehicle/driver, location, start and end times, and duration), hover the cursor over the red/blue pin and the details will pop up.

To scroll through the stop/idling events, click on **Previous Stops/Idling** or **Next Stops/Idling.**

**Note:** Depending on the type of the first event (stop or idling) or one selected on the map, the Previous/Next will scroll through either stops or idling.

To exit the full screen mode, click on the icon again or press the **ESC** key on your keyboard.

### View a stop/idling individually on the map

To view an individual stop/idling location on the map, click the **Map** icon (red pin for stop or blue pin for idling) at the end of the row.

To scroll through the stop/idling events on the map, click on **Previous Stop/Idling** or **Next Stop/Idling**.

To view the map in full screen, click on the **Full Screen** icon in the top left-hand corner.

To return to the table view, click on the **Table**.

To view an individual stop/idling location in Street View, click **Pegman** at the end of the row in the table, or drag and drop Pegman onto the map.

To scroll through the stop/idling events in Street View, click on **Previous Stop/Idling** or **Next Stop/Idling**.

To return to the Map view, click the **left** **arrow** in the left-hand corner of the screen.

To return to the Table view, click on the **Table** tab.
