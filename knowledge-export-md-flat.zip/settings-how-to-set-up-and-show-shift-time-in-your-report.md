# Settings - How to set up and show shift time in your report ?

Back to home

1.  Knowledge Base 
3.  Reports 
5.  Reports 

-   Logging-in to your Transpoco account
    -   Login to your Transpoco account
    -   Transpoco Smartphone Apps
    -   2 Factor Authentication
    -   System requirements
    -   Overview of Transpoco
    -   Implementation
-   How to organise your account to achieve the best results
    
-   How to use each feature - step by step guides
    -   Users and permissions
    -   Walkaround Checks module
    -   Fuel/Electric Vehicles Module
    -   Maintain Module
    -   Dashboard
    -   Messaging module
    -   Scheduled Reports
-   How to Order More Trackers
    
-   Live Map
    
-   Cameras
    -   FAQ
-   Webinar Videos
    
-   Walkaround Checklists
    -   Walkaround Checklists
    -   Driver App
    -   Alerts
-   Reports
    -   Reports
    -   Viewing data in reports
-   Fuel
    
-   Dashboard
    
-   Maintain Module
    
-   Driving Style
    
-   Locations
    
-   Cost Management (TCO) Report
    
-   The Notification Features
    
-   Hardware and Installation
    
-   Removal & Repair of Hardware
    -   Requesting a Repair or a Deinstallation
-   Cameras & GDPR Guidelines
    
-   Scheduled Reports
    
-   Safety Program
    
-   Fleet Manager App
    
-   Users & Permissions
    
-   Alerts
    
-   Policies & Documents
    
-   Privacy Policy and Terms & Conditions
    -   RoPA
-   API
    
-   Transpoco User Manuals
    
-   Settings
    -   Garage
-   Whats New?
    
-   Account Mangement Services
    
-   Driver ID process
    
-   Security
    
-   Transpoco Locate
    
-   Subscriptions & Invoices
    
-   Tutorial videos
    
-   Cancelling your account
    
-   VOR
    
-   Installation
    
-   BIKLY
    

# Settings - How to set up and show shift time in your report ?

## You could set up your customized shift time, and also filter out your fleet reports by the specific shift time that you set up in your Transpoco Synx account.

1.  Log in to your Transpoco Synx account.
2.  Click on the Settings > Company details > Shift Time.  
    
3.  You will see the shift time set up page.  
    
4.  There are **two default shift time settings** in your account.  
      
    One is **working hours (09:00 - 16:59, Monday to Friday)** :  
      
    The other one is **Outside working hours (00:00 - 08:59 & 17:00 - 23:59, Monday to Friday + the whole weekend)** :  
    
5.  You could always add new customized shift time by clicking on the “+ New Shift TIme.
6.  Choose your own shift time and then click “Confirm” to save it.   
    
7.  Then it will appear in the shift time page.  
    
8.  You could always view or delete any shit time including the default ones.  
      
    
9.  You can also edit the name by clicking on the name description twice. It will allow you to edit the name of it.  
      
    
10.  If you have too many shift time options you can change pages either by clicking “Next” and “Previous” OR by clicking on the page numbers.  
       
     
11.  You could change the number of rows as well by clicking on .

#### **After setting up your customized shift time, you can filter your fleet reports by them now.** 

**Note:** Only the following reports have the shift time available:

**In Live Map:**

-   Fleet Summary Report
-   Summary Report
-   Journeys Report
-   Idling Report
-   Stops Report
-   Stop / Idling Report

**In Service > Analytics:**

-   Schedule Report (for the journey report only)

  
11.  Click on the Services > Live Map, then choose any report type from the options listed in the Note above . 

12.   You will see the “Limit by shift time ” option below the calendar. 

13.   Then tick the box and you could choose the shift time that you want to limit your report by. 

14.    You can view the report by clicking on the button now.
