# Reports

Back to home

1.  Knowledge Base 
3.  Reports 

-   Logging-in to your Transpoco account
    -   Login to your Transpoco account
    -   Transpoco Smartphone Apps
    -   2 Factor Authentication
    -   System requirements
    -   Overview of Transpoco
    -   Implementation
-   How to organise your account to achieve the best results
    
-   How to use each feature - step by step guides
    -   Users and permissions
    -   Walkaround Checks module
    -   Fuel/Electric Vehicles Module
    -   Maintain Module
    -   Dashboard
    -   Messaging module
    -   Scheduled Reports
-   How to Order More Trackers
    
-   Live Map
    
-   Cameras
    -   FAQ
-   Webinar Videos
    
-   Walkaround Checklists
    -   Walkaround Checklists
    -   Driver App
    -   Alerts
-   Reports
    -   Reports
    -   Viewing data in reports
-   Fuel
    
-   Dashboard
    
-   Maintain Module
    
-   Driving Style
    
-   Locations
    
-   Cost Management (TCO) Report
    
-   The Notification Features
    
-   Hardware and Installation
    
-   Removal & Repair of Hardware
    -   Requesting a Repair or a Deinstallation
-   Cameras & GDPR Guidelines
    
-   Scheduled Reports
    
-   Safety Program
    
-   Fleet Manager App
    
-   Users & Permissions
    
-   Alerts
    
-   Policies & Documents
    
-   Privacy Policy and Terms & Conditions
    -   RoPA
-   API
    
-   Transpoco User Manuals
    
-   Settings
    -   Garage
-   Whats New?
    
-   Account Mangement Services
    
-   Driver ID process
    
-   Security
    
-   Transpoco Locate
    
-   Subscriptions & Invoices
    
-   Tutorial videos
    
-   Cancelling your account
    
-   VOR
    
-   Installation
    
-   BIKLY
    

# Reports

###### 

-   Canbus reports available: Fuel Used and Plant Utilisation

#### Reports

###### 

-   How do I view the total distance driven in business and private mode for a specific period?
-   What reports are available in Transpoco?
-   What is the Journeys Report?
-   What is the Fleet Summary Report?
-   What is the Summary Report?
-   What is the Last Location Report?
-   What is the Stops Report?
-   What is the Idling Report?
-   What is the Stops/Idling Report?
-   \[Fleet Summary Export\] - How do I add extra columns to the export of my Fleet Summary Report?
-   Fleet Summary - How do I filter my fleet Summary by Weekdays or Weekends?
-   \[Fleet Summary Scheduled Report\] - How to add additional vehicle columns to your Fleet Summary Schedule Report?
-   Settings - How to set up and show shift time in your report ?
-   Temperature Monitoring
-   Electric Vehicle Reports (Canbus)
-   What is the Alerts Report?
-   How to view mileage or odometer for a past date

See more

#### Viewing data in reports

###### 

-   How to view data in reports?
