# [Speed Summary Detail Scheduled Report] - How to see the details of my speed summary?

Back to home

1.  Knowledge Base 
3.  Scheduled Reports 

-   Logging-in to your Transpoco account
    -   Login to your Transpoco account
    -   Transpoco Smartphone Apps
    -   2 Factor Authentication
    -   System requirements
    -   Overview of Transpoco
    -   Implementation
-   How to organise your account to achieve the best results
    
-   How to use each feature - step by step guides
    -   Users and permissions
    -   Walkaround Checks module
    -   Fuel/Electric Vehicles Module
    -   Maintain Module
    -   Dashboard
    -   Messaging module
    -   Scheduled Reports
-   How to Order More Trackers
    
-   Live Map
    
-   Cameras
    -   FAQ
-   Webinar Videos
    
-   Walkaround Checklists
    -   Walkaround Checklists
    -   Driver App
    -   Alerts
-   Reports
    -   Reports
    -   Viewing data in reports
-   Fuel
    
-   Dashboard
    
-   Maintain Module
    
-   Driving Style
    
-   Locations
    
-   Cost Management (TCO) Report
    
-   The Notification Features
    
-   Hardware and Installation
    
-   Removal & Repair of Hardware
    -   Requesting a Repair or a Deinstallation
-   Cameras & GDPR Guidelines
    
-   Scheduled Reports
    
-   Safety Program
    
-   Fleet Manager App
    
-   Users & Permissions
    
-   Alerts
    
-   Policies & Documents
    
-   Privacy Policy and Terms & Conditions
    -   RoPA
-   API
    
-   Transpoco User Manuals
    
-   Settings
    -   Garage
-   Whats New?
    
-   Account Mangement Services
    
-   Driver ID process
    
-   Security
    
-   Transpoco Locate
    
-   Subscriptions & Invoices
    
-   Tutorial videos
    
-   Cancelling your account
    
-   VOR
    
-   Installation
    
-   BIKLY
    

# \[Speed Summary Detail Scheduled Report\] - How to see the details of my speed summary?

## You are able to see the details of your drivers' speeding like where these events are mostly happening, speed limit, speed over the limit, percentage over the limit, etc.

1.  Log in to your Transpoco account.
    1.  Click the Services > Analytics > Scheduled Reports.  
          
        3.   You will see the Scheduled Report page.   
          
        
        4.   Then click on the “+ Add New Schedule Report” .
        
          5.   Firstly, you need to add a subject and a description.
        
          6.   Then select the Report Types "Speed Summary Detail"  
          
        **Note: You can run this report for one vehicle/driver only, not for a group as there is too much data to be displayed and wouldn't be readable to do it for many vehicles/drivers at once.**   
          
        
        7\. Then click on the “Next” button .
        
        8.   Then set up the following options, Schedule period, Schedule Time, File Format, Report Language, Time Zone and Distance Unit. 
        
          Note: The CSV is the only format option available for this specific report.
        
        9.   Then click on the “Next” button  again.  
         10.   Then choose the users who would like to receive the report based on scheduled period and time; as well as the users who can manage the schedule report.   
        
         11.   Click on the “Confirm”  once you are done.
        
        12\. The report will look like the one below:
