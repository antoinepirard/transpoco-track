# What reports are available in Transpoco?

Back to home

1.  Knowledge Base 
3.  Reports 
5.  Reports 

-   Logging-in to your Transpoco account
    -   Login to your Transpoco account
    -   Transpoco Smartphone Apps
    -   2 Factor Authentication
    -   System requirements
    -   Overview of Transpoco
    -   Implementation
-   How to organise your account to achieve the best results
    
-   How to use each feature - step by step guides
    -   Users and permissions
    -   Walkaround Checks module
    -   Fuel/Electric Vehicles Module
    -   Maintain Module
    -   Dashboard
    -   Messaging module
    -   Scheduled Reports
-   How to Order More Trackers
    
-   Live Map
    
-   Cameras
    -   FAQ
-   Webinar Videos
    
-   Walkaround Checklists
    -   Walkaround Checklists
    -   Driver App
    -   Alerts
-   Reports
    -   Reports
    -   Viewing data in reports
-   Fuel
    
-   Dashboard
    
-   Maintain Module
    
-   Driving Style
    
-   Locations
    
-   Cost Management (TCO) Report
    
-   The Notification Features
    
-   Hardware and Installation
    
-   Removal & Repair of Hardware
    -   Requesting a Repair or a Deinstallation
-   Cameras & GDPR Guidelines
    
-   Scheduled Reports
    
-   Safety Program
    
-   Fleet Manager App
    
-   Users & Permissions
    
-   Alerts
    
-   Policies & Documents
    
-   Privacy Policy and Terms & Conditions
    -   RoPA
-   API
    
-   Transpoco User Manuals
    
-   Settings
    -   Garage
-   Whats New?
    
-   Account Mangement Services
    
-   Driver ID process
    
-   Security
    
-   Transpoco Locate
    
-   Subscriptions & Invoices
    
-   Tutorial videos
    
-   Cancelling your account
    
-   VOR
    
-   Installation
    
-   BIKLY
    

# What reports are available in Transpoco?

Your Transpoco account comes with a number of reports available to get detailed information about your fleet at your fingertips. Reports are available fleet-wide, by vehicle group or by vehicle. **Reports can be pulled for period of 3 months at a time** and go back to the date of installation of each vehicle. Our reports include: 

**Last Location**:

This report displays the last location of the vehicle or vehicles. It is the most up-to-date information about where your vehicles are and what they're doing. You can see this both on the map or by selecting the Reports tab as a data set.

-   *Default data points include*: Vehicle, Date & Time, Location, Speed, Engine status, Odometer, GPS Signal Strength and GSM Signal Strength.

Click here for more details on the Last Location Report 

**Fleet Summary:** 

This report provides basic data about your fleet for the time frame selected. You can view this report as a data set. This report can be exported

-   *Default data points include:* Vehicle description, Vehicle Registration, # of Journeys,Travel Time (HH:MM), Distance, and Idling Time (HH:MM)

Click here for more details on the Fleet Summary Report 

**Summary:** 

This report gives high level details on what a vehicle has done in over the last several days or weeks. The Summary Report presents data on a per vehicle, per day basis over the time frame selected. You can view this report as a data set, chart or route playback. This report can be exported.

-   *Default data points include:* Vehicle Registration, Date, First Start Time, Last Stop Time, Shift Duration,  # of Journeys, Travel Time, Distance, Idling Time, View Route. 

Click here for more details on the Summary Report

**Journeys:** 

This report gives details on each trip from Point A to Point B across the selected time frame. You can view this report as a data set, chart or route playback. This report can be exported.

-   *Default data points include:* Vehicle Registration, Date, Journey Start Time, Journey Start Location, Journey Stop Time, Journey Stop Location, Journey Time, Idling time, Distance, Route Playback

Click here for more details on the Journeys Report 

**Stops, Idling & Stops/Idling:** 

These reports give details of stops, idling and an aggregate of stops & idle. Stops are when a vehicle is stopped and off, whereas idle is when a vehicle is stopped and on. Each of these reports is set to a time threshold, which you can set just above the data. For example, the stop threshold is 1 minute of being stopped and off, whereas the idle threshold is 10 minutes of being stopped and on. These reports can be shown as a data set or as a map. These reports can be exported.

-   *Default data points include*: Date, Vehicle, Stop or Idle Time Begin, Stop or Idle Location, Stop or Idle Time End, Stop or Idle Duration, Map Pin, StreetView. 

Click here for more details on the Stops Reports

Click here for more details on the Idling Report

Click here for more details on the Stops/Idling Report 

**Locations:** 

This report allows you to pull data on the Locations you've set up on the system. It details when a vehicle enters, stops and exits your chosen location over the selected time frame. 

-   *Default data points include:* Date, Vehicle, Event Time Begin, Location, Event Time End, Event Duration, Event Type, Map Route

Click here for more details on the Locations Report 

**Alerts:** 

This report details alerts that have been triggered based on your alerts settings over the selected time frame. This report can be exported. 

-   *Default data points include:* Vehicle, Alert Type, Date, Start Time, Stop Time, Duration, Location, Speed, Road Type, Map, Streeview

Click here for more details on the Alerts Report 

*For reports related to optional features, please see our optional features articles.*
