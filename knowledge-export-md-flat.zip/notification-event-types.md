# Notification Event Types

Back to home

1.  Knowledge Base 
3.  The Notification Features 

-   Logging-in to your Transpoco account
    -   Login to your Transpoco account
    -   Transpoco Smartphone Apps
    -   2 Factor Authentication
    -   System requirements
    -   Overview of Transpoco
    -   Implementation
-   How to organise your account to achieve the best results
    
-   How to use each feature - step by step guides
    -   Users and permissions
    -   Walkaround Checks module
    -   Fuel/Electric Vehicles Module
    -   Maintain Module
    -   Dashboard
    -   Messaging module
    -   Scheduled Reports
-   How to Order More Trackers
    
-   Live Map
    
-   Cameras
    -   FAQ
-   Webinar Videos
    
-   Walkaround Checklists
    -   Walkaround Checklists
    -   Driver App
    -   Alerts
-   Reports
    -   Reports
    -   Viewing data in reports
-   Fuel
    
-   Dashboard
    
-   Maintain Module
    
-   Driving Style
    
-   Locations
    
-   Cost Management (TCO) Report
    
-   The Notification Features
    
-   Hardware and Installation
    
-   Removal & Repair of Hardware
    -   Requesting a Repair or a Deinstallation
-   Cameras & GDPR Guidelines
    
-   Scheduled Reports
    
-   Safety Program
    
-   Fleet Manager App
    
-   Users & Permissions
    
-   Alerts
    
-   Policies & Documents
    
-   Privacy Policy and Terms & Conditions
    -   RoPA
-   API
    
-   Transpoco User Manuals
    
-   Settings
    -   Garage
-   Whats New?
    
-   Account Mangement Services
    
-   Driver ID process
    
-   Security
    
-   Transpoco Locate
    
-   Subscriptions & Invoices
    
-   Tutorial videos
    
-   Cancelling your account
    
-   VOR
    
-   Installation
    
-   BIKLY
    

# Notification Event Types

## In this article we will explain where you can view your notifications and the meaning of each type of notification event.

The Notifications page will work like a "Hardware Health Check" page where you can see issues with your tracker units and/or camera and /or driver identification.

1\. Click **"Notifications"** in your account (see the screenshot below).

2\. You can see a table in the Notifications page that includes: vehicle, make/model, date of event, category, event type, event duration, status and notes. 

Notifications-1

**Note:** Open notifications will be indicated by a bell icon along with a number in a red circle indicating the number of open notifications.

  3.   You can filter this table by categories, there are three categories available now: **camera, tracker** and **driver ID.**  

driver

  4.   You can also filter this table by event type:

**Note:** The notifications cover all hardware; trackers, driver ID readers and cameras, and but do not apply to all customers. For example, if you don’t have cameras in your vehicles, then you will not receive notifications relating to cameras.

#### Definition of the event types: 

          **Event Type**

     **Unit type**

                                      **Definition**

**No device update**

Tracker

When the tracker unit stops sending updates over 7 days

**No GPS Signal**

Tracker

The tracker stopped functioning, temporarily (336h or 14 days) or permanently, due to a lack of a GPS signal.

**Memory exception alarm/Abnormal storage alarm**

Camera

Memory exception alarm is due to the storage card is broken or some partition is broken.  

-   **SD card read and write exception**  
    It should be that a faulty area of the memory card was read during boot up or poor contact, which caused this alarm.  If the alarm still persists after restarting, it is necessary to replace the memory card.

-   **SD Card Full**  
    It may be caused by too many locked alarm videos, and the storage space of the device needs to be checked.

**Recording failed**

Camera (VisionTrack model)

When there is a video request that could not be retrieved.

**Video lost**

Camera

It means we are displaying only 1 of the channels. That's mainly because you enable the channel and without any real camera, or the camera connection is not stable. It always happens when the IP settings wrong on IP Camera, or the camera has hardware connection issue.

**Abnormal boot alarm**

Camera

Abnormal Storage Alarm is due to the storage not installed or missing one installed.  

-   **SD Card Not Exist**  
    When the device supports two storage devices, if the device does not enable recording involving sub storage devices, no alarm will be generated for the sub storage devices. If the device enables recording of main and sub streams, if either storage device is abnormal, the corresponding storage fault alarm will be triggered.

**Camera down**

Camera

When the camera stops sending updates for over 12h and the vehicle has been driven over 10km

**Illegal Shutdown**

Camera

llegal shutdown is triggered when you disconnect the power directly, so if the vehicle power is very low when the vehicle stops, it's also the same situation as you disconnect the power directly.  
  
When you are installing the device, need to use a voltmeter to test the power supply to make sure there will be no problem. 

**Driver ID not assigned**

Driver ID

When a driver ID has been used but has not been assigned to a driver.

To resolve this issue assign the serial number of the driver to a driver and close the notification.

**Non company driver ID used**

Driver ID

When a driver ID has been used and is currently assigned to a driver from a different company (in cases where the customer has 2 or more Transpoco accounts).

5.   You can filter this table by vehicle groups.

vehicle

6.   You can also filter this table by searching any particular fields that you are looking for, as long as it is included in the table. 

filter

7.   You can choose the number of rows in the table and also be able to click “Next” and  “Previous‘ options as well. 

Previous

8.   At last, you can download the table in CSV format by clicking on this button.CSV.

9\. After an event has been resolved click **'Close Notification'**  and the number of open events will reduce by 1.The event will disappear from the list of open notifications.
