# How to see live details about a vehicle?

Back to home

1.  Knowledge Base 
3.  Fleet Manager App 

-   Logging-in to your Transpoco account
    -   Login to your Transpoco account
    -   Transpoco Smartphone Apps
    -   2 Factor Authentication
    -   System requirements
    -   Overview of Transpoco
    -   Implementation
-   How to organise your account to achieve the best results
    
-   How to use each feature - step by step guides
    -   Users and permissions
    -   Walkaround Checks module
    -   Fuel/Electric Vehicles Module
    -   Maintain Module
    -   Dashboard
    -   Messaging module
    -   Scheduled Reports
-   How to Order More Trackers
    
-   Live Map
    
-   Cameras
    -   FAQ
-   Webinar Videos
    
-   Walkaround Checklists
    -   Walkaround Checklists
    -   Driver App
    -   Alerts
-   Reports
    -   Reports
    -   Viewing data in reports
-   Fuel
    
-   Dashboard
    
-   Maintain Module
    
-   Driving Style
    
-   Locations
    
-   Cost Management (TCO) Report
    
-   The Notification Features
    
-   Hardware and Installation
    
-   Removal & Repair of Hardware
    -   Requesting a Repair or a Deinstallation
-   Cameras & GDPR Guidelines
    
-   Scheduled Reports
    
-   Safety Program
    
-   Fleet Manager App
    
-   Users & Permissions
    
-   Alerts
    
-   Policies & Documents
    
-   Privacy Policy and Terms & Conditions
    -   RoPA
-   API
    
-   Transpoco User Manuals
    
-   Settings
    -   Garage
-   Whats New?
    
-   Account Mangement Services
    
-   Driver ID process
    
-   Security
    
-   Transpoco Locate
    
-   Subscriptions & Invoices
    
-   Tutorial videos
    
-   Cancelling your account
    
-   VOR
    
-   Installation
    
-   BIKLY
    

# How to see live details about a vehicle?

## How to view details about the vehicle, including location and driver, by tapping on a vehicle on the live map in the SynX Fleet Manager App

Touch the vehicle on the map and the following vehicle’s details are shown at the bottom of the screen.  

-   Vehicle registration number
-   Date and time of last update
-   Vehicle speed
-   Driver’s name
-   Vehicle status (this may need to be added)
-   Location of vehicle

In addition, the following functionality is available on the screen:

-   Route playback (link to Journey Report of vehicle’s journeys that day or selected period)
-   Link to Daily Summary Report
-   Get Directions (from selected location to the vehicle’s location in Google Maps)
-   Call (driver)
-   Text (driver)

Vehicle details
