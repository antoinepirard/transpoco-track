# Walkaround Checks: How do I create an accident report using the Transpoco Driver app?

Back to home

1.  Knowledge Base 
3.  Walkaround Checklists 
5.  Driver App 

-   Logging-in to your Transpoco account
    -   Login to your Transpoco account
    -   Transpoco Smartphone Apps
    -   2 Factor Authentication
    -   System requirements
    -   Overview of Transpoco
    -   Implementation
-   How to organise your account to achieve the best results
    
-   How to use each feature - step by step guides
    -   Users and permissions
    -   Walkaround Checks module
    -   Fuel/Electric Vehicles Module
    -   Maintain Module
    -   Dashboard
    -   Messaging module
    -   Scheduled Reports
-   How to Order More Trackers
    
-   Live Map
    
-   Cameras
    -   FAQ
-   Webinar Videos
    
-   Walkaround Checklists
    -   Walkaround Checklists
    -   Driver App
    -   Alerts
-   Reports
    -   Reports
    -   Viewing data in reports
-   Fuel
    
-   Dashboard
    
-   Maintain Module
    
-   Driving Style
    
-   Locations
    
-   Cost Management (TCO) Report
    
-   The Notification Features
    
-   Hardware and Installation
    
-   Removal & Repair of Hardware
    -   Requesting a Repair or a Deinstallation
-   Cameras & GDPR Guidelines
    
-   Scheduled Reports
    
-   Safety Program
    
-   Fleet Manager App
    
-   Users & Permissions
    
-   Alerts
    
-   Policies & Documents
    
-   Privacy Policy and Terms & Conditions
    -   RoPA
-   API
    
-   Transpoco User Manuals
    
-   Settings
    -   Garage
-   Whats New?
    
-   Account Mangement Services
    
-   Driver ID process
    
-   Security
    
-   Transpoco Locate
    
-   Subscriptions & Invoices
    
-   Tutorial videos
    
-   Cancelling your account
    
-   VOR
    
-   Installation
    
-   BIKLY
    

# Walkaround Checks: How do I create an accident report using the Transpoco Driver app?

## How to use the Drivers app to create a report after a vehicle accident.

From the Walkaround Home Page, tap on **Start Walkaround**.

Either scroll down the full list of vehicles or search for a vehicle by typing in part or all of a registration number or vehicle/driver name in the search box.

Screenshot\_20190727\_145518\_com.synx.driver

Tap on the required **vehicle**.

A list of available walkaround checklists is presented.

Screenshot\_20190725\_150619\_com.synx.driver

Select **Accident Form**.

Screenshot\_20190725\_142115\_com.synx.driver

You can select any section of the form above; as each section is completed, it will come off the list. **Note:** For the purpose of this user guide, the sections are completed in order.

#### Accident

Select **Accident**.

There now follows a series of questions about the interior of the vehicle – each question must be answered to continue to the next, which will appear automatically.

Enter the date and time of the accident. This can be in any format, e.g. 13/07/2019 13:50.

Screenshot\_20190725\_142127\_com.synx.driver

Type in the exact location of the accident or, if you are at the scene of the accident, tap on the **location pin** and the address will be added for you.

The first time you use SynX Driver on your smartphone, the app will ask permission to access your phone’s location. Select **Allow**.

Screenshot\_20190725\_142127\_com.synx.driver     Screenshot\_20190725\_142217\_com.google.android.packageinstaller

Tap the green **tick**.

Type in the textbox the type of road on which the accident occurred.

Tap the green **tick**.

Screenshot\_20190725\_142534\_com.synx.driver     Screenshot\_20190725\_142548\_com.synx.driver

Tap on either **Wet**, **Dry** or **Frost** to match the weather conditions at the time of the accident.

The Accident section is now complete and the app returns to the Accident Report main page.

Screenshot\_20190725\_142611\_com.synx.driver

#### Description

Select **Description**.

Type in details of the accident including the Third Party’s details if available.

Screenshot\_20190728\_124242\_com.synx.driver

Tap the green **tick**.

The Description section is now complete and the app returns to the Accident Report main page.

Screenshot\_20190725\_142808\_com.synx.driver

#### Damage

Select **Damage**.

If the company vehicle is undamaged, tap the **green tick** or **swipe right** and the app will advance to the Accident Form menu.

If the company vehicle is damaged, tap on the **red cross** or **swipe left** to record the damage.

In the pop-up text box, type details of the damage to the vehicle.

Screenshot\_20190725\_142823\_com.synx.driver    Screenshot\_20190728\_130020\_com.synx.driver

Add a photo of the defect by tapping on **Photo**.

**NOTE:** For instructions on how to add a photo from your camera's library or by taking a photo, see Walkaround Checks: How to do I add a photo to the SynX Driver app?

Tap on the green **Save** button.

The app will automatically advance to the next question.

Screenshot\_20190728\_162156\_com.synx.driver

Repeat steps above for recording damage and adding photographic evidence.

The Damage section is now complete and the app returns to the Accident Report main page.

Screenshot\_20190725\_142941\_com.synx.driver

#### Garda / Police

Select **Garda**.

Enter details of Garda attendance/reporting; if not applicable, enter ‘No Garda’ or ‘N/A’.

Screenshot\_20190725\_143019\_com.synx.driver

Tap on the green **tick**.

The Garda section is now complete and the app returns to the Accident Report main page.

Screenshot\_20190725\_143028\_com.synx.driver

#### Other

Select **Other**.

If you have further information and/or photos to add, tap the **red cross** or **swipe left**; Otherwise, tap the **green tick** or **swipe right** and the app will advance to the Accident Report main page.

Screenshot\_20190725\_143054\_com.synx.driver

Repeat the steps to add notes and photos as per the other sections.

The Other section is now complete and the app returns to the Accident Report main page.

Screenshot\_20190725\_143104\_com.synx.driver

#### Insurance

Select **Insurance**.

Screenshot\_20190725\_143121\_com.synx.driver

Tap the **camera** icon and your camera will open.

The first time you use SynX Driver on your smartphone, the app will ask permission to take and access photos and videos. Select **Allow** on both screens.

Screenshot\_20190725\_143341\_com.google.android.packageinstaller     Screenshot\_20190725\_143352\_com.google.android.packageinstaller

Take a photo of the front of your insurance form.

Tap the **tick** in the top right corner. The photo will automatically upload to the Notes page.

Type in brief details about the photo being submitted.

Screenshot\_20190728\_205337\_com.synx.driver

Tap on **Save**.

Screenshot\_20190728\_205348\_com.synx.driver

Tap on the **red cross** or **swipe left** to enter details and a photo of the rear of the form.

Repeat the steps above for submitting notes and photo.

Send a hard copy of the insurance form to your Fleet Manager.

The Insurance section is now complete.

Once all six sections have been completed, the app shows the following screen.

Screenshot\_20190725\_143616\_com.synx.driver

Type any comments or provide further details in the text box if desired.

To submit the Accident Checklist without reviewing, tap on **Submit Checklist**.

To review the Accident Checklist before submitting, tap on **Review Checklist**.

Scroll down to review each declaration. Click on **Edit** for any item that requires amending or additional information.

Screenshot\_20190725\_143635\_com.synx.driver

Scroll to the end of the checklist and tap on **Submit Checklist**.

Screenshot\_20190725\_153432\_com.synx.driver
