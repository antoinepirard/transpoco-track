# What is the Summary Report?

Back to home

1.  Knowledge Base 
3.  Reports 
5.  Reports 

-   Logging-in to your Transpoco account
    -   Login to your Transpoco account
    -   Transpoco Smartphone Apps
    -   2 Factor Authentication
    -   System requirements
    -   Overview of Transpoco
    -   Implementation
-   How to organise your account to achieve the best results
    
-   How to use each feature - step by step guides
    -   Users and permissions
    -   Walkaround Checks module
    -   Fuel/Electric Vehicles Module
    -   Maintain Module
    -   Dashboard
    -   Messaging module
    -   Scheduled Reports
-   How to Order More Trackers
    
-   Live Map
    
-   Cameras
    -   FAQ
-   Webinar Videos
    
-   Walkaround Checklists
    -   Walkaround Checklists
    -   Driver App
    -   Alerts
-   Reports
    -   Reports
    -   Viewing data in reports
-   Fuel
    
-   Dashboard
    
-   Maintain Module
    
-   Driving Style
    
-   Locations
    
-   Cost Management (TCO) Report
    
-   The Notification Features
    
-   Hardware and Installation
    
-   Removal & Repair of Hardware
    -   Requesting a Repair or a Deinstallation
-   Cameras & GDPR Guidelines
    
-   Scheduled Reports
    
-   Safety Program
    
-   Fleet Manager App
    
-   Users & Permissions
    
-   Alerts
    
-   Policies & Documents
    
-   Privacy Policy and Terms & Conditions
    -   RoPA
-   API
    
-   Transpoco User Manuals
    
-   Settings
    -   Garage
-   Whats New?
    
-   Account Mangement Services
    
-   Driver ID process
    
-   Security
    
-   Transpoco Locate
    
-   Subscriptions & Invoices
    
-   Tutorial videos
    
-   Cancelling your account
    
-   VOR
    
-   Installation
    
-   BIKLY
    

# What is the Summary Report?

This report gives high level details on what a vehicle has done in over the last several days or weeks. The Summary Report presents data on a per vehicle, per day basis over the time frame selected. You can view this report as a data set, chart or route playback. This report can be exported.

-   *Default data points include:* Vehicle Registration, Date, First Start Time, Last Stop Time, Shift Duration,  # of Journeys, Travel Time, Distance, Idling Time, View Route. 

This is the Table view of the Summary Report: 

This is the Chart view of the Summary Report:
