# Dashboard

Back to home

1.  Knowledge Base 
3.  Dashboard 

-   Logging-in to your Transpoco account
    -   Login to your Transpoco account
    -   Transpoco Smartphone Apps
    -   2 Factor Authentication
    -   System requirements
    -   Overview of Transpoco
    -   Implementation
-   How to organise your account to achieve the best results
    
-   How to use each feature - step by step guides
    -   Users and permissions
    -   Walkaround Checks module
    -   Fuel/Electric Vehicles Module
    -   Maintain Module
    -   Dashboard
    -   Messaging module
    -   Scheduled Reports
-   How to Order More Trackers
    
-   Live Map
    
-   Cameras
    -   FAQ
-   Webinar Videos
    
-   Walkaround Checklists
    -   Walkaround Checklists
    -   Driver App
    -   Alerts
-   Reports
    -   Reports
    -   Viewing data in reports
-   Fuel
    
-   Dashboard
    
-   Maintain Module
    
-   Driving Style
    
-   Locations
    
-   Cost Management (TCO) Report
    
-   The Notification Features
    
-   Hardware and Installation
    
-   Removal & Repair of Hardware
    -   Requesting a Repair or a Deinstallation
-   Cameras & GDPR Guidelines
    
-   Scheduled Reports
    
-   Safety Program
    
-   Fleet Manager App
    
-   Users & Permissions
    
-   Alerts
    
-   Policies & Documents
    
-   Privacy Policy and Terms & Conditions
    -   RoPA
-   API
    
-   Transpoco User Manuals
    
-   Settings
    -   Garage
-   Whats New?
    
-   Account Mangement Services
    
-   Driver ID process
    
-   Security
    
-   Transpoco Locate
    
-   Subscriptions & Invoices
    
-   Tutorial videos
    
-   Cancelling your account
    
-   VOR
    
-   Installation
    
-   BIKLY
    

# Dashboard

###### 

-   Fleet Cost Management (TCO)
-   Overall metrics - Dashboard
-   What is the Dashboard?
-   How do I edit a metric in the Dashboard?
-   How do I add a new metric to the Dashboard?
-   How can I compare metric data from two periods in the Dashboard?
-   How do I delete a metric from the Dashboard?
-   How do I show/hide graph data in the Dashboard metrics?
-   How do I fix a Dashboard metric error?
-   What information does a Dashboard metric contain?
-   How do I refresh the Dashboard and metrics?
-   How can I move and resize metrics in the Dashboard?
-   How do I access the Dashboard?
-   Dashboard - How do I check the Average Fuel Consumption by vehicle group?
-   Average fuel consumption metric in the Dashboard
-   Dashboard - Driving Summary Score
-   Camera - Dashboard
-   Dashboard - How do I check the percentage of Driver ID usage per vehicle group?
-   Tableau de bord - Comment contrôler le pourcentage d’utilisation del’Identification Conducteur par véhicule
-   New Dashboard UI
