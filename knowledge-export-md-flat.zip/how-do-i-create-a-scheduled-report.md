# How do I create a scheduled report?

Back to home

1.  Knowledge Base 
3.  How to use each feature - step by step guides 
5.  Scheduled Reports 

-   Logging-in to your Transpoco account
    -   Login to your Transpoco account
    -   Transpoco Smartphone Apps
    -   2 Factor Authentication
    -   System requirements
    -   Overview of Transpoco
    -   Implementation
-   How to organise your account to achieve the best results
    
-   How to use each feature - step by step guides
    -   Users and permissions
    -   Walkaround Checks module
    -   Fuel/Electric Vehicles Module
    -   Maintain Module
    -   Dashboard
    -   Messaging module
    -   Scheduled Reports
-   How to Order More Trackers
    
-   Live Map
    
-   Cameras
    -   FAQ
-   Webinar Videos
    
-   Walkaround Checklists
    -   Walkaround Checklists
    -   Driver App
    -   Alerts
-   Reports
    -   Reports
    -   Viewing data in reports
-   Fuel
    
-   Dashboard
    
-   Maintain Module
    
-   Driving Style
    
-   Locations
    
-   Cost Management (TCO) Report
    
-   The Notification Features
    
-   Hardware and Installation
    
-   Removal & Repair of Hardware
    -   Requesting a Repair or a Deinstallation
-   Cameras & GDPR Guidelines
    
-   Scheduled Reports
    
-   Safety Program
    
-   Fleet Manager App
    
-   Users & Permissions
    
-   Alerts
    
-   Policies & Documents
    
-   Privacy Policy and Terms & Conditions
    -   RoPA
-   API
    
-   Transpoco User Manuals
    
-   Settings
    -   Garage
-   Whats New?
    
-   Account Mangement Services
    
-   Driver ID process
    
-   Security
    
-   Transpoco Locate
    
-   Subscriptions & Invoices
    
-   Tutorial videos
    
-   Cancelling your account
    
-   VOR
    
-   Installation
    
-   BIKLY
    

# How do I create a scheduled report?

## Here you will find a guide to create Scheduled Reports.

To create a scheduled report, navigate to **Services > Scheduled Reports**

image (30)

In the Scheduled Report page select **+New Scheduled Report** to create a new scheduled report

Choose a name and describe the report and select the vehicle or vehicle group you’d like to report on. Then, choose the reports you’d like to include on your scheduled report. 

E.g.: Click on Report Types and select Services (this is a report regarding your services created in the Maintenance module)

When selecting the ‘Services’ as your chosen Report Type, you will get a message as below which means that the Vehicle and Driver filters are not applied on this type of report.

  
Select how frequently you’d like to receive the report (daily, weekly or monthly), time of the day, file format (PDF or CSV), language, time zone and distance unit (KM or MI).

When selecting ‘Services’ as the Report Type, you will be able to select the Service Status as a filter to your report (All Status, Complete, Pending or Overdue).

  
  

Once you’ve selected all of your desired settings, click on Next to move on to Alert and Permission’s Tab. On this Tab you are able to select who will receive the reports from the dropdown and set the permission to manage the scheduled report created.

Once you’ve selected all of your desired settings, simply click “Save” and your report will be all set.
