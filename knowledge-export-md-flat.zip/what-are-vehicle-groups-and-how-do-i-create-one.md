# What are vehicle groups and how do I create one?

Back to home

1.  Knowledge Base 
3.  Settings 
5.  Garage 

-   Logging-in to your Transpoco account
    -   Login to your Transpoco account
    -   Transpoco Smartphone Apps
    -   2 Factor Authentication
    -   System requirements
    -   Overview of Transpoco
    -   Implementation
-   How to organise your account to achieve the best results
    
-   How to use each feature - step by step guides
    -   Users and permissions
    -   Walkaround Checks module
    -   Fuel/Electric Vehicles Module
    -   Maintain Module
    -   Dashboard
    -   Messaging module
    -   Scheduled Reports
-   How to Order More Trackers
    
-   Live Map
    
-   Cameras
    -   FAQ
-   Webinar Videos
    
-   Walkaround Checklists
    -   Walkaround Checklists
    -   Driver App
    -   Alerts
-   Reports
    -   Reports
    -   Viewing data in reports
-   Fuel
    
-   Dashboard
    
-   Maintain Module
    
-   Driving Style
    
-   Locations
    
-   Cost Management (TCO) Report
    
-   The Notification Features
    
-   Hardware and Installation
    
-   Removal & Repair of Hardware
    -   Requesting a Repair or a Deinstallation
-   Cameras & GDPR Guidelines
    
-   Scheduled Reports
    
-   Safety Program
    
-   Fleet Manager App
    
-   Users & Permissions
    
-   Alerts
    
-   Policies & Documents
    
-   Privacy Policy and Terms & Conditions
    -   RoPA
-   API
    
-   Transpoco User Manuals
    
-   Settings
    -   Garage
-   Whats New?
    
-   Account Mangement Services
    
-   Driver ID process
    
-   Security
    
-   Transpoco Locate
    
-   Subscriptions & Invoices
    
-   Tutorial videos
    
-   Cancelling your account
    
-   VOR
    
-   Installation
    
-   BIKLY
    

# What are vehicle groups and how do I create one?

Vehicle groups are your way to arrange vehicles in your fleet allowing arrange like vehicles for reporting and live tracking needs. Vehicle groups can also help you restrict users to see only their vehicles. 

1.  Log in to your Transpoco account.
2.  Click on Settings > Garage > Vehicle groups.

1.  Then click on “+ Add New Group”. 

1.  Then select the vehicles that you want to add into this new group by clicking the little box at the first column.

**Note: You could also search the vehicles by its reg, make, mod or description by typing the key words in the box above the first row.**

1.  Then click on “Save” at the bottom of the page. 

1.  You can edit the vehicle group by clicking “Edit” right beside each vehicle group.

**Note: Don’t forget to save your changes after you have edited the group.**
