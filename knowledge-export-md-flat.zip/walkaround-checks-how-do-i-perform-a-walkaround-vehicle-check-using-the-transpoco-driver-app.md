# Walkaround Checks: How do I perform a walkaround vehicle check using the Transpoco Driver app?

Back to home

1.  Knowledge Base 
3.  Walkaround Checklists 
5.  Driver App 

-   Logging-in to your Transpoco account
    -   Login to your Transpoco account
    -   Transpoco Smartphone Apps
    -   2 Factor Authentication
    -   System requirements
    -   Overview of Transpoco
    -   Implementation
-   How to organise your account to achieve the best results
    
-   How to use each feature - step by step guides
    -   Users and permissions
    -   Walkaround Checks module
    -   Fuel/Electric Vehicles Module
    -   Maintain Module
    -   Dashboard
    -   Messaging module
    -   Scheduled Reports
-   How to Order More Trackers
    
-   Live Map
    
-   Cameras
    -   FAQ
-   Webinar Videos
    
-   Walkaround Checklists
    -   Walkaround Checklists
    -   Driver App
    -   Alerts
-   Reports
    -   Reports
    -   Viewing data in reports
-   Fuel
    
-   Dashboard
    
-   Maintain Module
    
-   Driving Style
    
-   Locations
    
-   Cost Management (TCO) Report
    
-   The Notification Features
    
-   Hardware and Installation
    
-   Removal & Repair of Hardware
    -   Requesting a Repair or a Deinstallation
-   Cameras & GDPR Guidelines
    
-   Scheduled Reports
    
-   Safety Program
    
-   Fleet Manager App
    
-   Users & Permissions
    
-   Alerts
    
-   Policies & Documents
    
-   Privacy Policy and Terms & Conditions
    -   RoPA
-   API
    
-   Transpoco User Manuals
    
-   Settings
    -   Garage
-   Whats New?
    
-   Account Mangement Services
    
-   Driver ID process
    
-   Security
    
-   Transpoco Locate
    
-   Subscriptions & Invoices
    
-   Tutorial videos
    
-   Cancelling your account
    
-   VOR
    
-   Installation
    
-   BIKLY
    

# Walkaround Checks: How do I perform a walkaround vehicle check using the Transpoco Driver app?

## How to perform a walkaround vehicle check on the Driver app using an HGV, IFI Car/Van/Jeep, LCV or LCV Short, or a Custom Check List.

From the Walkaround Home Page, tap on **Start Walkaround**.

Either scroll down the full list of vehicles or search for a vehicle by typing in part or all of a registration number or vehicle/driver name in the search box.

Screenshot\_20190727\_145518\_com.synx.driver

Tap on the required vehicle.

A list of available walkaround checklists is presented.

Screenshot\_20190725\_150619\_com.synx.driver

Select the relevant walkaround checklist for your vehicle from **HGV**, **IFI Car/Van/Jeep**, **LCV** or **LCV Short**, or select **Custom Check List**.

**Note:** For the purpose of this article, **HGV** has been selected.

When selecting the HGV checklist, you are presented with the option to start with the inside or the outside of the vehicle.

**Note:** For the purpose of this article, ‘Inside’ is selected first.

Screenshot\_20190725\_144936\_com.synx.driver

Select **Inside**.

There now follows a series of questions about the interior of the vehicle – each question must be answered to continue to the next, which will appear automatically.

For each question (except for those that require direct input, such as odometer reading), answer in the positive or negative.

**Note:** The app measures the time taken to answer each question and if it deems the time is too quick, it will produce a pop-up warning. This is to help ensure that the checks on the vehicle are being carried out.

Screenshot\_20190729\_182647\_com.synx.driver     Screenshot\_20190725\_142600\_com.synx.driver

If the response is **positive** (there are no defects), either tap on the **green tick** or **swipe right**.

The app will advance to the next question.

If the response is **negative** (there is a defect), either tap on the **red cross** or **swipe left**.

A Notes page will pop up and the app will ask for details on the defect.

Screenshot\_20190725\_145105\_com.synx.driver

As shown in the above image, type in brief notes about the defect found.

If relevant, add a photo of the defect by selecting **Photo**.

**NOTE:** For instructions on how to add a photo from your camera's library or by taking a photo, see Walkaround Checks: How do I add a photo to the SynX Driver app?

Tap on the green **Save** button.

The app will automatically advance to the next question.

Screenshot\_20190725\_152517\_com.synx.driver

Continue with the rest of the questions for the interior check.

On the final question, enter the number of passengers there will be for that journey; enter 0 if there are no passengers.

After this last question, the app will take you to the Inside/ Outside menu. Select **Outside**.

There now follows a series of questions about the exterior of the vehicle – each question must be answered to continue to the next.

Follow the instructions as per the inside questions above.

When all checks have been completed, the app shows the following screen:

Screenshot\_20190731\_182931\_com.synx.driver

Type any comments or provide further details in the text box if desired.

To submit the Accident Checklist without reviewing, tap on **Submit Checklist**.

To review the Accident Checklist before submitting, tap on **Review Checklist**.

Scroll down to review each check.

Screenshot\_20190729\_183116\_com.synx.driver     Screenshot\_20190729\_183130\_com.synx.driver     Screenshot\_20190729\_183142\_com.synx.driver

Scroll down to review each declaration. Click on **Edit** for any item that requires amending or additional information.

Scroll to the end of the checklist and tap on **Submit Checklist**.

Screenshot\_20190725\_153432\_com.synx.driver
