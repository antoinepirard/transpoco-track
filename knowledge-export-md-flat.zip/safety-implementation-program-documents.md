# Safety Implementation Program Documents

Back to home

1.  Knowledge Base 
3.  Safety Program 

-   Logging-in to your Transpoco account
    -   Login to your Transpoco account
    -   Transpoco Smartphone Apps
    -   2 Factor Authentication
    -   System requirements
    -   Overview of Transpoco
    -   Implementation
-   How to organise your account to achieve the best results
    
-   How to use each feature - step by step guides
    -   Users and permissions
    -   Walkaround Checks module
    -   Fuel/Electric Vehicles Module
    -   Maintain Module
    -   Dashboard
    -   Messaging module
    -   Scheduled Reports
-   How to Order More Trackers
    
-   Live Map
    
-   Cameras
    -   FAQ
-   Webinar Videos
    
-   Walkaround Checklists
    -   Walkaround Checklists
    -   Driver App
    -   Alerts
-   Reports
    -   Reports
    -   Viewing data in reports
-   Fuel
    
-   Dashboard
    
-   Maintain Module
    
-   Driving Style
    
-   Locations
    
-   Cost Management (TCO) Report
    
-   The Notification Features
    
-   Hardware and Installation
    
-   Removal & Repair of Hardware
    -   Requesting a Repair or a Deinstallation
-   Cameras & GDPR Guidelines
    
-   Scheduled Reports
    
-   Safety Program
    
-   Fleet Manager App
    
-   Users & Permissions
    
-   Alerts
    
-   Policies & Documents
    
-   Privacy Policy and Terms & Conditions
    -   RoPA
-   API
    
-   Transpoco User Manuals
    
-   Settings
    -   Garage
-   Whats New?
    
-   Account Mangement Services
    
-   Driver ID process
    
-   Security
    
-   Transpoco Locate
    
-   Subscriptions & Invoices
    
-   Tutorial videos
    
-   Cancelling your account
    
-   VOR
    
-   Installation
    
-   BIKLY
    

# Safety Implementation Program Documents

Please feel free to use this document as a checklist for the implementation of your Fleet Safety System. We have also linked useful documents for you.

Transpoco's Fleet safety program includes monitoring of the following parameters through the use of GPS telemetry, Driver Identification, Walkaround Check app and Artificial intelligence Camera equipment.

Prior to the use of this data; particularly the Camera element, we advise the completion of an in-house program to ensure both you and your staff are aware of the data protection implications. The video below also demonstrates the operation of the camera equipment.

-   -   **Speed over limit**

-   -   **Harsh Braking**

-   -   **Harsh Cornering**

-   -   **Rapid Acceleration**

-   -   **Fobs Usage (Driver Id)**

-   -   **Compliance (checklists)**

-   -   **Driver Distraction**

-   -   **Driver Phone Usage**

-   -   **Driver Fatigue**

-   -   **Driver Yawns**

-   -   **Driver Smoking**

-   -   **Forward Collision**

-   -   **Too Close DIstance**

-   **Presentation of the** Fleet Safety Program **(quick explanation about the workflow and steps)** 

-   Briefing Document
-   Fleet safety Policy Sample
-   DPIA to be completed      
-   **Driver communication and consent** 
-   **Data Protection Impact Assessments UK**
