# Electric Vehicle Reports (Canbus)

Back to home

1.  Knowledge Base 
3.  Reports 
5.  Reports 

-   Logging-in to your Transpoco account
    -   Login to your Transpoco account
    -   Transpoco Smartphone Apps
    -   2 Factor Authentication
    -   System requirements
    -   Overview of Transpoco
    -   Implementation
-   How to organise your account to achieve the best results
    
-   How to use each feature - step by step guides
    -   Users and permissions
    -   Walkaround Checks module
    -   Fuel/Electric Vehicles Module
    -   Maintain Module
    -   Dashboard
    -   Messaging module
    -   Scheduled Reports
-   How to Order More Trackers
    
-   Live Map
    
-   Cameras
    -   FAQ
-   Webinar Videos
    
-   Walkaround Checklists
    -   Walkaround Checklists
    -   Driver App
    -   Alerts
-   Reports
    -   Reports
    -   Viewing data in reports
-   Fuel
    
-   Dashboard
    
-   Maintain Module
    
-   Driving Style
    
-   Locations
    
-   Cost Management (TCO) Report
    
-   The Notification Features
    
-   Hardware and Installation
    
-   Removal & Repair of Hardware
    -   Requesting a Repair or a Deinstallation
-   Cameras & GDPR Guidelines
    
-   Scheduled Reports
    
-   Safety Program
    
-   Fleet Manager App
    
-   Users & Permissions
    
-   Alerts
    
-   Policies & Documents
    
-   Privacy Policy and Terms & Conditions
    -   RoPA
-   API
    
-   Transpoco User Manuals
    
-   Settings
    -   Garage
-   Whats New?
    
-   Account Mangement Services
    
-   Driver ID process
    
-   Security
    
-   Transpoco Locate
    
-   Subscriptions & Invoices
    
-   Tutorial videos
    
-   Cancelling your account
    
-   VOR
    
-   Installation
    
-   BIKLY
    

# Electric Vehicle Reports (Canbus)

## MAPPING EV REAL-TIME BATTERY STATUS REPORTING

These reports are exclusive to CANbus installed electric vehicles

Initial fields are displayed on active map to show vehicle battery status with other standard parameters such as Speed / Location / Driver ID / Battery Level / Charging State etc

ev real time display

And also on the fuel matching popup screen (Battery Level / Charge State):

**Mapping of Charging Infrastructure**

This feature enables the visualized data points where vehicles are being charged and the duration of it being charged. It also provides a report logging all of the charging activity for the vehicles (depending on vehicle type) with location and duration of charge.

**ELECTRIC VEHICLE FLEET MANAGEMENT ALERTS**

There alerts are set up by the customer, see 'alerts' article for more information

Monitor and manage Battery Levels and Charge Points, identify opportunities to improve the fleet functionality by building bespoke alerts / reports on key EV activity

ev alerts
