# How can I check the details of my fuel transactions?

Back to home

1.  Knowledge Base 
3.  Fuel 

-   Logging-in to your Transpoco account
    -   Login to your Transpoco account
    -   Transpoco Smartphone Apps
    -   2 Factor Authentication
    -   System requirements
    -   Overview of Transpoco
    -   Implementation
-   How to organise your account to achieve the best results
    
-   How to use each feature - step by step guides
    -   Users and permissions
    -   Walkaround Checks module
    -   Fuel/Electric Vehicles Module
    -   Maintain Module
    -   Dashboard
    -   Messaging module
    -   Scheduled Reports
-   How to Order More Trackers
    
-   Live Map
    
-   Cameras
    -   FAQ
-   Webinar Videos
    
-   Walkaround Checklists
    -   Walkaround Checklists
    -   Driver App
    -   Alerts
-   Reports
    -   Reports
    -   Viewing data in reports
-   Fuel
    
-   Dashboard
    
-   Maintain Module
    
-   Driving Style
    
-   Locations
    
-   Cost Management (TCO) Report
    
-   The Notification Features
    
-   Hardware and Installation
    
-   Removal & Repair of Hardware
    -   Requesting a Repair or a Deinstallation
-   Cameras & GDPR Guidelines
    
-   Scheduled Reports
    
-   Safety Program
    
-   Fleet Manager App
    
-   Users & Permissions
    
-   Alerts
    
-   Policies & Documents
    
-   Privacy Policy and Terms & Conditions
    -   RoPA
-   API
    
-   Transpoco User Manuals
    
-   Settings
    -   Garage
-   Whats New?
    
-   Account Mangement Services
    
-   Driver ID process
    
-   Security
    
-   Transpoco Locate
    
-   Subscriptions & Invoices
    
-   Tutorial videos
    
-   Cancelling your account
    
-   VOR
    
-   Installation
    
-   BIKLY
    

# How can I check the details of my fuel transactions?

## You can check each detail from a particular fuel transaction done

1\. Click on Services

2\. Click on Fuel Transactions under Fuel menu option

3\. You can select the period, vehicle group and/or vehicle to filter the fuel transactions report

teste-1

4\. You will see every detail from your purchases done during the period selected. E.g.: number of litres, price per litre and total price.

Note: Here is the list of attributes you can extract and filter from your transactions

\* Purchase Time

\* Account Number

\* Provider

\* Card Number

\* Same Day Purchase (yes/no)

\* Card Description

\* Vehicle Declared

\* Vehicle Assigned

\* Mileage Declared

\* Odometer (Km or Mi - according to your user's preference)

\* Product (Diesel, Petrol, Car wash (Leaseplan only), Adblue (Leaseplan only))

\* Litres

\* Price per Litre

\* Total Price

\* Station Name

\* Station Address

\* Registration Status

\* GPS Status

\* Visibility (Visible or Hidden)
