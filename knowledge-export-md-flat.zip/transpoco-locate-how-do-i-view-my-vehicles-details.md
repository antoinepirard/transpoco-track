# Transpoco Locate: How do I view my vehicles' details?

Back to home

1.  Knowledge Base 
3.  Transpoco Locate 

-   Logging-in to your Transpoco account
    -   Login to your Transpoco account
    -   Transpoco Smartphone Apps
    -   2 Factor Authentication
    -   System requirements
    -   Overview of Transpoco
    -   Implementation
-   How to organise your account to achieve the best results
    
-   How to use each feature - step by step guides
    -   Users and permissions
    -   Walkaround Checks module
    -   Fuel/Electric Vehicles Module
    -   Maintain Module
    -   Dashboard
    -   Messaging module
    -   Scheduled Reports
-   How to Order More Trackers
    
-   Live Map
    
-   Cameras
    -   FAQ
-   Webinar Videos
    
-   Walkaround Checklists
    -   Walkaround Checklists
    -   Driver App
    -   Alerts
-   Reports
    -   Reports
    -   Viewing data in reports
-   Fuel
    
-   Dashboard
    
-   Maintain Module
    
-   Driving Style
    
-   Locations
    
-   Cost Management (TCO) Report
    
-   The Notification Features
    
-   Hardware and Installation
    
-   Removal & Repair of Hardware
    -   Requesting a Repair or a Deinstallation
-   Cameras & GDPR Guidelines
    
-   Scheduled Reports
    
-   Safety Program
    
-   Fleet Manager App
    
-   Users & Permissions
    
-   Alerts
    
-   Policies & Documents
    
-   Privacy Policy and Terms & Conditions
    -   RoPA
-   API
    
-   Transpoco User Manuals
    
-   Settings
    -   Garage
-   Whats New?
    
-   Account Mangement Services
    
-   Driver ID process
    
-   Security
    
-   Transpoco Locate
    
-   Subscriptions & Invoices
    
-   Tutorial videos
    
-   Cancelling your account
    
-   VOR
    
-   Installation
    
-   BIKLY
    

# Transpoco Locate: How do I view my vehicles' details?

## How to view your vehicles' details in SynX Locate.

SynX holds details of all your vehicles in a database, which you can add to and amend yourself.

Click on your **name** in the top right of the screen and select ‘Settings’ from the drop-down menu.

The settings menu will open.

Click on **Vehicles** and the list of vehicles and their details will open.

The standard information contained in this table covers the following:

-   Vehicle registration: Vehicle number plate (required)
-   Description: Secondary description (required)
-   Make: Make of vehicle
-   Model: Model of vehicle
-   Fuel Type: Petrol/diesel/electric
-   Fleet Number: Vehicles can be included in separate numbered fleets
-   Mileage (km): GPS-based mileage counter at last update
-   Notes: Free text box for any other information to include
-   Label: What will appear with the vehicle icon on a map, e.g. registration
-   Label Colour: Drop-down list of different colours for the label
-   Icon: Drop-down list of different vehicle types, e.g. truck, bus
-   CANbus enabled: Yes/No
-   Date of Delivery: Pop-up calendar for date selection
-   Exterior condition: Free text to add information
-   Edit: See Edit a Vehicle

To export the data as .csv or .xls format, click on the **Export** icon on the right-hand side.

The system will ask you to select a destination for the file and the file will be saved on your system.

To print the data, click on **Print** on the right-hand side.

Select ‘landscape’ for **Layout** in the print settings.

### Archived vehicles

Any vehicles that are taken out of use are moved to the archive, so the information is still available but the vehicles will not be included in any reports.

To view archived vehicles, click on the **Archive** tab.
