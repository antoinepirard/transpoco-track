# Sample DPIA

Back to home

1.  Knowledge Base 
3.  Logging-in to your Transpoco account 
5.  Implementation 

-   Logging-in to your Transpoco account
    -   Login to your Transpoco account
    -   Transpoco Smartphone Apps
    -   2 Factor Authentication
    -   System requirements
    -   Overview of Transpoco
    -   Implementation
-   How to organise your account to achieve the best results
    
-   How to use each feature - step by step guides
    -   Users and permissions
    -   Walkaround Checks module
    -   Fuel/Electric Vehicles Module
    -   Maintain Module
    -   Dashboard
    -   Messaging module
    -   Scheduled Reports
-   How to Order More Trackers
    
-   Live Map
    
-   Cameras
    -   FAQ
-   Webinar Videos
    
-   Walkaround Checklists
    -   Walkaround Checklists
    -   Driver App
    -   Alerts
-   Reports
    -   Reports
    -   Viewing data in reports
-   Fuel
    
-   Dashboard
    
-   Maintain Module
    
-   Driving Style
    
-   Locations
    
-   Cost Management (TCO) Report
    
-   The Notification Features
    
-   Hardware and Installation
    
-   Removal & Repair of Hardware
    -   Requesting a Repair or a Deinstallation
-   Cameras & GDPR Guidelines
    
-   Scheduled Reports
    
-   Safety Program
    
-   Fleet Manager App
    
-   Users & Permissions
    
-   Alerts
    
-   Policies & Documents
    
-   Privacy Policy and Terms & Conditions
    -   RoPA
-   API
    
-   Transpoco User Manuals
    
-   Settings
    -   Garage
-   Whats New?
    
-   Account Mangement Services
    
-   Driver ID process
    
-   Security
    
-   Transpoco Locate
    
-   Subscriptions & Invoices
    
-   Tutorial videos
    
-   Cancelling your account
    
-   VOR
    
-   Installation
    
-   BIKLY
    

# Sample DPIA

  
  

**Step 1a: DPIA Screening Checklist -****Controller: Company A-**

**Does your project involve:**

**Yes**

**No**

Evaluation or scoring of personal data (including profiling and predicting)

The platform will monitor, evaluate and score personal data i.e. driver behavior

Automated decision-making with legal or similar significant effects

Systematic monitoring including through a publicly accessible place on a large scale

The cameras will be installed in over 1000 vehicles travelling throughout Ireland 

Sensitive data or data of a highly personal nature (including special categories of data and criminal data) Camera will capture footage of drivers face at work (including personal habits)

Data processed on a large scale As above vehicles travelling in public spaces

Matching or combining data sets

Data concerning vulnerable people (including children)

Innovative use or applying technological or organisational solutions AI is an innovative use of processing of data collection

Processing preventing data subjects from exercising a right or using a service or contract

If you have answered yes to any of the above questions, you must carry out a DPIA. 

**Step 1b: Identify the Need for a DPIA**

Explain broadly what the project aims to achieve and what type of processing of personal data it involves. 

Company A intends to install and operate a driver safety product offered by Company T comprising two in-cam cameras, one facing the road ahead and one facing the driver. Footage captured by the cameras will be processed by Company T’s Artificial Intelligence software to detect lane departure, driving too close to the vehicle ahead, forward collision warning, distracted driving, driver fatigue, mobile phone use and driver smoking. Data collected for these incidents will be applied to a points system giving a drive safely sore for each drive. Drivers will be incentivised for good driving and provided with additional driver training for excessive behavioral events. Ultimately the system is designed to improve driving, reduce accidents and reduce insurance premiums.

**Step 2: Describe the Processing**

**Describe the nature of the processing:** how will you collect, use, store and delete data? What is the source of the data? Will you be sharing data with anyone? What types of processing identified as likely high risk are involved?

Data will be collected from in-cab cameras, front and driver facing cameras and stored locally on a 125Gb SD card. The camera is equipped with a sim card and 3G modem, footage from the camera can be pulled from the camera on demand by Company A to a Saas platform provided by Company T. The platform is hosted on Amazon Web Services to ISO27001 standards. The stored data in-cam o the SD card is encrypted and secured within the camera by a locking mechanism. The cloud stored footage is only available to dedicated staff at Company A.

**Describe the scope of the processing:** what is the nature of the data, and does it include special category or criminal offence data? How much data will you be collecting and using? How often? How long will you keep it? How many individuals are affected? What geographical area does it cover?

The data collected is video footage of the road ahead of a vehicle and footage of the driver. Both data sets are introduced in a machine vision algorithm which will monitor the driving behavior of the driver. Typically 2Gb of data will be collected per month, polled at regular daily intervals on demand by Company A. Data will be retained for a period of 7 years as per Company T’s ISO requirements, however Company A can delete data on demand. The system will be installed into 1000 vehicles covering the island of ireland.

**Describe the context of the processing:** what is the nature of your relationship with the individuals? How much control will they have? Would they expect you to use their data in this way? Do they include children or other vulnerable groups? Are there prior concerns over this type of processing or security flaws? Is it novel in any way? What is the current state of technology in this area? Are there any current issues of public concern that you should factor in? Are you signed up to any approved code of conduct or certification scheme (once any have been approved)?

The drivers are employed by Company A, they will be granted access to the footage, and allowed to dispute its reporting within HR guidelines. Footage may inadvertently include pedestrians however the AI algorithm is designed to only focus on the road ahead, vehicle shapes and driver related behaviors. This technology is not novel and precedent has been set by other providers. Warning stickers will be visible on the front rear and inside the cab of the vehicle. 

**Describe the purposes of the processing:** what do you want to achieve? What is the intended effect on individuals? What are the benefits of the processing for you, and more broadly?

The nature of the rollout is to monitor and improve the driving behavior of our drivers. The drivers will be encouraged to drive more safely, and will be rewarded for doing so. As a company we expect to improve our safety record, reduce accidents and lower our insurance cost.

**Step 3: Assessment of Necessity and Proportionality of Processing**

**Describe compliance and proportionality measures**, in particular: what is your lawful basis for processing? Does the processing actually achieve your purpose? Is there another way to achieve the same outcome? How will you prevent function creep? How will you ensure data quality and data minimisation? What information will you give individuals? How will you help to support their rights? What measures do you take to ensure processors comply? How do you safeguard any international transfers? Prior consultation?

**Step 4: Consult with Stakeholders**

**Consider how to consult with relevant stakeholders:** describe when and how you will seek individuals’ views – or justify why it’s not appropriate to do so. Who else do you need to involve within your organisation? Do you need to ask your processors to assist? Do you plan to consult information security experts, or any other experts?

  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  

**Steps 5 & 6: Risk Assessment - Identifying Privacy Risks and Evaluating Privacy Solutions**

 

 

**Name of College/School/Service/Project:\_XXXX**

 

 

 

 

 

 

**Risk Register Owner: XXXX**

**Risk ID**

**Risk Description**

**Consequence**

**Risk Owner**                   

**Current internal** **CONTROLS**

**(provide details of how you currently manage the risk)**

**Assessment of Risk**

**Describe what further** **ACTIONS** **you will take to** **reduce the Impact/Likelihood** **and**

**mitigate** **the risk.**                                        

**State who is the risk owner for each action**

**Impact**

(1,2,3,4,5)

**Likelihood** (1,2,3,4,5)

**Score**

 

  
  
  

Step 7: Document DPIA Outcomes

**Item**

**Name/date**

**Notes**

Measures approved by:

Integrate actions back into project plan, with date and responsibility for completion

DPO advice provided:

DPO should advise on compliance, step 6 measures and whether processing can proceed

Summary of DPO advice:

DPO advice accepted or overruled by:

If overruled, you must explain your reasons

Comments:

Residual risks approved by:

If accepting any residual high risk, consult the Data Commissioner before going ahead

Consultation responses reviewed by:

If your decision departs from individuals’ views, you must explain your reasons

Comments:

This DPIA will be kept under review by:

The DPO should also review ongoing compliance with DPIA
