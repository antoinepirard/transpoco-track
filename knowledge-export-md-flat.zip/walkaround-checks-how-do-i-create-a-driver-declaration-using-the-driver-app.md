# Walkaround Checks: How do I create a driver declaration using the Driver app?

Back to home

1.  Knowledge Base 
3.  Walkaround Checklists 
5.  Driver App 

-   Logging-in to your Transpoco account
    -   Login to your Transpoco account
    -   Transpoco Smartphone Apps
    -   2 Factor Authentication
    -   System requirements
    -   Overview of Transpoco
    -   Implementation
-   How to organise your account to achieve the best results
    
-   How to use each feature - step by step guides
    -   Users and permissions
    -   Walkaround Checks module
    -   Fuel/Electric Vehicles Module
    -   Maintain Module
    -   Dashboard
    -   Messaging module
    -   Scheduled Reports
-   How to Order More Trackers
    
-   Live Map
    
-   Cameras
    -   FAQ
-   Webinar Videos
    
-   Walkaround Checklists
    -   Walkaround Checklists
    -   Driver App
    -   Alerts
-   Reports
    -   Reports
    -   Viewing data in reports
-   Fuel
    
-   Dashboard
    
-   Maintain Module
    
-   Driving Style
    
-   Locations
    
-   Cost Management (TCO) Report
    
-   The Notification Features
    
-   Hardware and Installation
    
-   Removal & Repair of Hardware
    -   Requesting a Repair or a Deinstallation
-   Cameras & GDPR Guidelines
    
-   Scheduled Reports
    
-   Safety Program
    
-   Fleet Manager App
    
-   Users & Permissions
    
-   Alerts
    
-   Policies & Documents
    
-   Privacy Policy and Terms & Conditions
    -   RoPA
-   API
    
-   Transpoco User Manuals
    
-   Settings
    -   Garage
-   Whats New?
    
-   Account Mangement Services
    
-   Driver ID process
    
-   Security
    
-   Transpoco Locate
    
-   Subscriptions & Invoices
    
-   Tutorial videos
    
-   Cancelling your account
    
-   VOR
    
-   Installation
    
-   BIKLY
    

# Walkaround Checks: How do I create a driver declaration using the Driver app?

## How to create a driver declaration in the Driver app, which allows you to record details of your driving licence, any penalty points incurred, and any accidents, claims or convictions.

From the Walkaround Home Page, tap on **Driver Dec**.

Either scroll down the full list of vehicles or search for a vehicle by typing in part or all of a registration number or vehicle/driver name in the search box.

Tap on the required vehicle.

Screenshot\_20190727\_145518\_com.synx.driver

Select **Driver Dec** from the list of available Checklists and **Declaration** on the next screen.

Screenshot\_20190725\_150619\_com.synx.driver     Screenshot\_20190729\_183206\_com.synx.driver

There now follows a series of questions about you as a driver – each question must be answered to continue to the next.

Enter the number of penalty points you have incurred, or type ‘None’.

Screenshot\_20190729\_183214\_com.synx.driver

Tap on the **green** **tick**.

Enter details about any accidents, claims or convictions in the last five years, or type ‘None’.

Screenshot\_20190729\_183240\_com.synx.driver

Tap on the **green** **tick**.

Tap on the **red cross** or **swipe left** to attach photos of your driving licence.

Screenshot\_20190729\_183255\_com.synx.driver     Screenshot\_20190729\_183312\_com.synx.driver

In the text box, type in any details about your driving licence that may need to be recorded.

Add a photo of the front of your licence by tapping on **Photo**.

Screenshot\_20190729\_183503\_com.synx.driver

**NOTE:** For instructions on how to add a photo from your camera's library or by taking a photo, see Walkaround Checks: How do I add a photo to the SynX Driver app?

Add a photo of the rear of your driving licence.

Screenshot\_20190730\_000613\_com.synx.driver

Tap on the green **Save** button.

The app will automatically advance to the next question.

There now follows a series of declarations – each declaration must be answered by typing a response in the text box, followed by tapping the **green** **tick**, to advance to the next screen.

Once all six sections have been completed, the app shows the following screen:

Screenshot\_20190731\_182931\_com.synx.driver

Type any comments or provide further details in the text box if desired.

To submit the Driver Declaration without reviewing, tap on **Submit Checklist**.

To review the Driver Declaration before submitting, tap on **Review Checklist**.

Scroll down to review each declaration. Click on **Edit** for any item that requires amending or additional information.

Screenshot\_20190730\_000638\_com.synx.driver     Screenshot\_20190730\_000647\_com.synx.driver

Scroll to the end of the checklist and tap on **Submit Checklist**.

Screenshot\_20190730\_000703\_com.synx.driver
