# How to create a customised user profile

Back to home

1.  Knowledge Base 
3.  Users & Permissions 

-   Logging-in to your Transpoco account
    -   Login to your Transpoco account
    -   Transpoco Smartphone Apps
    -   2 Factor Authentication
    -   System requirements
    -   Overview of Transpoco
    -   Implementation
-   How to organise your account to achieve the best results
    
-   How to use each feature - step by step guides
    -   Users and permissions
    -   Walkaround Checks module
    -   Fuel/Electric Vehicles Module
    -   Maintain Module
    -   Dashboard
    -   Messaging module
    -   Scheduled Reports
-   How to Order More Trackers
    
-   Live Map
    
-   Cameras
    -   FAQ
-   Webinar Videos
    
-   Walkaround Checklists
    -   Walkaround Checklists
    -   Driver App
    -   Alerts
-   Reports
    -   Reports
    -   Viewing data in reports
-   Fuel
    
-   Dashboard
    
-   Maintain Module
    
-   Driving Style
    
-   Locations
    
-   Cost Management (TCO) Report
    
-   The Notification Features
    
-   Hardware and Installation
    
-   Removal & Repair of Hardware
    -   Requesting a Repair or a Deinstallation
-   Cameras & GDPR Guidelines
    
-   Scheduled Reports
    
-   Safety Program
    
-   Fleet Manager App
    
-   Users & Permissions
    
-   Alerts
    
-   Policies & Documents
    
-   Privacy Policy and Terms & Conditions
    -   RoPA
-   API
    
-   Transpoco User Manuals
    
-   Settings
    -   Garage
-   Whats New?
    
-   Account Mangement Services
    
-   Driver ID process
    
-   Security
    
-   Transpoco Locate
    
-   Subscriptions & Invoices
    
-   Tutorial videos
    
-   Cancelling your account
    
-   VOR
    
-   Installation
    
-   BIKLY
    

# How to create a customised user profile

## In this article we will demonstrate how to create a customised user profile and explain the different modules

Profiles allow administrators to restrict access to various parts of the platform for their users. To set up a customised profile go to **Settings > Users & Permissions > Profiles**

**The system provides 4 different default profiles which are:**

\* Admin - With access to the whole system based on the package chosen;

\* Standard Viewer - Won't have access to the Settings menu option;

\* Email Only - Won't have access to the system but it can be set as a recipient for alerts and scheduled reports.

\* Custom -  Customised access 

Your Transpoco account consists of different modules and we will explain the purpose of each module now.  We will explain the purpose of each module to allow you to create your own customised profile.

-   Administrator: This permission allows users to edit settings on all aspects of the platform
-   Live Map : This permission allows users to view the live map
-   Locations: This permission allows users to create, edit, delete and report on locations
-   Temperature (optional feature): This permission gives access to view features for Temperature probe reporting.
-   Routing (optional feature): This permission gives access to create, edit, delete and report on routes
-   Fuel Cards: This permission allows users access to the Fuel Module.
-   Fleet Manager App: This permission gives access to login to the Transpoco Fleet Manager App. Users can login to the app using their login details for their account.
-   Map Features: This permission allows users access to the Fuel Module.
-   Notifications: This permission allows users access to view Notifications. The Notifications feature is located on the navigation menu and the user can open unread notifications.
-   Profiles: This permission gives access to create, edit, assign and delete profiles
-   Alerts: This permission allows the user to view features on the Live Map such as the Heat Map or different map options.
-   Driving Style: This permission gives access to driving style and driver alerts reports
-   Driver ID (optional feature): This permission allows the user to access Driver details and reporting related to Driver ID
-   Maintain: This permission allows the user to access the Maintain module
-   Winter Maintenance Reports (optional feature):
-   User Management: This permission allows the user to access the Users & Permissions settings.
-   Security Settings Management: This permission allows the user to access the Security Settings on the Settings menu.
-   Camera: This permission allows the user to access the Camera module
-   Drivers and drivers groups: This permission allows the user to access the Driver profiles and Driver Groups in the Settings menu.
-   Reports: This permission allows users to run and download reports
-   Dashboards: This permission allows the user to access the Dashboard module
-   PTO (optional feature): This permission gives access to reports on PTO or Operating vehicles or plants
-   Walkaround: This permission allows the user to access the Walkaround module
-   API: This permission gives access to connect your Transpoco account with various software through our API
-   Vehicle access control: This permission allows the user to manage vehicles and vehicle groups
-   Driver app: This permission allows the user to access the Walkaround module. The user can login to the Synx Driver app using their login details for their Synx account.
-   Messaging: This permission allows users to message drivers directly from the platform.  
      
    

**Note:** After you select the permissions the final step is to provide other users with access to assign this profile. Click the **Profile Access** tab and select users from this organisation who will be able to assign this profile to new or existing users.

Once you click to edit an existing profile, the system will present more options to customise:

*Map Customisation:* This section allows you to select whether the user sees a line or arrow during route replay

*Report Customisation:* This section allows you to select which fields are included on each report. Simply drag and drop the fields you’d like included.

*Layout Customisation:* This section allows you to select how the vehicles appear on the drop down menus

*Garage Customisation:* This section allows you to select which fields appear in the Vehicle's section. Simply drag and drop the fields you’d like to see

*Drivers Customisation:* This section allows you to select which fields appear in the Driver's section. Simply drag and drop the fields you’d like to see
