# Transpoco Briefing Document

Back to home

1.  Knowledge Base 
3.  Logging-in to your Transpoco account 
5.  Implementation 

-   Logging-in to your Transpoco account
    -   Login to your Transpoco account
    -   Transpoco Smartphone Apps
    -   2 Factor Authentication
    -   System requirements
    -   Overview of Transpoco
    -   Implementation
-   How to organise your account to achieve the best results
    
-   How to use each feature - step by step guides
    -   Users and permissions
    -   Walkaround Checks module
    -   Fuel/Electric Vehicles Module
    -   Maintain Module
    -   Dashboard
    -   Messaging module
    -   Scheduled Reports
-   How to Order More Trackers
    
-   Live Map
    
-   Cameras
    -   FAQ
-   Webinar Videos
    
-   Walkaround Checklists
    -   Walkaround Checklists
    -   Driver App
    -   Alerts
-   Reports
    -   Reports
    -   Viewing data in reports
-   Fuel
    
-   Dashboard
    
-   Maintain Module
    
-   Driving Style
    
-   Locations
    
-   Cost Management (TCO) Report
    
-   The Notification Features
    
-   Hardware and Installation
    
-   Removal & Repair of Hardware
    -   Requesting a Repair or a Deinstallation
-   Cameras & GDPR Guidelines
    
-   Scheduled Reports
    
-   Safety Program
    
-   Fleet Manager App
    
-   Users & Permissions
    
-   Alerts
    
-   Policies & Documents
    
-   Privacy Policy and Terms & Conditions
    -   RoPA
-   API
    
-   Transpoco User Manuals
    
-   Settings
    -   Garage
-   Whats New?
    
-   Account Mangement Services
    
-   Driver ID process
    
-   Security
    
-   Transpoco Locate
    
-   Subscriptions & Invoices
    
-   Tutorial videos
    
-   Cancelling your account
    
-   VOR
    
-   Installation
    
-   BIKLY
    

# Transpoco Briefing Document

**Vehicles Management System (VMS) Briefing Document** 

Your Safety is very important.

(Insert Company Name) commits to doing its utmost to ensure that each employee arrives to work and home safely each day. Therefore, (Insert Company Name) has initiated an upgraded Vehicle  Management System (Transpoco) to achieve this aim. 

The leading cause of Vehicle Accidents is **driver behaviour**. The introduction of the  VMS will help drivers improve their driving skill sets, thus assisting them to drive more  safely and ensuring **less collisions** occur therefore reducing risk to all employees, other road users and members of the public. This is aligned with (Insert Company Name)’s primary core  value which is **“Live Safety”**

  
  
  

 **VMS Briefing Document** 

**Who is responsible for this system?** 

The fleet department is responsible for the rollout, implementation, maintenance, and  monitoring of the VMS system. Providing safe, fit for purpose vehicles is our primary  focus. The relevant training on use of the system will be given to all staff 

**Who is this relevant to?** 

-   Staff who drive company vehicles and employees who drive for work 

**When is the proposed implementation?** 

-   Company vehicles are being fitted with a VMS unit which commenced on the (Insert date) to replace the incumbent system (Insert Competitor name). Currently we are  rolling the camera and A.I. (artificial intelligence) functionality of this new system 

**How will it work?** 

-   The following slides will give the details of how it is being rolled out and explain the VMS elements that are applied with this system

  
  

**VMS Briefing Document**  

VMS is a GPS Fleet Management system combined with camera and artificial  intelligence technology. The primary purpose of the Vehicle Management system is to  safeguard the health and safety of employees and to improve driving skill sets,  efficiency, productivity, vehicle utilisation and service delivery. The data to be collected includes. 

-   Fleet utilisation 
-   Fuel consumption & carbon footprint measurement, reporting, and compliance  • vehicle daily checks & defect reporting mechanism (S.I.348 legislation compliance) • Speeding events, driving style 
-   Camera functionality for accident investigation 
-   Benefit in Kind reporting (TCA 1997 legislation compliance) 
-   Artificial intelligence that reports on driving style & behaviour 
-   Accurate reporting and measurement across all business units in all territories

**VMS Briefing Document**  

-   The VMS is not a people monitoring system and will only be used for identifying  driving style & behaviour that requires intervention and upskilling, or to assist in  accident investigation 
-   This data will enable early intervention for additional driver training and upskilling  where required thereby reducing road related risk of collisions and injury 
-   The rollout is in 4 phases. 

(1) Camera alerts examples

AI Camera Alerts

(2) Implementation of driver I.D.

(3) Implementation of vehicle daily check & defect reporting “App” see

 Daily Driver walkaround video

(4) Installation of Cameras and A.I. **(expected completion end of Q2 2021)**

AI Driver Onboarding video

  
  
  
  
  

**VMS Briefing Document**  

-   Alerts are received if VMS units are interfered with or tampered with(Insert Video). Any  employees that have been found to have tampered or interfered with VMS units  will have the Grievance and Disciplinary Policies and Procedures initiated through  the respective management structure 
-   All data protection procedures and policies will be stringently followed in  compliance with European GDPR policies and guidelines along with (Insert Company Name) GDPR  policies and guidelines 
-   The Data Privacy Impact Assessment will be used as part of the implementation  process. The DPIA is a tool which assists (Insert Company Name) identify the most effective way to  comply with its data protection obligations and meet all employees & individual’s  expectations of privacy

  
  
  

**VMS Briefing Document**  

-   The National Road Safety Authority Strategy focuses on working with local  authorities, NRA, HSA, Gardaí, state stakeholders, & business organisations,  collectively striving to improve road safety 
-   We at (Insert Company Name) are fully supportive of this strategy and will endeavour to play our  part in the reduction of road fatalities, injuries, and collisions, it is our duty of care  to do so 
-   We are all on a collective journey towards safer roads, reduced fatalities and  serious injuries, to this end (Insert Company Name) has moved to encapsulate the concept of  passive safety systems in company vehicles, which is a Vehicle management  System (VMS) with its primary function to provide better road safety and vehicle  safety for all employees, other road users and members of the general public

7 

  
  
  
  

**VMS Briefing Document** 

**I would like to ask a question?** 

-   • The first port of call should be your line manager 
-   • Questions can also be directed to email@(Insert Company Name).com • We will endeavour to respond within 48 hours 
-   • Further information and updates will follow in the coming months
-   In the event of an accident, the driver is advisable to verbally inform the other parties involved in the accident that the incident has been recorded.

8 

  
  
  
  
  

  
  
  

**VMS Briefing Document** 

**Key Benefits to the organisation & Employees**  

-   Delivers real value across our entire business, benefitting all employees, other road-users and  the wider community 
-   Assists in achieving our primary organisation goal of “safety first” with a “zero harm” result Work safe, home safe, every day 
-   Benefits include fewer collisions, less downtime, improved operational and safety standards,  legal compliance as well as lower fuel bills and insurance premiums 
-   The use of telematics and A.I. technology is recommended and endorsed by several leading  motor fleet insurance companies, including our insurer.
