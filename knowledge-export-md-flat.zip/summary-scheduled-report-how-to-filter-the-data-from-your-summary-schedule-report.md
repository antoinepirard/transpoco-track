# [Summary Scheduled Report] - How to filter the data from your Summary Schedule Report?

Back to home

1.  Knowledge Base 
3.  How to use each feature - step by step guides 
5.  Scheduled Reports 

-   Logging-in to your Transpoco account
    -   Login to your Transpoco account
    -   Transpoco Smartphone Apps
    -   2 Factor Authentication
    -   System requirements
    -   Overview of Transpoco
    -   Implementation
-   How to organise your account to achieve the best results
    
-   How to use each feature - step by step guides
    -   Users and permissions
    -   Walkaround Checks module
    -   Fuel/Electric Vehicles Module
    -   Maintain Module
    -   Dashboard
    -   Messaging module
    -   Scheduled Reports
-   How to Order More Trackers
    
-   Live Map
    
-   Cameras
    -   FAQ
-   Webinar Videos
    
-   Walkaround Checklists
    -   Walkaround Checklists
    -   Driver App
    -   Alerts
-   Reports
    -   Reports
    -   Viewing data in reports
-   Fuel
    
-   Dashboard
    
-   Maintain Module
    
-   Driving Style
    
-   Locations
    
-   Cost Management (TCO) Report
    
-   The Notification Features
    
-   Hardware and Installation
    
-   Removal & Repair of Hardware
    -   Requesting a Repair or a Deinstallation
-   Cameras & GDPR Guidelines
    
-   Scheduled Reports
    
-   Safety Program
    
-   Fleet Manager App
    
-   Users & Permissions
    
-   Alerts
    
-   Policies & Documents
    
-   Privacy Policy and Terms & Conditions
    -   RoPA
-   API
    
-   Transpoco User Manuals
    
-   Settings
    -   Garage
-   Whats New?
    
-   Account Mangement Services
    
-   Driver ID process
    
-   Security
    
-   Transpoco Locate
    
-   Subscriptions & Invoices
    
-   Tutorial videos
    
-   Cancelling your account
    
-   VOR
    
-   Installation
    
-   BIKLY
    

# \[Summary Scheduled Report\] - How to filter the data from your Summary Schedule Report?

## You can apply customized filters on your Summary report in the scheduled report section. Please find the detailed instructions below: 

1.  Log in to your Transpoco account.
2.  Click on the Services > Analytics > Scheduled Report.  
    
3.  You will see the scheduled reports page, then click on the “+ New Schedule Report”.  
    
4.  Type in “Subject”, “Description”, select “Vehicles” or “filter by vehicle groups”, and then select the “Summary” for the Report Types.  
    
5.  Then click “Next” , go to the “Configuration” .
6.  Then set up the following options, Schedule period, Schedule Time, File format Report Language, Time Zone and Distance Unit.

**The next step is where you can apply customized filters to the Summary Report schedule report.**

  7.  There are 8 filters: Drive Duration; Drive Distance; Journeys; First Start Time; Last Stop Time; Idling Duration; Shift Duration; and Private Distance. 

-   **Drive Duration:** 

This filter indicates the total drive duration (in hours) from the vehicles selected.

**Note:** You can customize the filter by choosing different operators: Equal to, Greater than or Less Than, as well as choose the value of the filter. Eg: Drive Duration > 20 hours per day. 

-   **Drive Distance:** 

This filter indicates the total drive distance (Kilometre or Mileage) from the vehicles selected.

**Note:** You can customize the filter by choosing different operators: Equal to, Greater than or Less Than, as well as choose the value of the filter. Eg: Drive Distance > 100 km per day. 

-   **Journeys:** 

This filter indicates the number of journeys (how many times the vehicle has been turned on and off).

**Note:** You can customize the filter by choosing different operators: Equal to, Greater than or Less Than, as well as choose the value of the filter. Eg: Journeys < 10 per day. 

-   **First Start Time:** 

This filter indicates the first start time of the vehicles selected. “First Start time” is when the vehicle is turned ON for the first time in the day.

**Note:** You can customize the filter by choosing different operators: Equal to, Greater than or Less Than, as well as choose the value of the filter. Eg: First Start Time = 11:00 am per day.

-   **Last Stop Time:** 

This filter indicates the last stop time of the vehicles selected. “Last Stop time” is when the vehicle is turned OFF for the last time in the day. 

**Note:** You can customize the filter by choosing different operators: Equal to, Greater than or Less Than, as well as choose the value of the filter. Eg: Last Stop Time < 04:00 pm per day.

-   **Idling Duration:** 

This filter indicates the total Idling duration (in Hours) of the vehicles selected.

**Note:** You can customize the filter by choosing different operators: Equal to, Greater than or Less Than, as well as choose the value of the filter. Eg: Idling Duration > 20 hours per day.

-   **Shift Duration:**

This filter indicates the total shift Duration (Hours) of the vehicles selected. “Shift Duration” means the duration in hours between the first time the vehicle was turned ON in the day and last time the vehicle was turned OFF in the day.

**Note:** You can customize the filter by choosing different operators: Equal to, Greater than or Less Than, as well as choose the value of the filter. Eg: Shift Duration > 10 hours per day.

-   **Private Distance:**

This filter indicates the total distance driven (kilometres or mileage) in the private mode by the vehicles selected.

**Note:** You can customize the filter by choosing different operators: Equal to, Greater than or Less Than, as well as choose the value of the filter. Eg: Private Distance > 100 MI per day.
