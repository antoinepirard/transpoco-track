# Transpoco Locate: How do I create a Summary Report?

Back to home

1.  Knowledge Base 
3.  Transpoco Locate 

-   Logging-in to your Transpoco account
    -   Login to your Transpoco account
    -   Transpoco Smartphone Apps
    -   2 Factor Authentication
    -   System requirements
    -   Overview of Transpoco
    -   Implementation
-   How to organise your account to achieve the best results
    
-   How to use each feature - step by step guides
    -   Users and permissions
    -   Walkaround Checks module
    -   Fuel/Electric Vehicles Module
    -   Maintain Module
    -   Dashboard
    -   Messaging module
    -   Scheduled Reports
-   How to Order More Trackers
    
-   Live Map
    
-   Cameras
    -   FAQ
-   Webinar Videos
    
-   Walkaround Checklists
    -   Walkaround Checklists
    -   Driver App
    -   Alerts
-   Reports
    -   Reports
    -   Viewing data in reports
-   Fuel
    
-   Dashboard
    
-   Maintain Module
    
-   Driving Style
    
-   Locations
    
-   Cost Management (TCO) Report
    
-   The Notification Features
    
-   Hardware and Installation
    
-   Removal & Repair of Hardware
    -   Requesting a Repair or a Deinstallation
-   Cameras & GDPR Guidelines
    
-   Scheduled Reports
    
-   Safety Program
    
-   Fleet Manager App
    
-   Users & Permissions
    
-   Alerts
    
-   Policies & Documents
    
-   Privacy Policy and Terms & Conditions
    -   RoPA
-   API
    
-   Transpoco User Manuals
    
-   Settings
    -   Garage
-   Whats New?
    
-   Account Mangement Services
    
-   Driver ID process
    
-   Security
    
-   Transpoco Locate
    
-   Subscriptions & Invoices
    
-   Tutorial videos
    
-   Cancelling your account
    
-   VOR
    
-   Installation
    
-   BIKLY
    

# Transpoco Locate: How do I create a Summary Report?

## How to run a Summary Report in Locate.

Similar to the Fleet Summary Report, but the Summary Report can be filtered further to one or more vehicles, and shows start/stop time of the day’s activities and a route replay on the map.

**Note:** If you require more detailed information about how to run the report, see How do I create a report?

1.  Select the **Vehicle(s)**.
2.  Select ‘Summary’ from the **Reports** drop-down list.
3.  Select the **date** range.
4.  Click on the **View Report** button.

Summary Report

The totals for the fleet (or selected group of vehicles) are in the pink row.

The standard information contained in this report covers the following for each day during the selected period:

-   Date: Date vehicle was driven
-   First Start Time: The first time the engine was started that day in hours & minutes
-   Last Stop Time: The last time the engine was turned off that day in hours & minutes
-   Shift Duration: The time between the first engine on and the last engine off
-   No. Journeys: Total number of separate journeys undertaken that day
-   Travel Time: Total hours and minutes vehicle was moving
-   Distance: Total distance (in km or miles) covered that day
-   Idling Time: Total hours & minutes vehicle had ignition on but not moving
-   View Route: Mapped route of the journey between start time and last stop time

The 'No. Journeys' is also a hyperlink to the Journey Report for that vehicle on that day.

To export the data as .csv or .xls format, click on the **Export** icon above the far right column. For more information see How do I export a report?

### View route on the map

To view on the map a replay of all the journeys of any vehicle on any day, click the **View Route** icon at the end of that row.

The report will show a map of the journeys above a list of each event or part of the journey.

Summary Report - on map

The journeys are drawn from start to finish mapping out the total driven that day.

The rows show the individual driving events and driving time intervals (usually every ~30 seconds) that sent data from the GPS unit to the software.

The standard information contained in this table covers the following for each driving event and part of the journey:

-   Date: Shows the date of the journeys
-   Location: Where the driving event took place
-   Speed: Snapshot of the speed when driving data was sent
-   Driver: Assigned driver to vehicle
-   Satellites: Number of satellites tracking the vehicle GPS
-   Engine: Ignition on or off
-   Event: Vehicle data updates on movement and time intervals
-   Coordinates: Map coordinates of location

Click on rows in the table to view the corresponding event on the journey as black arrows.

Summary Report - on map view event

Use the **map controls** to zoom into parts of the journey or view in Street View.

By default, the map and table are split 50/50 on the screen. To show the map full screen, click on the **Split Screen** icon (top icon) in the top left-hand corner. The system will remember your choice.

Summary Map toggle icons

As the map will fill now the screen, scroll down to view the table rows.

Click the icon again to return to 50/50 split screen.

To view only the map in full screen, click on the **Full Screen** icon (bottom icon) in the top left-hand corner.

To exit the full screen mode, click on the icon again or press the **ESC** key.

To export the data as .csv or .xls format, click on the **Export** icon above the far right column. For more information see How do I export a report?

### Chart view

The Summary chart view graphs the Shift Duration, Travel Time, Idling Time and Distance per vehicle per day.

From the main tabular report, click on the **Chart** tab.

Hover the cursor over the bars to see the information in a pop-up, such as date, duration of the shift and number of journeys in the shift.

Summary Report - chart view
